import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

// StrictMode intentionally omitted: the WebGL engine must be created exactly once.
createRoot(document.getElementById("root")!).render(<App />);
