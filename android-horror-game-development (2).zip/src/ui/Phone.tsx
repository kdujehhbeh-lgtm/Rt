import { useState, useSyncExternalStore } from 'react';
import { ui } from '../game/store';
import { Game } from '../game/game';

const FA = (s: string) => s.replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);

/** realistic smartphone overlay: contacts, recents, dial pad, in-call screen */
export function PhoneUI({ game }: { game: Game }) {
  const st = useSyncExternalStore(ui.subscribe, ui.get);
  const [tab, setTab] = useState<'contacts' | 'pad'>('contacts');
  const [num, setNum] = useState('');
  if (!st.phoneOpen) return null;
  const call = st.phoneCall;
  const contacts = Object.entries(Game.CONTACTS);
  const now = st.clock;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/50" dir="rtl" onPointerDown={(e) => e.stopPropagation()}>
      <div className="relative w-[240px] h-[min(470px,92vh)] rounded-[34px] bg-zinc-950 border-[6px] border-zinc-800 shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden">
        <div className="absolute top-1.5 left-1/2 -translate-x-1/2 w-20 h-5 rounded-full bg-black z-10" />
        <div className="flex justify-between px-5 pt-2 text-[10px] text-white/80" dir="ltr"><span>{now}</span><span>▂▄▆ 4G 🔋</span></div>
        {call ? (
          <div className="flex flex-col items-center justify-between h-[calc(100%-24px)] py-8 bg-gradient-to-b from-zinc-800 to-zinc-950">
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 rounded-full bg-zinc-600 flex items-center justify-center text-3xl text-white">{call.name.slice(0, 1)}</div>
              <div className="mt-3 text-white text-lg">{call.name}</div>
              <div className="text-white/50 text-xs mt-1">{call.status === 'calling' ? 'در حال تماس…' : call.status === 'talking' ? 'در حال مکالمه' : call.status === 'busy' ? 'در دسترس نیست' : 'تماس پایان یافت'}</div>
            </div>
            <div className="grid grid-cols-3 gap-4 text-white/70 text-[10px] text-center">
              {['🔇 بی‌صدا', '⌨ صفحه‌کلید', '🔊 بلندگو'].map((l) => <div key={l} className="w-14 h-14 rounded-full bg-white/10 flex items-center justify-center">{l}</div>)}
            </div>
            <button onClick={() => game.closePhone()} className="w-16 h-16 rounded-full bg-red-600 text-white text-2xl shadow-lg active:scale-95">✆</button>
          </div>
        ) : (
          <div className="h-[calc(100%-24px)] flex flex-col bg-zinc-950">
            <div className="px-4 pt-3 pb-2 text-white text-lg font-bold">{tab === 'contacts' ? 'مخاطبین' : 'شماره‌گیر'}</div>
            {tab === 'contacts' ? (
              <div className="flex-1 overflow-y-auto">
                {contacts.map(([n, name]) => (
                  <button key={n} onClick={() => game.dial(n)} className="w-full flex items-center gap-3 px-4 py-2.5 border-b border-white/5 active:bg-white/10 text-right">
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center text-white ${n === 'wife' ? 'bg-pink-700' : n === 'unknown' ? 'bg-zinc-700' : 'bg-sky-800'}`}>{name.slice(0, 1)}</div>
                    <div className="flex-1"><div className="text-white text-sm">{name}</div><div className="text-white/40 text-[10px]">{/^\d+$/.test(n) ? FA(n) : n === 'unknown' ? 'تماس بی‌پاسخ' : 'موبایل'}</div></div>
                    <span className="text-emerald-400">✆</span>
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center">
                <div className="h-10 text-white text-2xl tracking-widest" dir="ltr">{FA(num)}</div>
                <div className="grid grid-cols-3 gap-2.5 mt-2" dir="ltr">
                  {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((k) => (
                    <button key={k} onClick={() => setNum((v) => (v + k).slice(0, 11))} className="w-14 h-14 rounded-full bg-white/10 text-white text-xl active:bg-white/25">{FA(k)}</button>
                  ))}
                </div>
                <div className="flex gap-6 mt-3 items-center">
                  <button onClick={() => setNum((v) => v.slice(0, -1))} className="text-white/60 text-sm">⌫</button>
                  <button onClick={() => num && game.dial(num)} className="w-14 h-14 rounded-full bg-emerald-600 text-white text-2xl active:scale-95">✆</button>
                </div>
              </div>
            )}
            <div className="flex border-t border-white/10 text-[11px]">
              <button onClick={() => setTab('contacts')} className={`flex-1 py-2.5 ${tab === 'contacts' ? 'text-sky-400' : 'text-white/50'}`}>👤 مخاطبین</button>
              <button onClick={() => setTab('pad')} className={`flex-1 py-2.5 ${tab === 'pad' ? 'text-sky-400' : 'text-white/50'}`}>⌨ شماره‌گیر</button>
              <button onClick={() => game.closePhone()} className="flex-1 py-2.5 text-white/50">✕ بستن</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
