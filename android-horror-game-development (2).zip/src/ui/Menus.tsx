import { useState, useSyncExternalStore } from 'react';
import { settingsStore, ui, loadSave, getEndings, type Quality } from '../game/store';
import bg from '../assets/menu-bg.jpg';

const FA = (n: number | string) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);

function Slider({ label, value, min, max, step, onChange, fmt }: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; fmt?: (v: number) => string }) {
  return (
    <label className="flex items-center gap-3 py-1.5">
      <span className="w-36 text-sm text-white/75 shrink-0">{label}</span>
      <input type="range" className="flex-1" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} />
      <span className="w-12 text-xs text-white/55 text-left font-mono" dir="ltr">{fmt ? fmt(value) : value}</span>
    </label>
  );
}
function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)} className="flex items-center justify-between w-full py-2">
      <span className="text-sm text-white/75">{label}</span>
      <span className={`w-11 h-6 rounded-full relative transition ${value ? 'bg-red-700' : 'bg-white/15'}`}><span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all ${value ? 'left-0.5' : 'left-[22px]'}`} /></span>
    </button>
  );
}

export function SettingsPanel({ onClose, inGame }: { onClose: () => void; inGame?: boolean }) {
  const s = useSyncExternalStore(settingsStore.subscribe, settingsStore.get);
  const set = settingsStore.set;
  const pct = (v: number) => FA(Math.round(v * 100)) + '٪';
  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3" dir="rtl" onPointerDown={(e) => e.stopPropagation()}>
      <div className="w-[min(720px,96vw)] max-h-[92vh] overflow-y-auto rounded-xl bg-zinc-950/95 border border-white/10 p-5 shadow-2xl">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-xl font-bold text-white">تنظیمات</h2>
          <button onClick={onClose} className="px-4 py-1.5 rounded bg-red-800 text-white text-sm">بازگشت</button>
        </div>
        <div className="grid sm:grid-cols-2 gap-x-8">
          <div>
            <h3 className="text-xs text-red-400/80 mt-2 mb-1">گرافیک</h3>
            <div className="flex gap-2 py-1.5">
              {(['low', 'medium', 'high'] as Quality[]).map((q) => (
                <button key={q} onClick={() => set({ quality: q })} className={`flex-1 py-2 rounded text-sm border ${s.quality === q ? 'bg-red-800 border-red-500 text-white' : 'bg-white/5 border-white/10 text-white/70'}`}>{{ low: 'پایین', medium: 'متوسط', high: 'بالا' }[q]}</button>
              ))}
            </div>
            {inGame && <p className="text-[11px] text-white/40 mb-1">تغییر کیفیت از بارگذاری بعدی کامل اعمال می‌شود.</p>}
            <Slider label="میدان دید (FOV)" value={s.fov} min={55} max={100} step={1} onChange={(v) => set({ fov: v })} fmt={(v) => FA(v) + '°'} />
            <Slider label="رزولوشن رندر" value={s.resBoost} min={0.7} max={1.3} step={0.05} onChange={(v) => set({ resBoost: v })} fmt={pct} />
            <Slider label="وضوح و شارپنس" value={s.sharpen} min={0} max={1} step={0.05} onChange={(v) => set({ sharpen: v })} fmt={pct} />
            <p className="text-[11px] text-white/40 mb-1">رزولوشن به‌صورت خودکار با توان گوشی تنظیم می‌شود تا بازی روان بماند.</p>
            <Toggle label="نمایش FPS" value={s.showFps} onChange={(v) => set({ showFps: v })} />
            <h3 className="text-xs text-red-400/80 mt-3 mb-1">صدا</h3>
            <Slider label="صدای کلی" value={s.master} min={0} max={1} step={0.05} onChange={(v) => set({ master: v })} fmt={pct} />
            <Slider label="موسیقی و تنش" value={s.music} min={0} max={1} step={0.05} onChange={(v) => set({ music: v })} fmt={pct} />
            <Slider label="افکت‌ها و محیط" value={s.sfx} min={0} max={1} step={0.05} onChange={(v) => set({ sfx: v })} fmt={pct} />
          </div>
          <div>
            <h3 className="text-xs text-red-400/80 mt-2 mb-1">کنترل</h3>
            <Slider label="حساسیت دوربین" value={s.sensitivity} min={0.2} max={2.5} step={0.05} onChange={(v) => set({ sensitivity: v })} fmt={(v) => FA(v.toFixed(2))} />
            <Toggle label="معکوس کردن محور عمودی" value={s.invertY} onChange={(v) => set({ invertY: v })} />
            <Toggle label="حالت چپ‌دست (جابجایی کنترل‌ها)" value={s.leftHanded} onChange={(v) => set({ leftHanded: v })} />
            <Slider label="اندازه دکمه‌ها" value={s.btnScale} min={0.7} max={1.4} step={0.05} onChange={(v) => set({ btnScale: v })} fmt={pct} />
            <Slider label="شفافیت دکمه‌ها" value={s.btnOpacity} min={0.2} max={1} step={0.05} onChange={(v) => set({ btnOpacity: v })} fmt={pct} />
          </div>
        </div>
      </div>
    </div>
  );
}

const ENDING_LIST = [
  { id: 'truedawn', t: 'صبح', h: 'تا فصل ۱۰ دوام بیاور.' },
];
export const _OLD_ENDINGS = [
  { id: 'truedawn', t: 'سپیده‌ی واقعی (پایان کامل)', h: 'همه را آزاد کن، تا انتها برو و قرارداد پدرت را پاره کن.' },
  { id: 'awake', t: 'بیداری', h: 'تا فصل ۲۵ برو… اما همه را نجات نده.' },
  { id: 'manager', t: 'مدیر جدید', h: 'جای پدرت را بگیر.' },
  { id: 'release', t: 'رهایی (پایان واقعی)', h: 'نام‌ها را به صاحبانشان برگردان… و ریشه را بسوزان.' },
  { id: 'fire', t: 'آتش', h: 'حقیقت را کامل بدان… و بسوزانش.' },
  { id: 'dawn', t: 'سپیده‌دم', h: 'قوانین را رعایت کن و فرار کن.' },
  { id: 'passenger', t: 'مسافر', h: 'زیادی کنجکاو بودی.' },
  { id: 'eternal', t: 'شیفت ابدی', h: 'بعضی قراردادها را نباید امضا کرد.' },
];

export function MainMenu({ onNew, onContinue }: { onNew: () => void; onContinue: () => void }) {
  const [panel, setPanel] = useState<'none' | 'settings' | 'endings' | 'help'>('none');
  const save = loadSave();
  const endings = getEndings();
  return (
    <div className="fixed inset-0 z-40 overflow-hidden" dir="rtl">
      <img src={bg} className="menu-bg absolute inset-0 w-full h-full object-cover" alt="" />
      <div className="absolute inset-0 bg-gradient-to-l from-black/90 via-black/50 to-black/20" />
      <div className="absolute inset-y-0 right-0 flex flex-col justify-center pr-[7vw] gap-1">
        <div dir="ltr" className="title-flicker text-5xl sm:text-7xl font-black tracking-[0.25em] text-red-50 text-right" style={{ fontFamily: 'Impact, Arial Black, sans-serif' }}>NIGHT SHIFT</div>
        <div className="text-white/55 text-sm mb-6 tracking-widest">شیفت شب • یک داستان ترسناک</div>
        {save && (
          <button onClick={onContinue} className="menu-btn text-right text-xl py-2 text-white hover:text-red-300 transition">
            ادامه <span className="text-xs text-white/40 mr-2">فصل {FA(save.chapter)}</span>
          </button>
        )}
        <button onClick={onNew} className="text-right text-xl py-2 text-white hover:text-red-300 transition">{save ? 'شروع دوباره' : 'شروع بازی'}</button>
        <button onClick={() => setPanel('settings')} className="text-right text-xl py-2 text-white/85 hover:text-red-300 transition">تنظیمات</button>
        <button onClick={() => setPanel('endings')} className="text-right text-xl py-2 text-white/85 hover:text-red-300 transition">پایان‌ها <span className="text-xs text-white/40">{FA(endings.length)}/{FA(ENDING_LIST.length)}</span></button>
        <button onClick={() => setPanel('help')} className="text-right text-xl py-2 text-white/85 hover:text-red-300 transition">راهنما</button>
        <div className="mt-6 text-[11px] text-white/30">برای بهترین تجربه از هدفون استفاده کنید 🎧</div>
      </div>
      {panel === 'settings' && <SettingsPanel onClose={() => setPanel('none')} />}
      {panel === 'endings' && (
        <Modal title="پایان‌ها" onClose={() => setPanel('none')}>
          <div className="grid grid-cols-2 gap-3">
            {ENDING_LIST.map((e) => {
              const u = endings.includes(e.id);
              return (
                <div key={e.id} className={`p-4 rounded-lg border ${u ? 'border-red-700/60 bg-red-950/40' : 'border-white/10 bg-white/5'}`}>
                  <div className="font-bold text-white">{u ? e.t : '؟؟؟'}</div>
                  <div className="text-xs text-white/50 mt-1">{u ? 'کشف شده' : e.h}</div>
                </div>
              );
            })}
          </div>
        </Modal>
      )}
      {panel === 'help' && (
        <Modal title="راهنما" onClose={() => setPanel('none')}>
          <div className="text-sm leading-7 text-white/80 space-y-2">
            <p>🕹️ <b>سمت چپ صفحه:</b> جوی‌استیک حرکت (هرجا لمس کنید ظاهر می‌شود).</p>
            <p>👆 <b>سمت راست صفحه:</b> بکشید تا دوربین بچرخد. دکمه‌ها: ✋ تعامل، 🏃 دویدن (نگه دارید)، ⬇ خم شدن، 🔦 چراغ‌قوه، 🍾 پرتاب بطری.</p>
            <p>🔊 صداها را جدی بگیرید. دویدن و پرتاب اشیا صدا تولید می‌کنند؛ خم شدن بی‌صداست.</p>
            <p>🚪 می‌توانید درها را ببندید و در کمدها، توالت یا زیر پیشخوان مخفی شوید. هیچ مخفیگاهی کاملاً امن نیست.</p>
            <p>📼 دوربین‌های مداربسته همیشه حقیقت را نشان نمی‌دهند.</p>
            <p>💾 بازی در هر مرحله‌ی مأموریت به‌صورت خودکار ذخیره می‌شود.</p>
            <p className="text-white/50">رفتار شما در طول شب، پایان داستان را تعیین می‌کند.</p>
          </div>
        </Modal>
      )}
    </div>
  );
}

function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3" dir="rtl">
      <div className="w-[min(640px,94vw)] max-h-[90vh] overflow-y-auto rounded-xl bg-zinc-950/95 border border-white/10 p-5">
        <div className="flex items-center justify-between mb-4"><h2 className="text-xl font-bold text-white">{title}</h2><button onClick={onClose} className="px-4 py-1.5 rounded bg-red-800 text-white text-sm">بستن</button></div>
        {children}
      </div>
    </div>
  );
}

export function PauseMenu({ onResume, onQuit, onRestart }: { onResume: () => void; onQuit: () => void; onRestart: () => void }) {
  const [settings, setSettings] = useState(false);
  return (
    <div className="fixed inset-0 z-40 bg-black/75 backdrop-blur-sm flex items-center justify-center" dir="rtl" onPointerDown={(e) => e.stopPropagation()}>
      <div className="flex flex-col gap-2 w-64">
        <div className="text-2xl font-bold text-white mb-3 text-center">توقف</div>
        <button onClick={onResume} className="py-3 rounded bg-red-800 text-white">ادامه</button>
        <button onClick={() => setSettings(true)} className="py-3 rounded bg-white/10 text-white">تنظیمات</button>
        <button onClick={onRestart} className="py-3 rounded bg-white/10 text-white">بارگذاری آخرین نقطه‌ی ذخیره</button>
        <button onClick={onQuit} className="py-3 rounded bg-white/10 text-white/80">خروج به منوی اصلی</button>
        <p className="text-[11px] text-white/40 text-center mt-2">پیشرفت در آخرین مأموریت تکمیل‌شده ذخیره شده است.</p>
      </div>
      {settings && <SettingsPanel inGame onClose={() => setSettings(false)} />}
    </div>
  );
}

export function LoadingScreen() {
  const st = useSyncExternalStore(ui.subscribe, ui.get);
  if (!st.loading) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center" dir="rtl">
      <div className="text-2xl text-white/90 mb-6 tracking-wider">{st.loading.text}</div>
      <div className="w-64 h-[2px] bg-white/10 overflow-hidden"><div className="h-full bg-red-700 transition-all duration-300" style={{ width: `${st.loading.progress * 100}%` }} /></div>
      <div className="mt-8 text-sm text-white/40 italic">{st.loading.tip}</div>
    </div>
  );
}

export function EndingScreen({ onMenu }: { onMenu: () => void }) {
  const st = useSyncExternalStore(ui.subscribe, ui.get);
  const e = st.ending; if (!e) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center p-6" dir="rtl">
      <div className="max-w-2xl text-center fade-in">
        <div className="text-red-600/90 text-sm tracking-[0.4em] mb-3" dir="ltr">NIGHT SHIFT</div>
        <h1 className="text-4xl font-black text-white mb-6">{e.title}</h1>
        <p className="whitespace-pre-line leading-9 text-white/80 text-[15px]">{e.text}</p>
        <div className="mt-8 text-xs text-white/45">{e.stats}</div>
        <button onClick={onMenu} className="mt-8 px-8 py-3 rounded bg-red-800 text-white">منوی اصلی</button>
      </div>
    </div>
  );
}
