import { useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import { ui, settingsStore } from '../game/store';
import type { Game } from '../game/game';

function useNoiseUrl() {
  return useMemo(() => {
    const c = document.createElement('canvas'); c.width = c.height = 160;
    const x = c.getContext('2d')!; const d = x.createImageData(160, 160);
    for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; }
    x.putImageData(d, 0, 0); return c.toDataURL();
  }, []);
}

export function Overlays() {
  const noise = useNoiseUrl();
  const st = useSyncExternalStore(ui.subscribe, ui.get);
  const s = useSyncExternalStore(settingsStore.subscribe, settingsStore.get);
  return (
    <>
      {/* animated blended grain is expensive on mobile compositors → High quality only */}
      {s.quality === 'high' && <div className="grain z-[5]" style={{ backgroundImage: `url(${noise})` }} />}
      <div className="vignette z-[5]" />
      {st.chase && <div className="chase-vignette z-[6]" />}
    </>
  );
}

export function HUD({ game }: { game: Game }) {
  const st = useSyncExternalStore(ui.subscribe, ui.get);
  const s = useSyncExternalStore(settingsStore.subscribe, settingsStore.get);
  const [flash, setFlash] = useState(false);
  useEffect(() => { if (!st.objective) return; setFlash(true); const t = setTimeout(() => setFlash(false), 1500); return () => clearTimeout(t); }, [st.objectiveFlash, st.objective]);
  const noise = useNoiseUrl();
  const hideHud = st.cutscene || !!st.cctv;

  return (
    <div className="fixed inset-0 pointer-events-none z-20" dir="rtl">
      {/* top bar: clock + objective */}
      {!hideHud && st.objective && (
        <div className={`absolute top-3 right-3 max-w-[46vw] transition-all ${flash ? 'scale-105' : ''}`}>
          <div className="flex items-center gap-2 text-[11px] text-white/45 mb-1"><span>⏱ {st.clock}</span>{st.saving && <span className="text-emerald-300/80">● ذخیره شد</span>}</div>
          <div className={`text-[13px] sm:text-sm leading-6 px-3 py-1.5 rounded-md border-r-2 ${flash ? 'border-amber-300 bg-amber-900/40 text-amber-50' : 'border-white/40 bg-black/45 text-white/85'}`}>{st.objective}</div>
        </div>
      )}
      {!hideHud && !st.objective && st.saving && <div className="absolute top-3 right-3 text-xs text-emerald-300/80">● ذخیره شد</div>}
      {s.showFps && <div className="absolute top-3 left-16 text-[10px] text-lime-300/70 font-mono" dir="ltr">{st.fps} FPS • {st.resInfo}</div>}

      {/* crosshair + prompt */}
      {!hideHud && !st.dialogue && !st.note && (
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
          <div className={`rounded-full transition-all ${st.prompt ? 'w-2.5 h-2.5 bg-amber-300 shadow-[0_0_10px_rgba(255,200,90,0.9)]' : 'w-1.5 h-1.5 bg-white/40'}`} />
          {st.prompt && <div className="mt-4 px-3 py-1 rounded bg-black/60 text-amber-100 text-sm whitespace-nowrap border border-amber-200/20 fade-in">{st.prompt}</div>}
        </div>
      )}

      {/* stamina */}
      {!hideHud && st.stamina < 0.99 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-40 h-1 bg-white/10 rounded overflow-hidden">
          <div className={`h-full ${st.stamina < 0.25 ? 'bg-red-500/80' : 'bg-white/60'}`} style={{ width: `${st.stamina * 100}%` }} />
        </div>
      )}
      {st.hiding && <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_15%,rgba(0,0,0,0.92)_55%)]" />}
      {st.hiding && <div className="absolute top-1/3 left-1/2 -translate-x-1/2 text-white/40 text-xs">نفست را آرام نگه دار…</div>}

      {/* subtitle */}
      {st.subtitle && (
        <div className="absolute bottom-[22%] left-1/2 -translate-x-1/2 max-w-[70vw] text-center fade-in">
          <span className="inline-block px-4 py-1.5 rounded bg-black/65 text-[15px] leading-7 text-white/95">
            {st.subtitle.speaker && <b className="text-amber-200/90 ml-2">{st.subtitle.speaker}:</b>}
            {st.subtitle.speaker ? st.subtitle.text : <i className="text-white/80">{st.subtitle.text}</i>}
          </span>
        </div>
      )}

      {/* toast */}
      {st.toast && <div className="absolute top-20 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-full bg-white/10 border border-white/15 text-sm text-white/85 backdrop-blur fade-in">{st.toast}</div>}

      {/* phone message */}
      {st.message && (
        <div className="absolute top-6 left-1/2 -translate-x-1/2 w-[min(420px,80vw)] rounded-2xl bg-zinc-900/90 border border-white/10 shadow-2xl p-3 fade-in">
          <div className="flex items-center gap-2 text-[11px] text-white/50 mb-1"><span className="w-4 h-4 rounded bg-emerald-500 inline-block" /> پیام جدید • ناشناس • ۰۲:۰۰</div>
          <div className="text-[15px] text-white leading-7">{st.message}</div>
        </div>
      )}

      {/* chapter card */}
      {st.chapterCard && (
        <div className="absolute inset-0 flex flex-col items-center justify-center fade-in">
          <div className="text-3xl sm:text-4xl font-bold tracking-wide text-white/95 drop-shadow-[0_2px_10px_rgba(0,0,0,0.9)]">{st.chapterCard.title}</div>
          <div className="mt-3 text-sm text-white/60">{st.chapterCard.sub}</div>
        </div>
      )}

      {/* NIGHT SHIFT title */}
      {st.title && (
        <div className="absolute inset-0 flex flex-col items-center justify-center fade-in" dir="ltr">
          <div className="title-flicker text-5xl sm:text-7xl font-black tracking-[0.35em] text-red-50" style={{ fontFamily: 'Impact, Arial Black, sans-serif' }}>NIGHT SHIFT</div>
          <div className="mt-4 text-white/50 tracking-[0.5em] text-xs">شیفت شب</div>
        </div>
      )}

      {/* dialogue */}
      {st.dialogue && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-[min(760px,92vw)] pointer-events-auto fade-in">
          <div className="rounded-xl bg-black/80 border border-white/10 p-4 shadow-2xl">
            <div className="text-amber-200/90 text-sm mb-1">{st.dialogue.speaker}</div>
            <div className="text-white text-[15px] leading-7 mb-3 min-h-7">{st.dialogue.text}</div>
            <div className="grid grid-cols-2 gap-2">
              {st.dialogue.options.map((o) => (
                <button key={o.id} onClick={() => game.choose(o.id)} className="text-right px-3 py-2.5 rounded-lg bg-white/5 hover:bg-white/15 active:bg-white/20 border border-white/10 text-white/90 text-sm">{o.text}</button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* note */}
      {st.note && (
        <div className="absolute inset-0 bg-black/70 flex items-center justify-center pointer-events-auto fade-in">
          <div className="paper doc-paper relative w-[min(620px,88vw)] max-h-[86vh] overflow-y-auto rounded-sm px-8 pt-8 pb-6 rotate-[-0.8deg]">
            <div className="doc-tape" style={{ left: '12%' }} /><div className="doc-tape" style={{ right: '12%', transform: 'rotate(8deg)' }} />
            <div className="doc-ring" />
            {/(دفترچه|قرارداد|نامه)/.test(st.note.title) && <div className="doc-stamp">PETRO 24<br />محرمانه</div>}
            <div className="font-black text-lg mb-3 border-b-2 border-black/25 pb-2 text-stone-900">{st.note.title}</div>
            <div className="doc-lines whitespace-pre-line leading-8 text-[15px] text-[#1d2a5a] font-semibold">{st.note.body}</div>
            <button onClick={() => game.closeNote()} className="relative mt-5 px-6 py-2 rounded bg-stone-800 text-stone-100 text-sm">بستن</button>
          </div>
        </div>
      )}

      {/* CCTV */}
      {st.cctv && (
        <div className="absolute inset-0 pointer-events-auto">
          <div className="scanlines" />
          <div className="absolute inset-0 overflow-hidden"><div className="cctv-roll" /></div>
          {st.cctv.glitch && <div className="absolute inset-0 opacity-70 flex items-center justify-center" style={{ backgroundImage: `url(${noise})`, animation: 'grain 0.2s steps(4) infinite' }}><span className="bg-black px-4 py-2 text-xl font-mono text-white" dir="ltr">NO SIGNAL</span></div>}
          <div className="absolute top-4 right-4 font-mono text-white/90 text-sm" dir="ltr"><span className="rec-dot text-red-500">●</span> REC</div>
          <div className="absolute top-4 left-4 text-white/90 text-sm">{st.cctv.name}</div>
          <div className="absolute bottom-20 left-4 font-mono text-white/70 text-xs" dir="ltr">{st.clock} • PETRO-24 SECURITY</div>
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-3">
            <button onClick={() => game.cctvNext(1)} className="px-5 py-3 rounded bg-black/70 border border-white/20 text-white">◀ بعدی</button>
            <button onClick={() => game.closeCCTV()} className="px-5 py-3 rounded bg-red-900/70 border border-white/20 text-white">خروج</button>
            <button onClick={() => game.cctvNext(-1)} className="px-5 py-3 rounded bg-black/70 border border-white/20 text-white">قبلی ▶</button>
          </div>
        </div>
      )}

      {/* jumpscare / death */}
      {st.jumpscare > 0 && <div className="absolute inset-0 bg-red-900/30 shake" />}
      <div className="absolute inset-0 bg-black transition-none" style={{ opacity: st.fade }} />
      {st.dead && (
        <div className="absolute inset-0 flex flex-col items-center justify-center fade-in">
          <div className="text-5xl text-red-700 font-black tracking-widest">مُردی</div>
          <div className="mt-4 text-white/50 text-sm">بازگشت به آخرین نقطه‌ی ذخیره…</div>
        </div>
      )}
      {st.skippable && (
        <button onClick={() => game.story.skip()} className="absolute bottom-4 left-4 pointer-events-auto px-4 py-2 rounded bg-black/50 border border-white/20 text-white/70 text-sm">رد کردن ⏭</button>
      )}
    </div>
  );
}
