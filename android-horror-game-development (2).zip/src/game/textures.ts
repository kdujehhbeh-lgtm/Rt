// Procedural canvas textures + quality-aware material factory
import * as THREE from 'three';
import type { Quality } from './store';
import { gfx, hiCanvas, finishTex } from './gfx';

const cache = new Map<string, THREE.Texture>();
let rngSeed = 1;
const rnd = () => { rngSeed = (rngSeed * 16807) % 2147483647; return (rngSeed - 1) / 2147483646; };

function canvasTex(key: string, w: number, h: number, draw: (c: CanvasRenderingContext2D, w: number, h: number) => void, repeat?: [number, number], srgb = true) {
  const k = key + '@' + gfx.texScale;
  if (cache.has(k)) return cache.get(k)!;
  // supersampled canvas: identical artwork, texScale× more pixels (sharper text, edges, grain)
  const { cv, c } = hiCanvas(w, h);
  rngSeed = key.length * 997 + 13;
  draw(c, w, h);
  const t = finishTex(new THREE.CanvasTexture(cv), srgb);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (repeat) t.repeat.set(repeat[0], repeat[1]);
  cache.set(k, t);
  return t;
}

function speckle(c: CanvasRenderingContext2D, w: number, h: number, n: number, col: string, min: number, max: number, alpha = 0.3) {
  c.fillStyle = col;
  for (let i = 0; i < n; i++) {
    c.globalAlpha = rnd() * alpha;
    const s = min + rnd() * (max - min);
    c.fillRect(rnd() * w, rnd() * h, s, s);
  }
  c.globalAlpha = 1;
}

export const tex = {
  asphalt: () => canvasTex('asphalt', 512, 512, (c, w, h) => {
    c.fillStyle = '#2a2a2c'; c.fillRect(0, 0, w, h);
    speckle(c, w, h, 9000, '#000', 1, 3, 0.5); speckle(c, w, h, 6000, '#777', 1, 2, 0.35);
    c.strokeStyle = 'rgba(10,10,10,0.7)'; c.lineWidth = 1.5;
    for (let i = 0; i < 7; i++) { c.beginPath(); let x = rnd() * w, y = rnd() * h; c.moveTo(x, y); for (let j = 0; j < 8; j++) { x += (rnd() - 0.5) * 60; y += (rnd() - 0.5) * 60; c.lineTo(x, y); } c.stroke(); }
    for (let i = 0; i < 5; i++) { const g = c.createRadialGradient(rnd() * w, rnd() * h, 0, rnd() * w, rnd() * h, 120); g.addColorStop(0, 'rgba(0,0,0,0.25)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h); }
  }),
  concrete: () => canvasTex('concrete', 512, 512, (c, w, h) => {
    c.fillStyle = '#6d6b66'; c.fillRect(0, 0, w, h);
    speckle(c, w, h, 8000, '#3b3a37', 1, 3, 0.4); speckle(c, w, h, 4000, '#9a9790', 1, 2, 0.3);
    c.strokeStyle = 'rgba(30,30,30,0.6)'; c.lineWidth = 2;
    c.strokeRect(0, 0, w, h); c.beginPath(); c.moveTo(w / 2, 0); c.lineTo(w / 2, h); c.moveTo(0, h / 2); c.lineTo(w, h / 2); c.stroke();
    for (let i = 0; i < 6; i++) { const x = rnd() * w, y = rnd() * h; const g = c.createRadialGradient(x, y, 0, x, y, 40 + rnd() * 80); g.addColorStop(0, 'rgba(20,15,10,0.35)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h); }
  }),
  tiles: () => canvasTex('tiles', 512, 512, (c, w, h) => {
    const n = 4, s = w / n;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      const v = 200 + Math.floor(rnd() * 25) - ((i + j) % 2) * 18;
      c.fillStyle = `rgb(${v},${v - 4},${v - 12})`; c.fillRect(i * s, j * s, s, s);
    }
    speckle(c, w, h, 5000, '#5a5040', 1, 3, 0.25);
    c.strokeStyle = '#6d665a'; c.lineWidth = 4;
    for (let i = 0; i <= n; i++) { c.beginPath(); c.moveTo(i * s, 0); c.lineTo(i * s, h); c.moveTo(0, i * s); c.lineTo(w, i * s); c.stroke(); }
    for (let i = 0; i < 8; i++) { const x = rnd() * w, y = rnd() * h; const g = c.createRadialGradient(x, y, 0, x, y, 60); g.addColorStop(0, 'rgba(60,45,20,0.25)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h); }
  }),
  plaster: (col = '#b9b4a6', key = 'p') => canvasTex('plaster' + key + col, 256, 256, (c, w, h) => {
    c.fillStyle = col; c.fillRect(0, 0, w, h);
    speckle(c, w, h, 4000, '#000', 1, 2, 0.12); speckle(c, w, h, 2000, '#fff', 1, 2, 0.08);
    const g = c.createLinearGradient(0, h, 0, h * 0.6); g.addColorStop(0, 'rgba(40,30,20,0.45)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
    for (let i = 0; i < 5; i++) { c.fillStyle = `rgba(60,50,30,${rnd() * 0.15})`; const x = rnd() * w; c.fillRect(x, rnd() * h * 0.3, 2 + rnd() * 3, h); }
  }),
  wood: () => canvasTex('wood', 512, 512, (c, w, h) => {
    const planks = 6; const ph = h / planks;
    for (let i = 0; i < planks; i++) {
      const b = 70 + rnd() * 30; c.fillStyle = `rgb(${b + 30},${b},${b - 30})`; c.fillRect(0, i * ph, w, ph);
      c.strokeStyle = 'rgba(30,15,5,0.35)';
      for (let j = 0; j < 14; j++) { c.beginPath(); const y = i * ph + rnd() * ph; c.moveTo(0, y); c.bezierCurveTo(w * 0.3, y + rnd() * 6 - 3, w * 0.6, y + rnd() * 6 - 3, w, y); c.stroke(); }
      c.fillStyle = 'rgba(20,10,0,0.8)'; c.fillRect(0, i * ph, w, 2); c.fillRect(rnd() * w, i * ph, 2, ph);
    }
  }),
  products: (seed = 0) => canvasTex('products' + seed, 512, 256, (c, w, h) => {
    rngSeed = 77 + seed * 131;
    c.fillStyle = '#222'; c.fillRect(0, 0, w, h);
    const rows = 3; const rh = h / rows;
    const palette = ['#c0392b', '#e67e22', '#f1c40f', '#27ae60', '#2980b9', '#8e44ad', '#ecf0f1', '#d35400', '#16a085', '#7f1d1d'];
    for (let r = 0; r < rows; r++) {
      let x = 2;
      while (x < w) {
        const pw = 18 + rnd() * 28; const phh = rh * (0.55 + rnd() * 0.35);
        const col = palette[Math.floor(rnd() * palette.length)];
        c.fillStyle = col; c.fillRect(x, r * rh + rh - phh - 6, pw - 3, phh);
        c.fillStyle = 'rgba(255,255,255,0.5)'; c.fillRect(x + 3, r * rh + rh - phh, pw - 9, 4);
        c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(x + pw - 7, r * rh + rh - phh - 6, 4, phh);
        x += pw;
      }
      c.fillStyle = '#888'; c.fillRect(0, r * rh + rh - 6, w, 6);
      c.fillStyle = '#fff'; for (let k = 0; k < 8; k++) c.fillRect(k * 64 + 20, r * rh + rh - 5, 14, 4);
    }
  }),
  drinks: () => canvasTex('drinks', 256, 512, (c, w, h) => {
    c.fillStyle = '#e8f4ff'; c.fillRect(0, 0, w, h);
    const rows = 5; const rh = h / rows;
    const cols = ['#c0392b', '#2ecc71', '#f39c12', '#3498db', '#1a1a1a', '#9b59b6'];
    for (let r = 0; r < rows; r++) {
      const col = cols[Math.floor(rnd() * cols.length)];
      for (let x = 6; x < w - 20; x += 26) {
        if (rnd() < 0.12) continue;
        c.fillStyle = col; c.fillRect(x, r * rh + 18, 20, rh - 30);
        c.fillRect(x + 6, r * rh + 8, 8, 12);
        c.fillStyle = 'rgba(255,255,255,0.6)'; c.fillRect(x + 2, r * rh + 40, 16, 12);
        c.fillStyle = col;
      }
      c.fillStyle = '#9aa'; c.fillRect(0, r * rh + rh - 8, w, 8);
    }
  }),
  sign: (text: string, bg = '#111', fg = '#fff', w = 512, h = 128, font = 'bold 72px Arial') => canvasTex('sign' + text + bg + fg + w, w, h, (c) => {
    c.fillStyle = bg; c.fillRect(0, 0, w, h);
    c.fillStyle = fg; c.font = font; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText(text, w / 2, h / 2 + 4);
    speckle(c, w, h, 600, '#000', 1, 3, 0.4);
  }),
  glow: () => canvasTex('glow', 128, 128, (c, w, h) => {
    const g = c.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
    g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.3, 'rgba(255,255,255,0.35)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
  }),
  cone: () => canvasTex('cone', 64, 128, (c, w, h) => {
    const g = c.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, 'rgba(255,255,255,0.55)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
  }),
  mist: () => canvasTex('mist', 256, 256, (c, w, h) => {
    c.clearRect(0, 0, w, h);
    for (let i = 0; i < 40; i++) {
      const x = rnd() * w, y = rnd() * h, r = 30 + rnd() * 70;
      const g = c.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, 'rgba(255,255,255,0.12)'); g.addColorStop(1, 'rgba(255,255,255,0)');
      c.fillStyle = g; c.fillRect(0, 0, w, h);
    }
  }),
  metal: () => canvasTex('metal', 256, 256, (c, w, h) => {
    c.fillStyle = '#8a8d90'; c.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y++) { c.fillStyle = `rgba(255,255,255,${rnd() * 0.06})`; c.fillRect(0, y, w, 1); }
    speckle(c, w, h, 800, '#4a3020', 2, 6, 0.3);
  }),
  grass: () => canvasTex('grass', 256, 256, (c, w, h) => {
    c.fillStyle = '#1d2216'; c.fillRect(0, 0, w, h);
    speckle(c, w, h, 6000, '#33402a', 1, 3, 0.6); speckle(c, w, h, 3000, '#0a0d07', 1, 3, 0.6);
  }),
  ceiling: () => canvasTex('ceiling', 256, 256, (c, w, h) => {
    c.fillStyle = '#c8c4b8'; c.fillRect(0, 0, w, h);
    speckle(c, w, h, 3000, '#777', 1, 2, 0.3);
    c.strokeStyle = '#8a857a'; c.lineWidth = 4; c.strokeRect(0, 0, w, h);
    const g = c.createRadialGradient(w * 0.7, h * 0.3, 0, w * 0.7, h * 0.3, 60); g.addColorStop(0, 'rgba(110,80,30,0.45)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h);
  }),
};

export function repeatTex(t: THREE.Texture, rx: number, ry: number) {
  const c = t.clone(); c.repeat.set(rx, ry); c.needsUpdate = true; return c;
}

// ---------------- Material factory ----------------
let quality: Quality = 'medium';
export function setMaterialQuality(q: Quality) { quality = q; }
export function getQuality() { return quality; }
const matCache = new Map<string, THREE.Material>();

export interface MatOpts { color?: number | string; map?: THREE.Texture; rough?: number; metal?: number; emissive?: number | string; emissiveIntensity?: number; transparent?: boolean; opacity?: number; side?: THREE.Side; key?: string; bump?: boolean }

export function mat(o: MatOpts): THREE.Material {
  const key = o.key ? o.key + quality : JSON.stringify({ ...o, map: o.map?.uuid }) + quality;
  if (matCache.has(key)) return matCache.get(key)!;
  let m: THREE.Material;
  if (quality === 'low') {
    m = new THREE.MeshLambertMaterial({
      color: o.color ?? 0xffffff, map: o.map ?? null, emissive: (o.emissive ?? 0x000000) as any,
      emissiveIntensity: o.emissiveIntensity ?? 1, transparent: o.transparent ?? false, opacity: o.opacity ?? 1, side: o.side ?? THREE.FrontSide,
    });
  } else {
    const sm = new THREE.MeshStandardMaterial({
      color: o.color ?? 0xffffff, map: o.map ?? null, roughness: o.rough ?? 0.8, metalness: o.metal ?? 0,
      emissive: (o.emissive ?? 0x000000) as any, emissiveIntensity: o.emissiveIntensity ?? 1,
      transparent: o.transparent ?? false, opacity: o.opacity ?? 1, side: o.side ?? THREE.FrontSide,
    });
    if (quality === 'high' && o.bump && o.map) { sm.bumpMap = o.map; sm.bumpScale = 0.6; }
    m = sm;
  }
  matCache.set(key, m);
  return m;
}
export function clearMaterialCache() { matCache.forEach((m) => m.dispose()); matCache.clear(); }

export function basic(color: number, opts: Partial<THREE.MeshBasicMaterialParameters> = {}) {
  return new THREE.MeshBasicMaterial({ color, ...opts });
}
