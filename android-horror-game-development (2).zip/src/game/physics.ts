// 2.5D collision world (AABBs on XZ with Y ranges), line of sight and waypoint navigation
import * as THREE from 'three';

export interface Box {
  minX: number; maxX: number; minZ: number; maxZ: number;
  minY: number; maxY: number;
  enabled: boolean;
  sight: boolean; // blocks line of sight
  door?: boolean;
  tag?: string;
}

export class Collision {
  boxes: Box[] = [];
  add(minX: number, maxX: number, minZ: number, maxZ: number, opts: Partial<Box> = {}): Box {
    const b: Box = { minX, maxX, minZ, maxZ, minY: -0.5, maxY: 4, enabled: true, sight: true, ...opts };
    this.boxes.push(b);
    return b;
  }
  addCentered(x: number, z: number, w: number, d: number, opts: Partial<Box> = {}) {
    return this.add(x - w / 2, x + w / 2, z - d / 2, z + d / 2, opts);
  }

  resolve(pos: THREE.Vector3, r: number, height = 1.7) {
    for (let iter = 0; iter < 2; iter++) {
      for (const b of this.boxes) {
        if (!b.enabled) continue;
        if (pos.x + r < b.minX || pos.x - r > b.maxX || pos.z + r < b.minZ || pos.z - r > b.maxZ) continue;
        if (pos.y + height < b.minY || pos.y > b.maxY - 0.05) continue;
        const cx = Math.max(b.minX, Math.min(pos.x, b.maxX));
        const cz = Math.max(b.minZ, Math.min(pos.z, b.maxZ));
        let dx = pos.x - cx, dz = pos.z - cz;
        const d2 = dx * dx + dz * dz;
        if (d2 > r * r) continue;
        if (d2 > 1e-8) {
          const d = Math.sqrt(d2);
          pos.x = cx + (dx / d) * r; pos.z = cz + (dz / d) * r;
        } else {
          // inside: push along smallest penetration
          const l = pos.x - b.minX, rr = b.maxX - pos.x, t = pos.z - b.minZ, bb = b.maxZ - pos.z;
          const m = Math.min(l, rr, t, bb);
          if (m === l) pos.x = b.minX - r; else if (m === rr) pos.x = b.maxX + r; else if (m === t) pos.z = b.minZ - r; else pos.z = b.maxZ + r;
        }
      }
    }
  }

  /** segment vs boxes. inflate expands boxes; ignoreDoors treats doors as passable */
  segmentBlocked(ax: number, az: number, bx: number, bz: number, y = 1.4, opts: { inflate?: number; ignoreDoors?: boolean; sightOnly?: boolean } = {}): Box | null {
    const inf = opts.inflate ?? 0;
    const dx = bx - ax, dz = bz - az;
    // broad phase: segment bounding box
    const sx0 = Math.min(ax, bx) - inf, sx1 = Math.max(ax, bx) + inf, sz0 = Math.min(az, bz) - inf, sz1 = Math.max(az, bz) + inf;
    for (const b of this.boxes) {
      if (!b.enabled) continue;
      if (b.maxX < sx0 || b.minX > sx1 || b.maxZ < sz0 || b.minZ > sz1) continue;
      if (opts.sightOnly && !b.sight) continue;
      if (opts.ignoreDoors && b.door) continue;
      if (y < b.minY || y > b.maxY) continue;
      let t0 = 0, t1 = 1;
      const minX = b.minX - inf, maxX = b.maxX + inf, minZ = b.minZ - inf, maxZ = b.maxZ + inf;
      if (Math.abs(dx) < 1e-9) { if (ax < minX || ax > maxX) continue; }
      else {
        let ta = (minX - ax) / dx, tb = (maxX - ax) / dx; if (ta > tb) [ta, tb] = [tb, ta];
        t0 = Math.max(t0, ta); t1 = Math.min(t1, tb); if (t0 > t1) continue;
      }
      if (Math.abs(dz) < 1e-9) { if (az < minZ || az > maxZ) continue; }
      else {
        let ta = (minZ - az) / dz, tb = (maxZ - az) / dz; if (ta > tb) [ta, tb] = [tb, ta];
        t0 = Math.max(t0, ta); t1 = Math.min(t1, tb); if (t0 > t1) continue;
      }
      return b;
    }
    return null;
  }

  los(a: THREE.Vector3, b: THREE.Vector3, y = 1.4) {
    return !this.segmentBlocked(a.x, a.z, b.x, b.z, y, { sightOnly: true });
  }
}

export interface NavNode { x: number; z: number; y: number; links: number[]; tag?: string }

export class NavGraph {
  nodes: NavNode[] = [];
  add(x: number, z: number, y = 0, tag?: string) { this.nodes.push({ x, z, y, links: [], tag }); return this.nodes.length - 1; }
  build(col: Collision, maxDist = 13) {
    const n = this.nodes;
    for (let i = 0; i < n.length; i++) for (let j = i + 1; j < n.length; j++) {
      const a = n[i], b = n[j];
      if (Math.abs(a.y - b.y) > 1) continue;
      const d = Math.hypot(a.x - b.x, a.z - b.z);
      if (d > maxDist) continue;
      if (col.segmentBlocked(a.x, a.z, b.x, b.z, a.y + 0.5, { inflate: 0.22, ignoreDoors: true })) continue;
      a.links.push(j); b.links.push(i);
    }
  }
  nearest(x: number, z: number, col?: Collision, y = 0): number {
    let best = -1, bd = Infinity;
    for (let i = 0; i < this.nodes.length; i++) {
      const nd = this.nodes[i];
      if (Math.abs(nd.y - y) > 1.5) continue;
      const d = (nd.x - x) ** 2 + (nd.z - z) ** 2;
      if (d < bd) {
        if (col && col.segmentBlocked(x, z, nd.x, nd.z, y + 0.5, { ignoreDoors: true, inflate: 0.1 })) continue;
        bd = d; best = i;
      }
    }
    if (best < 0) {
      for (let i = 0; i < this.nodes.length; i++) { const nd = this.nodes[i]; const d = (nd.x - x) ** 2 + (nd.z - z) ** 2; if (d < bd) { bd = d; best = i; } }
    }
    return best;
  }
  findTag(tag: string) { return this.nodes.findIndex((n) => n.tag === tag); }
  path(from: number, to: number): number[] {
    if (from < 0 || to < 0) return [];
    if (from === to) return [to];
    const n = this.nodes;
    const g = new Array(n.length).fill(Infinity); const prev = new Array(n.length).fill(-1);
    const open = new Set<number>([from]); g[from] = 0;
    const h = (i: number) => Math.hypot(n[i].x - n[to].x, n[i].z - n[to].z);
    while (open.size) {
      let cur = -1, bf = Infinity;
      open.forEach((i) => { const f = g[i] + h(i); if (f < bf) { bf = f; cur = i; } });
      if (cur === to) break;
      open.delete(cur);
      for (const nb of n[cur].links) {
        const ng = g[cur] + Math.hypot(n[cur].x - n[nb].x, n[cur].z - n[nb].z);
        if (ng < g[nb]) { g[nb] = ng; prev[nb] = cur; open.add(nb); }
      }
    }
    if (prev[to] < 0) return [];
    const p: number[] = []; let c = to;
    while (c !== from && c >= 0) { p.unshift(c); c = prev[c]; }
    return p;
  }
}
