// Global graphics knobs: texture supersampling & anisotropic filtering (set from the quality preset)
import * as THREE from 'three';
import type { Quality } from './store';

export const gfx = { texScale: 1, aniso: 4, maxAniso: 4 };

export function setGfxQuality(q: Quality, renderer?: THREE.WebGLRenderer) {
  if (renderer) gfx.maxAniso = Math.max(1, renderer.capabilities.getMaxAnisotropy());
  gfx.texScale = q === 'high' ? 2 : q === 'medium' ? 1.5 : 1.25;
  gfx.aniso = Math.min(gfx.maxAniso, q === 'high' ? 16 : q === 'medium' ? 8 : 4);
}

/** supersampled 2D canvas: callers draw in logical units (w × h), pixels are texScale × denser */
export function hiCanvas(w: number, h: number, scale = gfx.texScale) {
  const cv = document.createElement('canvas');
  cv.width = Math.max(1, Math.round(w * scale)); cv.height = Math.max(1, Math.round(h * scale));
  const c = cv.getContext('2d')!;
  c.setTransform(cv.width / w, 0, 0, cv.height / h, 0, 0);
  c.imageSmoothingQuality = 'high';
  return { cv, c };
}

/** standard settings for every generated texture */
export function finishTex<T extends THREE.Texture>(t: T, srgb = true): T {
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = gfx.aniso;
  t.minFilter = THREE.LinearMipmapLinearFilter; t.magFilter = THREE.LinearFilter; t.generateMipmaps = true;
  return t;
}
