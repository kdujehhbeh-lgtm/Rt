// Procedural "art" textures: horror posters, packaging, food, flesh/fur, pegboard, plates, gauges
import * as THREE from 'three';
import { photoPoster } from './posters';
import { gfx, hiCanvas, finishTex } from './gfx';

const cache = new Map<string, THREE.CanvasTexture>();
let seed = 1;
const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };

function make(key: string, w: number, h: number, draw: (c: CanvasRenderingContext2D, w: number, h: number) => void, srgb = true) {
  const k = key + w + 'x' + h + '@' + gfx.texScale;
  const hit = cache.get(k); if (hit) return hit;
  const { cv, c } = hiCanvas(w, h);
  seed = 1; for (let i = 0; i < key.length; i++) seed = (seed * 31 + key.charCodeAt(i)) % 2147483647; seed = seed || 7;
  draw(c, w, h);
  const t = finishTex(new THREE.CanvasTexture(cv), srgb);
  cache.set(k, t);
  return t;
}

const FONT = 'Vazirmatn, Tahoma, Arial, sans-serif';
function txt(c: CanvasRenderingContext2D, s: string, x: number, y: number, size: number, color: string, weight = 'bold', align: CanvasTextAlign = 'center') {
  c.font = `${weight} ${size}px ${FONT}`; c.fillStyle = color; c.textAlign = align; c.textBaseline = 'middle';
  c.direction = /[\u0600-\u06FF]/.test(s) ? 'rtl' : 'ltr';
  c.fillText(s, x, y);
  c.direction = 'ltr';
}
function grime(c: CanvasRenderingContext2D, w: number, h: number, n = 10, a = 0.25) {
  for (let i = 0; i < n; i++) {
    const x = rnd() * w, y = rnd() * h, r = 20 + rnd() * w * 0.25;
    const g = c.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(70,50,20,${a * rnd()})`); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
  }
  for (let i = 0; i < w * h / 300; i++) { c.fillStyle = `rgba(0,0,0,${rnd() * 0.12})`; c.fillRect(rnd() * w, rnd() * h, 1 + rnd() * 2, 1 + rnd() * 2); }
}
function tape(c: CanvasRenderingContext2D, x: number, y: number, rot: number) {
  c.save(); c.translate(x, y); c.rotate(rot); c.fillStyle = 'rgba(230,225,190,0.75)'; c.fillRect(-28, -9, 56, 18); c.restore();
}
function drip(c: CanvasRenderingContext2D, x: number, y: number, len: number, wdt: number, col: string) {
  c.fillStyle = col; c.beginPath(); c.moveTo(x - wdt, y); c.lineTo(x + wdt, y); c.lineTo(x + wdt * 0.4, y + len); c.arc(x, y + len, wdt * 0.6, 0, Math.PI); c.closePath(); c.fill();
}

export type FaceVariant = 'normal' | 'scratched' | 'hollow' | 'faceless' | 'grin';
/** greyscale "photocopy" portrait */
export function drawFace(c: CanvasRenderingContext2D, cx: number, cy: number, s: number, v: FaceVariant, female = false) {
  const bg = c.createLinearGradient(cx, cy - s, cx, cy + s); bg.addColorStop(0, '#9a9a96'); bg.addColorStop(1, '#5a5a58');
  c.fillStyle = bg; c.fillRect(cx - s * 0.9, cy - s, s * 1.8, s * 2);
  c.fillStyle = '#262626'; c.beginPath(); c.ellipse(cx, cy + s * 1.15, s * 0.85, s * 0.55, 0, Math.PI, 0); c.fill();
  c.fillStyle = '#7d7d7a'; c.fillRect(cx - s * 0.15, cy + s * 0.4, s * 0.3, s * 0.35);
  if (female) { c.fillStyle = '#161616'; c.beginPath(); c.ellipse(cx, cy + s * 0.05, s * 0.52, s * 0.72, 0, 0, Math.PI * 2); c.fill(); }
  const g = c.createRadialGradient(cx - s * 0.12, cy - s * 0.15, s * 0.05, cx, cy, s * 0.6);
  g.addColorStop(0, v === 'faceless' ? '#e2e0da' : '#c9c7c2'); g.addColorStop(1, '#6e6d69');
  c.fillStyle = g; c.beginPath(); c.ellipse(cx, cy, s * 0.38, s * 0.5, 0, 0, Math.PI * 2); c.fill();
  c.fillStyle = '#151515'; c.beginPath(); c.ellipse(cx, cy - s * 0.32, s * 0.41, s * 0.24, 0, Math.PI, 0); c.fill();
  if (v === 'faceless') { c.fillStyle = 'rgba(0,0,0,0.12)'; c.beginPath(); c.ellipse(cx, cy + s * 0.05, s * 0.2, s * 0.3, 0, 0, Math.PI * 2); c.fill(); return; }
  const ey = cy - s * 0.04, ex = s * 0.15;
  for (const sx of [-1, 1]) {
    if (v === 'hollow') {
      c.fillStyle = '#000'; c.beginPath(); c.ellipse(cx + sx * ex, ey, s * 0.085, s * 0.1, 0, 0, Math.PI * 2); c.fill();
      drip(c, cx + sx * ex, ey + s * 0.05, s * (0.25 + rnd() * 0.3), s * 0.025, '#0a0a0a');
    } else {
      c.fillStyle = '#e8e8e6'; c.beginPath(); c.ellipse(cx + sx * ex, ey, s * 0.07, s * 0.035, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#111'; c.beginPath(); c.arc(cx + sx * ex, ey, s * 0.028, 0, Math.PI * 2); c.fill();
      c.strokeStyle = '#3a3a3a'; c.lineWidth = s * 0.02; c.beginPath(); c.moveTo(cx + sx * ex - s * 0.08, ey - s * 0.07); c.lineTo(cx + sx * ex + s * 0.07, ey - s * 0.08); c.stroke();
    }
  }
  c.strokeStyle = '#4a4a48'; c.lineWidth = s * 0.02; c.beginPath(); c.moveTo(cx, ey + s * 0.02); c.lineTo(cx - s * 0.03, cy + s * 0.15); c.lineTo(cx + s * 0.02, cy + s * 0.17); c.stroke();
  if (v === 'grin') {
    c.fillStyle = '#000'; c.beginPath(); c.moveTo(cx - s * 0.3, cy + s * 0.2); c.quadraticCurveTo(cx, cy + s * 0.55, cx + s * 0.3, cy + s * 0.2); c.quadraticCurveTo(cx, cy + s * 0.35, cx - s * 0.3, cy + s * 0.2); c.fill();
    c.fillStyle = '#ddd'; for (let i = -5; i <= 5; i++) c.fillRect(cx + i * s * 0.045 - s * 0.012, cy + s * 0.27 + Math.abs(i) * -s * 0.008, s * 0.024, s * 0.05);
  } else { c.strokeStyle = '#2a2a2a'; c.lineWidth = s * 0.025; c.beginPath(); c.moveTo(cx - s * 0.12, cy + s * 0.27); c.quadraticCurveTo(cx, cy + s * 0.25, cx + s * 0.12, cy + s * 0.27); c.stroke(); }
  if (v === 'scratched') {
    c.strokeStyle = 'rgba(10,10,10,0.95)'; c.lineWidth = s * 0.035;
    for (let k = 0; k < 14; k++) { c.beginPath(); c.moveTo(cx - s * 0.28 + rnd() * s * 0.1, ey + (rnd() - 0.5) * s * 0.15); c.lineTo(cx + s * 0.28 - rnd() * s * 0.1, ey + (rnd() - 0.5) * s * 0.15); c.stroke(); }
    c.strokeStyle = 'rgba(140,0,0,0.9)'; c.lineWidth = s * 0.02;
    for (let k = 0; k < 6; k++) { c.beginPath(); c.moveTo(cx - s * 0.3, ey + (rnd() - 0.5) * s * 0.2); c.lineTo(cx + s * 0.3, ey + (rnd() - 0.5) * s * 0.2); c.stroke(); }
  }
}

export type PosterKind = 'missing' | 'missingMe' | 'dontlook' | 'tall' | 'dog' | 'hiring' | 'rules' | 'smile' | 'flyer';
const NAMES = ['محمد رضایی', 'سارا کریمی', 'علی نوروزی', 'رضا احمدی', 'مریم صادقی', 'حسین یزدانی'];

export const art = {
  /** high quality photo posters (see posters.ts) */
  poster(kind: PosterKind, variant = 0, aged = false): THREE.Texture {
    return photoPoster(kind, variant, aged);
  },
  /** legacy fully-procedural poster (kept as fallback) */
  posterProcedural(kind: PosterKind, variant = 0, aged = false) {
    return make(`poster-${kind}-${variant}-${aged}`, 256, 360, (c, w, h) => {
      const paper = kind === 'tall' || kind === 'smile' ? '#141414' : kind === 'dontlook' ? '#d9d2bb' : '#e9e3cd';
      c.fillStyle = paper; c.fillRect(0, 0, w, h);
      if (kind === 'missing' || kind === 'missingMe' || kind === 'flyer') {
        txt(c, 'گمشده', w / 2, 40, 52, '#a01010', '900');
        txt(c, 'MISSING', w / 2, 80, 20, '#222', 'bold');
        c.fillStyle = '#222'; c.fillRect(48, 96, 160, 150);
        const fv: FaceVariant = kind === 'missingMe' ? 'faceless' : aged ? (variant % 2 ? 'hollow' : 'scratched') : 'normal';
        drawFace(c, w / 2, 172, 72, fv, variant % 3 === 1);
        const name = kind === 'missingMe' ? 'کارمند جدید شیفت شب' : NAMES[variant % NAMES.length];
        txt(c, name, w / 2, 268, 20, '#111');
        txt(c, kind === 'missingMe' ? 'آخرین بار: امشب، ساعت ۳' : 'آخرین بار دیده شده:', w / 2, 296, 13, '#333', 'normal');
        txt(c, 'پمپ بنزین پترو ۲۴ — شیفت شب', w / 2, 316, 13, '#333', 'bold');
        txt(c, '☎ ۰۹۱۲ ۰۰۰ ۰۰۲۴', w / 2, 342, 14, '#111');
        for (let i = 0; i < 8; i++) { c.fillStyle = paper; c.fillRect(i * 32 + 4, h - 6, 26, 6); }
      } else if (kind === 'dontlook') {
        c.fillStyle = '#000'; c.beginPath(); c.ellipse(w / 2, 130, 90, 50, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#d9d2bb'; c.beginPath(); c.ellipse(w / 2, 130, 70, 36, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#000'; c.beginPath(); c.arc(w / 2, 130, 26, 0, Math.PI * 2); c.fill();
        c.strokeStyle = '#a00'; c.lineWidth = 14; c.beginPath(); c.moveTo(40, 60); c.lineTo(216, 200); c.moveTo(216, 60); c.lineTo(40, 200); c.stroke();
        txt(c, 'به صورتش', w / 2, 250, 38, '#8a0000', '900');
        txt(c, 'نگاه نکن', w / 2, 296, 38, '#8a0000', '900');
        for (let i = 0; i < 6; i++) drip(c, 50 + rnd() * 160, 312, 10 + rnd() * 40, 3, '#7a0000');
      } else if (kind === 'tall') {
        const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#2a2e33'); g.addColorStop(1, '#0a0a0a'); c.fillStyle = g; c.fillRect(0, 0, w, h);
        c.fillStyle = 'rgba(200,200,210,0.12)'; for (let i = 0; i < 30; i++) c.fillRect(rnd() * w, 180 + rnd() * 120, 60, 3);
        c.fillStyle = '#000'; c.fillRect(w / 2 - 8, 70, 16, 210); c.beginPath(); c.ellipse(w / 2, 62, 13, 18, 0, 0, Math.PI * 2); c.fill();
        c.fillRect(w / 2 - 18, 90, 6, 150); c.fillRect(w / 2 + 12, 90, 6, 150);
        c.fillStyle = '#fff'; c.fillRect(w / 2 - 6, 58, 3, 3); c.fillRect(w / 2 + 3, 58, 3, 3);
        txt(c, 'او همیشه', w / 2, 310, 30, '#d8d8d8', '900'); txt(c, 'کنار جاده است', w / 2, 342, 24, '#a01010', '900');
      } else if (kind === 'dog') {
        txt(c, 'سگ گمشده', w / 2, 40, 40, '#111', '900'); txt(c, 'پاداش', w / 2, 80, 24, '#a01010', '900');
        c.fillStyle = '#7a7a76'; c.fillRect(38, 100, 180, 170);
        c.fillStyle = '#111'; // a dog... standing on two legs
        c.beginPath(); c.ellipse(128, 175, 22, 45, 0, 0, Math.PI * 2); c.fill();
        c.beginPath(); c.ellipse(132, 122, 16, 14, 0, 0, Math.PI * 2); c.fill(); c.fillRect(140, 118, 26, 10);
        c.beginPath(); c.moveTo(122, 112); c.lineTo(118, 96); c.lineTo(128, 108); c.fill();
        c.fillRect(112, 210, 8, 55); c.fillRect(136, 210, 8, 55); c.fillRect(100, 150, 6, 60); c.fillRect(150, 150, 6, 60);
        c.fillStyle = '#ffcc55'; c.fillRect(134, 118, 3, 3);
        txt(c, 'اگر او را دیدید', w / 2, 296, 16, '#222'); txt(c, 'نزدیک نشوید', w / 2, 320, 20, '#a01010', '900');
      } else if (kind === 'hiring') {
        c.fillStyle = '#0d3a6a'; c.fillRect(0, 0, w, 90);
        txt(c, 'استخدام فوری', w / 2, 46, 36, '#fff', '900');
        txt(c, 'کارمند شیفت شب', w / 2, 128, 26, '#0d3a6a', '900');
        txt(c, '✔ حقوق عالی', w / 2, 175, 18, '#222'); txt(c, '✔ کار آسان', w / 2, 205, 18, '#222'); txt(c, '✔ بدون نیاز به سابقه', w / 2, 235, 18, '#222');
        txt(c, '* ترک شیفت قبل از طلوع ممنوع است', w / 2, 300, 11, '#8a0000', 'normal');
        txt(c, 'پترو ۲۴', w / 2, 335, 22, '#0d3a6a', '900');
      } else if (kind === 'rules') {
        txt(c, 'قوانین شیفت شب', w / 2, 34, 26, '#111', '900');
        const r = ['چراغ‌ها روشن بمانند', 'سؤال اضافه نپرس', 'در را برایشان باز نکن', 'به بی‌چهره خیره نشو', 'تلفن بعد از ۴ را جواب نده', 'تا صبح دوام بیاور'];
        r.forEach((s, i) => txt(c, `${'۱۲۳۴۵۶'[i]}. ${s}`, w - 20, 80 + i * 42, 16, '#222', 'bold', 'right'));
        c.strokeStyle = '#8a0000'; c.lineWidth = 3; c.beginPath(); c.moveTo(20, 290); c.lineTo(236, 290); c.stroke();
      } else if (kind === 'smile') {
        drawFace(c, w / 2, 160, 100, 'grin');
        txt(c, 'لبخند بزن', w / 2, 300, 34, '#e8e8e8', '900'); txt(c, 'او تماشا می‌کند', w / 2, 336, 16, '#a01010', 'bold');
      }
      if (kind === 'flyer') { txt(c, 'تو بعدی هستی', w / 2, 200, 34, 'rgba(150,0,0,0.85)', '900'); }
      grime(c, w, h, aged ? 16 : 8, aged ? 0.45 : 0.25);
      if (aged) for (let i = 0; i < 4; i++) drip(c, rnd() * w, 0, 30 + rnd() * 90, 3 + rnd() * 3, 'rgba(90,0,0,0.85)');
      tape(c, 22, 10, -0.3); tape(c, w - 22, 10, 0.3);
    });
  },
  handprints() {
    return make('handprints', 256, 256, (c, w, h) => {
      c.clearRect(0, 0, w, h);
      for (let k = 0; k < 4; k++) {
        const x = 40 + rnd() * 170, y = 40 + rnd() * 150, r = (rnd() - 0.5) * 0.8;
        c.save(); c.translate(x, y); c.rotate(r); c.fillStyle = 'rgba(110,0,0,0.85)';
        c.beginPath(); c.ellipse(0, 10, 16, 20, 0, 0, Math.PI * 2); c.fill();
        [[-14, -14, 0.4], [-6, -22, 0.1], [3, -23, 0], [11, -19, -0.15], [20, 2, -1]].forEach(([fx, fy, fr]) => { c.save(); c.translate(fx, fy); c.rotate(fr); c.fillRect(-3, -14, 6, 18); c.restore(); });
        c.restore();
        drip(c, x, y + 25, 20 + rnd() * 60, 3, 'rgba(100,0,0,0.8)');
      }
    });
  },
  scrawl(text: string) {
    return make('scrawl' + text, 512, 256, (c, w, h) => {
      c.clearRect(0, 0, w, h);
      c.save(); c.translate(w / 2, h / 2); c.rotate(-0.08);
      txt(c, text, 0, 0, 80, 'rgba(120,0,0,0.9)', '900'); c.restore();
      for (let i = 0; i < 10; i++) drip(c, 80 + rnd() * 350, h / 2 + 30, 20 + rnd() * 70, 3, 'rgba(110,0,0,0.85)');
    });
  },
  /** packaging labels: drawn light so instance colors tint them */
  label(kind: 'bag' | 'box' | 'can' | 'bottle' | 'oil' | 'candy') {
    return make('label' + kind, 128, 128, (c, w, h) => {
      c.fillStyle = '#f2f2f2'; c.fillRect(0, 0, w, h);
      if (kind === 'bag') {
        const g = c.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#b8b8b8'); c.fillStyle = g; c.fillRect(0, 0, w, h);
        c.fillStyle = '#ffd94a'; c.beginPath(); c.ellipse(w / 2, h * 0.38, 46, 22, -0.2, 0, Math.PI * 2); c.fill();
        txt(c, 'CHIPS', w / 2, h * 0.38, 22, '#b01010', '900');
        c.fillStyle = '#e8c070'; for (let i = 0; i < 5; i++) { c.beginPath(); c.ellipse(30 + i * 17, h * 0.75, 12, 7, i, 0, Math.PI * 2); c.fill(); }
        c.fillStyle = 'rgba(255,255,255,0.5)'; c.fillRect(0, 0, w, 10); c.fillRect(0, h - 10, w, 10);
      } else if (kind === 'box') {
        c.fillStyle = '#d8d8d8'; c.fillRect(0, 0, w, h);
        c.fillStyle = '#ffffff'; c.beginPath(); c.arc(w / 2, h * 0.62, 34, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#e0a040'; for (let i = 0; i < 12; i++) { c.beginPath(); c.arc(w / 2 + (rnd() - 0.5) * 40, h * 0.62 + (rnd() - 0.5) * 30, 6, 0, Math.PI * 2); c.fill(); }
        txt(c, 'FLAKES', w / 2, h * 0.2, 22, '#202020', '900');
      } else if (kind === 'can') {
        c.fillStyle = '#e6e6e6'; c.fillRect(0, 0, w, h);
        c.fillStyle = '#ffffff'; c.beginPath(); c.moveTo(0, h * 0.55); c.bezierCurveTo(w * 0.3, h * 0.35, w * 0.6, h * 0.75, w, h * 0.5); c.lineTo(w, h * 0.65); c.bezierCurveTo(w * 0.6, h * 0.9, w * 0.3, h * 0.5, 0, h * 0.7); c.fill();
        txt(c, 'COLA', w * 0.25, h * 0.35, 26, '#ffffff', '900'); txt(c, 'COLA', w * 0.75, h * 0.35, 26, '#ffffff', '900');
        c.fillStyle = '#c0c0c0'; c.fillRect(0, 0, w, 8); c.fillRect(0, h - 8, w, 8);
      } else if (kind === 'bottle') {
        c.fillStyle = '#ffffff'; c.fillRect(0, h * 0.42, w, h * 0.28);
        txt(c, 'FRESH', w / 2, h * 0.56, 20, '#333', '900');
      } else if (kind === 'oil') {
        c.fillStyle = '#222'; c.fillRect(0, h * 0.3, w, h * 0.45); txt(c, '10W-40', w / 2, h * 0.52, 22, '#ffffff', '900');
      } else {
        c.fillStyle = '#5a3020'; c.fillRect(0, 0, w, h); c.fillStyle = '#ffffff'; c.fillRect(0, h * 0.3, w, h * 0.4); txt(c, 'CHOCO', w / 2, h / 2, 26, '#5a3020', '900');
      }
    });
  },
  priceStrip() {
    return make('pricestrip', 256, 32, (c, w, h) => {
      c.fillStyle = '#f4f4f0'; c.fillRect(0, 0, w, h);
      for (let i = 0; i < 6; i++) { c.fillStyle = i % 3 === 0 ? '#ffd400' : '#ffffff'; c.fillRect(i * 43 + 4, 4, 36, h - 8); txt(c, `${(i * 7 + 12) % 90}٬۰۰۰`, i * 43 + 22, h / 2, 9, '#c00', 'bold'); }
    });
  },
  flesh() {
    return make('flesh', 256, 256, (c, w, h) => {
      const g = c.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#5a1a18'); g.addColorStop(1, '#2a0808'); c.fillStyle = g; c.fillRect(0, 0, w, h);
      for (let i = 0; i < 600; i++) { c.fillStyle = `rgba(${120 + rnd() * 80},${20 + rnd() * 30},${20 + rnd() * 20},${rnd() * 0.3})`; c.beginPath(); c.arc(rnd() * w, rnd() * h, 1 + rnd() * 6, 0, Math.PI * 2); c.fill(); }
      c.strokeStyle = 'rgba(20,0,30,0.6)';
      for (let i = 0; i < 22; i++) { c.lineWidth = 0.5 + rnd() * 2.5; c.beginPath(); let x = rnd() * w, y = rnd() * h; c.moveTo(x, y); for (let j = 0; j < 7; j++) { x += (rnd() - 0.5) * 50; y += (rnd() - 0.5) * 50; c.lineTo(x, y); } c.stroke(); }
      c.fillStyle = 'rgba(255,220,200,0.08)'; for (let i = 0; i < 40; i++) { c.beginPath(); c.ellipse(rnd() * w, rnd() * h, 2 + rnd() * 6, 1 + rnd() * 3, rnd() * 3, 0, Math.PI * 2); c.fill(); }
    });
  },
  paleSkin() {
    return make('paleskin', 256, 256, (c, w, h) => {
      c.fillStyle = '#b9b4a8'; c.fillRect(0, 0, w, h);
      for (let i = 0; i < 3000; i++) { c.fillStyle = `rgba(${80 + rnd() * 60},${70 + rnd() * 40},${70 + rnd() * 40},${rnd() * 0.15})`; c.fillRect(rnd() * w, rnd() * h, 2, 2); }
      c.strokeStyle = 'rgba(70,40,80,0.35)';
      for (let i = 0; i < 14; i++) { c.lineWidth = 0.6 + rnd(); c.beginPath(); let x = rnd() * w, y = rnd() * h; c.moveTo(x, y); for (let j = 0; j < 6; j++) { x += (rnd() - 0.5) * 40; y += rnd() * 30; c.lineTo(x, y); } c.stroke(); }
      c.strokeStyle = 'rgba(20,10,10,0.5)'; c.lineWidth = 1.2;
      for (let i = 0; i < 5; i++) { c.beginPath(); let x = rnd() * w, y = rnd() * h; c.moveTo(x, y); for (let j = 0; j < 5; j++) { x += (rnd() - 0.5) * 30; y += (rnd() - 0.5) * 30; c.lineTo(x, y); } c.stroke(); }
    });
  },
  fur() {
    return make('fur', 256, 256, (c, w, h) => {
      c.fillStyle = '#1b1612'; c.fillRect(0, 0, w, h);
      for (let i = 0; i < 4000; i++) { const x = rnd() * w, y = rnd() * h; c.strokeStyle = `rgba(${40 + rnd() * 40},${30 + rnd() * 30},${20 + rnd() * 20},${0.3 + rnd() * 0.5})`; c.lineWidth = 1; c.beginPath(); c.moveTo(x, y); c.lineTo(x + (rnd() - 0.5) * 4, y + 4 + rnd() * 8); c.stroke(); }
      for (let i = 0; i < 12; i++) { c.fillStyle = `rgba(90,20,20,${0.2 + rnd() * 0.3})`; c.beginPath(); c.ellipse(rnd() * w, rnd() * h, 5 + rnd() * 15, 3 + rnd() * 8, rnd() * 3, 0, Math.PI * 2); c.fill(); }
    });
  },
  pegboard() {
    return make('pegboard', 256, 256, (c, w, h) => {
      c.fillStyle = '#9a7a52'; c.fillRect(0, 0, w, h);
      for (let x = 8; x < w; x += 16) for (let y = 8; y < h; y += 16) { c.fillStyle = '#3a2a18'; c.beginPath(); c.arc(x, y, 2.5, 0, Math.PI * 2); c.fill(); }
      grime(c, w, h, 6, 0.2);
    });
  },
  grill() {
    return make('grill', 64, 64, (c, w, h) => {
      c.fillStyle = '#ffffff'; c.fillRect(0, 0, w, h);
      c.fillStyle = 'rgba(60,20,5,0.7)'; for (let i = 0; i < 6; i++) c.fillRect(i * 11, 0, 3, h);
    });
  },
  plate() {
    return make('plate', 256, 56, (c, w, h) => {
      c.fillStyle = '#f2f2f2'; c.fillRect(0, 0, w, h);
      c.fillStyle = '#1f3f9a'; c.fillRect(0, 0, 34, h);
      txt(c, 'I.R.', 17, 18, 11, '#fff'); txt(c, 'IRAN', 17, 36, 10, '#fff');
      txt(c, '۲۴ ن ۶۶۶', 135, h / 2 + 2, 32, '#111', '900');
      c.fillStyle = '#111'; c.fillRect(200, 4, 2, h - 8); txt(c, 'ایران', 228, 16, 11, '#111'); txt(c, '۱۳', 228, 38, 20, '#111', '900');
      c.strokeStyle = '#111'; c.lineWidth = 3; c.strokeRect(1, 1, w - 2, h - 2);
    });
  },
  gauge() {
    return make('gauge', 256, 128, (c, w, h) => {
      c.fillStyle = '#050608'; c.fillRect(0, 0, w, h);
      const dial = (cx: number, max: number, label: string) => {
        c.strokeStyle = '#2a7fff'; c.lineWidth = 2; c.beginPath(); c.arc(cx, 70, 48, Math.PI * 0.8, Math.PI * 2.2); c.stroke();
        for (let i = 0; i <= 10; i++) { const a = Math.PI * 0.8 + (i / 10) * Math.PI * 1.4; c.beginPath(); c.moveTo(cx + Math.cos(a) * 40, 70 + Math.sin(a) * 40); c.lineTo(cx + Math.cos(a) * 47, 70 + Math.sin(a) * 47); c.stroke(); if (i % 2 === 0) txt(c, String(Math.round(max * i / 10)), cx + Math.cos(a) * 31, 70 + Math.sin(a) * 31, 9, '#8ac4ff', 'normal'); }
        txt(c, label, cx, 102, 9, '#8ac4ff', 'normal');
      };
      dial(64, 200, 'km/h'); dial(192, 8, 'x1000');
      txt(c, '02:41', w / 2, 20, 12, '#5fff8a', 'bold');
      c.fillStyle = '#ff3a2a'; c.beginPath(); c.arc(w / 2, 112, 4, 0, Math.PI * 2); c.fill();
    });
  },
  sign(text: string, bg: string, fg: string, w = 256, h = 64, size = 34) {
    return make('asign' + text + bg + fg, w, h, (c) => { c.fillStyle = bg; c.fillRect(0, 0, w, h); txt(c, text, w / 2, h / 2 + 2, size, fg, '900'); });
  },
  wetFloor() {
    return make('wetfloor', 128, 192, (c, w, h) => {
      c.fillStyle = '#f5c800'; c.fillRect(0, 0, w, h);
      c.fillStyle = '#111'; c.beginPath(); c.moveTo(w / 2, 20); c.lineTo(w - 20, 100); c.lineTo(20, 100); c.closePath(); c.fill();
      c.fillStyle = '#f5c800'; c.beginPath(); c.moveTo(w / 2, 36); c.lineTo(w - 32, 92); c.lineTo(32, 92); c.closePath(); c.fill();
      txt(c, '!', w / 2, 70, 40, '#111', '900');
      txt(c, 'احتیاط', w / 2, 130, 22, '#111', '900'); txt(c, 'زمین خیس', w / 2, 160, 18, '#111', '900');
    });
  },
};
