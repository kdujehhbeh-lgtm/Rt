// Light pool: the scene may contain dozens of point lights, but the GPU only ever sees a fixed small
// number of real ones (no shader recompiles, bounded per-pixel cost on mobile). Every 0.2 s the
// nearest/brightest "virtual" lights are assigned to the physical slots with a short fade-in.
import * as THREE from 'three';

interface Slot { l: THREE.PointLight; src: THREE.PointLight | null; fade: number }
const virt: THREE.PointLight[] = [];
let slots: Slot[] = [];
let scene: THREE.Scene | null = null;
let acc = 0;
const tmp = new THREE.Vector3();

/** hide a point light from the renderer and let the pool drive it */
export function registerLight(l: THREE.PointLight) {
  if (slots.some((s) => s.l === l) || virt.includes(l)) return;
  virt.push(l); l.visible = false;
}
export function poolActive() { return slots.length > 0; }

export function initPool(sc: THREE.Scene, k: number) {
  disposePool();
  scene = sc;
  sc.traverse((o) => { if ((o as THREE.PointLight).isPointLight) registerLight(o as THREE.PointLight); });
  for (let i = 0; i < k; i++) { const l = new THREE.PointLight(0xffffff, 0, 10, 2); l.position.set(0, -500, 0); sc.add(l); slots.push({ l, src: null, fade: 0 }); }
  acc = 0;
}
export function disposePool() {
  slots.forEach((s) => s.l.parent?.remove(s.l));
  slots = []; virt.length = 0; scene = null;
}
function inScene(o: THREE.Object3D) { let p: THREE.Object3D | null = o; while (p.parent) p = p.parent; return p === scene; }

export function updatePool(dt: number, cam: THREE.Vector3) {
  if (!slots.length) return;
  acc -= dt;
  if (acc <= 0) {
    acc = 0.2;
    const cands: { v: THREE.PointLight; s: number }[] = [];
    for (let i = virt.length - 1; i >= 0; i--) {
      const v = virt[i];
      if (!inScene(v)) { virt.splice(i, 1); continue; }
      if (v.intensity <= 0.01) continue;
      v.getWorldPosition(tmp);
      const d = tmp.distanceTo(cam); const r = v.distance || 20;
      if (d > r * 1.6 + 6) continue;
      cands.push({ v, s: d - r * 0.45 - Math.min(10, v.intensity) * 0.15 });
    }
    cands.sort((a, b) => a.s - b.s);
    const chosen = new Set(cands.slice(0, slots.length).map((c) => c.v));
    const kept = new Set<THREE.PointLight>();
    const free: Slot[] = [];
    for (const s of slots) { if (s.src && chosen.has(s.src)) kept.add(s.src); else free.push(s); }
    chosen.forEach((v) => { if (kept.has(v)) return; const s = free.shift(); if (!s) return; s.src = v; s.fade = 0; });
    free.forEach((s) => (s.src = null));
  }
  for (const s of slots) {
    if (!s.src) { s.l.intensity *= Math.max(0, 1 - dt * 6); continue; }
    s.fade = Math.min(1, s.fade + dt * 4);
    s.src.getWorldPosition(s.l.position);
    s.l.color.copy(s.src.color); s.l.distance = s.src.distance; s.l.decay = s.src.decay;
    s.l.intensity = s.src.intensity * s.fade;
  }
}
