// World-building helpers: geometry builder, doors, light groups, interactables
import * as THREE from 'three';
import { Collision, type Box } from './physics';
import { audio } from './audio';
import { mat } from './textures';

export interface Interactable {
  id: string;
  pos: THREE.Vector3;
  range?: number;
  prompt: () => string | null;
  action: () => void;
  /** higher wins when several interactions overlap (mission > generic) */
  priority?: number;
}

const geoCache = new Map<string, THREE.BufferGeometry>();
/** Box geometry with world-scaled UVs (1 texture tile = `tile` meters) */
export function boxGeo(w: number, h: number, d: number, tile = 2) {
  const k = `${w.toFixed(2)}_${h.toFixed(2)}_${d.toFixed(2)}_${tile}`;
  const c = geoCache.get(k); if (c) return c;
  const g = new THREE.BoxGeometry(w, h, d);
  const uv = g.attributes.uv as THREE.BufferAttribute;
  const dims: [number, number][] = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let v = 0; v < 4; v++) {
    const i = f * 4 + v;
    uv.setXY(i, uv.getX(i) * dims[f][0] / tile, uv.getY(i) * dims[f][1] / tile);
  }
  uv.needsUpdate = true;
  geoCache.set(k, g);
  return g;
}
export function clearGeoCache() { geoCache.forEach((g) => g.dispose()); geoCache.clear(); }

export interface BoxOpts { collide?: boolean; sight?: boolean; cast?: boolean; receive?: boolean; tile?: number; minY?: number; maxY?: number; parent?: THREE.Object3D }

export class Builder {
  constructor(public group: THREE.Group, public col: Collision, public shadows = false) {}
  /** y = bottom of box */
  box(x: number, y: number, z: number, w: number, h: number, d: number, m: THREE.Material, o: BoxOpts = {}) {
    const mesh = new THREE.Mesh(boxGeo(w, h, d, o.tile ?? 2), m);
    mesh.position.set(x, y + h / 2, z);
    mesh.castShadow = this.shadows && (o.cast ?? false);
    mesh.receiveShadow = this.shadows && (o.receive ?? true);
    (o.parent ?? this.group).add(mesh);
    if (o.collide) this.col.addCentered(x, z, w, d, { sight: o.sight ?? true, minY: o.minY ?? y - 0.1, maxY: o.maxY ?? y + h });
    return mesh;
  }
  /** Wall along X axis at constant z with openings [centerX, width, top] */
  wallX(z: number, x1: number, x2: number, h: number, m: THREE.Material, openings: [number, number, number?][] = [], t = 0.2, y0 = 0) {
    const segs = this.segments(x1, x2, openings);
    for (const [a, b] of segs) this.box((a + b) / 2, y0, z, b - a, h, t, m, { collide: true, minY: y0 - 0.5, maxY: y0 + h });
    for (const [c, w, top] of openings) { const tp = top ?? 2.3; if (tp < h) this.box(c, y0 + tp, z, w, h - tp, t, m); }
  }
  wallZ(x: number, z1: number, z2: number, h: number, m: THREE.Material, openings: [number, number, number?][] = [], t = 0.2, y0 = 0) {
    const segs = this.segments(z1, z2, openings);
    for (const [a, b] of segs) this.box(x, y0, (a + b) / 2, t, h, b - a, m, { collide: true, minY: y0 - 0.5, maxY: y0 + h });
    for (const [c, w, top] of openings) { const tp = top ?? 2.3; if (tp < h) this.box(x, y0 + tp, c, t, h - tp, w, m); }
  }
  private segments(a: number, b: number, openings: [number, number, number?][]) {
    const segs: [number, number][] = [];
    let cur = a;
    [...openings].sort((p, q) => p[0] - q[0]).forEach(([c, w]) => { if (c - w / 2 > cur) segs.push([cur, c - w / 2]); cur = c + w / 2; });
    if (cur < b) segs.push([cur, b]);
    return segs;
  }
  plane(x: number, y: number, z: number, w: number, d: number, m: THREE.Material, rotX = -Math.PI / 2) {
    const g = new THREE.PlaneGeometry(w, d);
    const uv = g.attributes.uv as THREE.BufferAttribute;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * w / 2, uv.getY(i) * d / 2);
    const mesh = new THREE.Mesh(g, m);
    mesh.rotation.x = rotX; mesh.position.set(x, y, z);
    mesh.receiveShadow = this.shadows;
    this.group.add(mesh);
    return mesh;
  }
  cyl(x: number, y: number, z: number, r: number, h: number, m: THREE.Material, seg = 12, collide = false) {
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, seg), m);
    mesh.position.set(x, y + h / 2, z);
    mesh.castShadow = this.shadows;
    this.group.add(mesh);
    if (collide) this.col.addCentered(x, z, r * 2, r * 2, { minY: y - 0.1, maxY: y + h });
    return mesh;
  }
}

// ---------------- Doors ----------------
export interface DoorOpts { x: number; z: number; width: number; axis: 'x' | 'z'; y?: number; height?: number; material: THREE.Material; glass?: boolean; name: string; dir?: number; locked?: boolean; autoClose?: boolean }

export class Door {
  pivot = new THREE.Group();
  box: Box;
  open = false; locked = false; broken = false;
  angle = 0; target = 0;
  pos: THREE.Vector3;
  name: string;
  autoClose: boolean;
  closeTimer = 0;
  bangHits = 0;
  glass = false;
  dir: number;
  onOpen?: () => void;
  constructor(parent: THREE.Object3D, col: Collision, o: DoorOpts) {
    const y = o.y ?? 0; const h = o.height ?? 2.2;
    this.name = o.name; this.dir = o.dir ?? 1; this.locked = !!o.locked; this.autoClose = !!o.autoClose;
    this.pos = new THREE.Vector3(o.x, y + 1.2, o.z);
    const panelGeo = boxGeo(o.width - 0.04, h - 0.04, 0.06, 1);
    const panel = new THREE.Mesh(panelGeo, o.material);
    if (o.axis === 'x') { this.pivot.position.set(o.x - o.width / 2, y, o.z); panel.position.set(o.width / 2, h / 2, 0); }
    else { this.pivot.position.set(o.x, y, o.z - o.width / 2); panel.rotation.y = Math.PI / 2; panel.position.set(0, h / 2, o.width / 2); }
    this.pivot.add(panel);
    if (o.glass) {
      // frame
      const fm = mat({ color: 0x2a2a2a, metal: 0.8, rough: 0.4, key: 'doorframe' });
      const bar = new THREE.Mesh(boxGeo(o.width, 0.1, 0.08, 1), fm);
      bar.position.copy(panel.position).setY(1.05); bar.rotation.y = panel.rotation.y; this.pivot.add(bar);
      const bar2 = bar.clone(); bar2.position.y = h - 0.05; this.pivot.add(bar2);
      const bar3 = bar.clone(); bar3.position.y = 0.05; this.pivot.add(bar3);
    } else {
      const knob = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6), mat({ color: 0xb8a060, metal: 0.9, rough: 0.3, key: 'knob' }));
      if (o.axis === 'x') knob.position.set(o.width - 0.12, 1.0, 0.06); else knob.position.set(0.06, 1.0, o.width - 0.12);
      this.pivot.add(knob);
      const k2 = knob.clone(); if (o.axis === 'x') k2.position.z = -0.06; else k2.position.x = -0.06; this.pivot.add(k2);
    }
    parent.add(this.pivot);
    this.box = o.axis === 'x'
      ? col.add(o.x - o.width / 2, o.x + o.width / 2, o.z - 0.08, o.z + 0.08, { door: true, sight: !o.glass, minY: y - 0.5, maxY: y + h, tag: o.name })
      : col.add(o.x - 0.08, o.x + 0.08, o.z - o.width / 2, o.z + o.width / 2, { door: true, sight: !o.glass, minY: y - 0.5, maxY: y + h, tag: o.name });
  }
  setOpen(v: boolean, silent = false) {
    if (this.broken) v = true;
    if (v === this.open) return;
    this.open = v;
    this.target = v ? 1.65 * this.dir : 0;
    if (!silent) audio.door(this.pos, v, false, this.glass);
    if (v) { this.onOpen?.(); this.closeTimer = 3.5; }
  }
  toggle() { if (this.locked && !this.open) { audio.knock(this.pos, 1, 0.25); return false; } this.setOpen(!this.open); return true; }
  breakOpen() { this.broken = true; this.locked = false; this.open = false; this.setOpen(true, true); audio.door(this.pos, false, true); audio.knock(this.pos, 1, 1); }
  update(dt: number) {
    this.angle += (this.target - this.angle) * Math.min(1, dt * 6);
    this.pivot.rotation.y = -this.angle;
    this.box.enabled = Math.abs(this.angle) < 0.35 && !this.broken;
    if (this.autoClose && this.open) { this.closeTimer -= dt; if (this.closeTimer <= 0) this.setOpen(false); }
  }
}

// ---------------- Light groups (flicker / power) ----------------
type AnyMat = THREE.MeshStandardMaterial | THREE.MeshLambertMaterial | THREE.MeshBasicMaterial;
export class LightGroup {
  lights: { l: THREE.Light; base: number }[] = [];
  mats: { m: AnyMat; base: number; col?: THREE.Color }[] = [];
  objs: THREE.Object3D[] = [];
  on = true;
  flickerT = 0;
  unstable = 0; // constant subtle flicker probability
  private cur = 1;
  private nextFlip = 0;
  private flickVal = 1;
  constructor(public name: string) {}
  add(l: THREE.Light) { this.lights.push({ l, base: l.intensity }); return l; }
  addMat(m: THREE.Material) { const am = m as AnyMat; if ((am as any).emissive) this.mats.push({ m: am, base: (am as any).emissiveIntensity }); else if ((am as THREE.MeshBasicMaterial).color) this.mats.push({ m: am, base: 1, col: (am as THREE.MeshBasicMaterial).color.clone() }); return m; }
  addObj(o: THREE.Object3D) { this.objs.push(o); return o; }
  set(on: boolean) { this.on = on; }
  flicker(d: number) { this.flickerT = Math.max(this.flickerT, d); }
  update(dt: number, t: number) {
    let v = this.on ? 1 : 0;
    if (this.on && (this.flickerT > 0 || this.unstable > 0)) {
      if (this.flickerT > 0) this.flickerT -= dt;
      if (t > this.nextFlip) {
        const strong = this.flickerT > 0;
        this.flickVal = strong ? (Math.random() < 0.45 ? 0.05 : 0.6 + Math.random() * 0.5) : (Math.random() < this.unstable ? 0.25 : 1);
        this.nextFlip = t + (strong ? 0.04 + Math.random() * 0.14 : 0.05 + Math.random() * 0.4);
      }
      v *= this.flickVal;
    }
    if (Math.abs(v - this.cur) < 0.001) return;
    this.cur = v;
    for (const { l, base } of this.lights) l.intensity = base * v;
    for (const e of this.mats) {
      if (e.col) (e.m as THREE.MeshBasicMaterial).color.copy(e.col).multiplyScalar(Math.max(0.08, v));
      else (e.m as any).emissiveIntensity = e.base * v;
    }
    for (const o of this.objs) o.visible = v > 0.3;
  }
  get level() { return this.cur; }
}

export function setLayer(o: THREE.Object3D, layer: number) { o.traverse((c) => c.layers.set(layer)); }
export function freezeStatic(g: THREE.Object3D) { g.updateMatrixWorld(true); g.traverse((c) => { c.matrixAutoUpdate = false; }); }
