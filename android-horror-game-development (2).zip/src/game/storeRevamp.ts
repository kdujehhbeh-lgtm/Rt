// "Pro" store revamp: polished porcelain floor, branded wall cladding, drop ceiling with linear LEDs,
// hanging aisle signs, redesigned checkout (branded counter, real cash register with open drawer &
// banknotes, back bar of cigarettes, documents desk, safe), realistic bins, jerry can, books.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { mat, tex } from './textures';
import { hiCanvas, finishTex } from './gfx';
import type { Collision } from './physics';

const FONT = 'Vazirmatn, Tahoma, Arial, sans-serif';
const cache = new Map<string, THREE.CanvasTexture>();
let seed = 1; const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
function T(key: string, w: number, h: number, draw: (c: CanvasRenderingContext2D, w: number, h: number) => void, rep?: [number, number]) {
  const hit = cache.get(key); if (hit) return hit;
  const { cv, c } = hiCanvas(w, h); seed = key.length * 977 + 11; draw(c, w, h);
  const t = finishTex(new THREE.CanvasTexture(cv)); t.wrapS = t.wrapT = THREE.RepeatWrapping; if (rep) t.repeat.set(...rep);
  cache.set(key, t); return t;
}
function txt(c: CanvasRenderingContext2D, s: string, x: number, y: number, size: number, col: string, weight = '900', align: CanvasTextAlign = 'center') {
  c.font = `${weight} ${size}px ${FONT}`; c.fillStyle = col; c.textAlign = align; c.textBaseline = 'middle'; c.direction = /[\u0600-\u06FF]/.test(s) ? 'rtl' : 'ltr'; c.fillText(s, x, y); c.direction = 'ltr';
}

// ---------------- textures ----------------
export const rt = {
  porcelain: () => T('porcelain', 512, 512, (c, w, h) => {
    // 60×60 large-format polished porcelain, 2×2 tiles per texture, subtle stone veining & 2 mm joints
    for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) {
      const b = 222 + rnd() * 10; c.fillStyle = `rgb(${b},${b - 2},${b - 6})`; c.fillRect(i * 256, j * 256, 256, 256);
      for (let k = 0; k < 6; k++) { c.strokeStyle = `rgba(150,140,130,${0.06 + rnd() * 0.08})`; c.lineWidth = 0.8 + rnd() * 1.5; c.beginPath(); let x = i * 256 + rnd() * 256, y = j * 256 + rnd() * 256; c.moveTo(x, y); for (let q = 0; q < 8; q++) { x += (rnd() - 0.4) * 50; y += (rnd() - 0.5) * 30; c.lineTo(x, y); } c.stroke(); }
    }
    for (let i = 0; i < 9000; i++) { c.fillStyle = `rgba(120,110,100,${rnd() * 0.05})`; c.fillRect(rnd() * w, rnd() * h, 1.5, 1.5); }
    c.fillStyle = '#9a948a'; for (let k = 0; k <= 2; k++) { c.fillRect(k * 256 - 1.5, 0, 3, h); c.fillRect(0, k * 256 - 1.5, w, 3); }
  }, [14, 4.5]),
  cladding: () => T('cladding', 1024, 256, (c, w, h) => {
    // charcoal dado with red brand stripe + white upper wall with printed lifestyle band
    c.fillStyle = '#f4f2ee'; c.fillRect(0, 0, w, h);
    c.fillStyle = '#26282c'; c.fillRect(0, h * 0.62, w, h * 0.38);
    for (let x = 0; x < w; x += 64) { c.fillStyle = 'rgba(255,255,255,0.04)'; c.fillRect(x, h * 0.62, 2, h * 0.38); }
    c.fillStyle = '#c8141f'; c.fillRect(0, h * 0.58, w, h * 0.04);
    c.fillStyle = '#0d3a6a'; c.fillRect(0, h * 0.555, w, h * 0.022);
    for (let x = 30; x < w; x += 330) { txt(c, 'PETRO 24', x + 80, h * 0.3, 40, '#0d3a6a', '900', 'left'); txt(c, '• همیشه باز •', x + 210, h * 0.3, 22, '#c8141f', 'bold', 'left'); }
  }, [3, 1]),
  ceiling: () => T('droptile', 256, 256, (c, w, h) => {
    c.fillStyle = '#f1f0ec'; c.fillRect(0, 0, w, h);
    for (let i = 0; i < 2500; i++) { c.fillStyle = `rgba(0,0,0,${rnd() * 0.06})`; c.beginPath(); c.arc(rnd() * w, rnd() * h, 0.8 + rnd(), 0, Math.PI * 2); c.fill(); } // fissured mineral fibre
    c.fillStyle = '#d4d6d8'; c.fillRect(0, 0, w, 6); c.fillRect(0, 0, 6, h); // T-bar grid
    c.fillStyle = 'rgba(0,0,0,0.12)'; c.fillRect(0, 6, w, 2); c.fillRect(6, 0, 2, h);
  }, [28 / 1.2, 9 / 1.2]),
  counterFront: () => T('counterfront', 1024, 192, (c, w, h) => {
    const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#0e2f58'); g.addColorStop(1, '#081b34'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    c.fillStyle = '#c8141f'; c.fillRect(0, h - 26, w, 10);
    for (let x = 0; x < w; x += 8) { c.fillStyle = 'rgba(255,255,255,0.03)'; c.fillRect(x, 0, 1, h); }
    txt(c, 'PETRO 24  MARKET', w * 0.3, h * 0.45, 64, '#ffffff', '900'); txt(c, 'صندوق • CHECKOUT', w * 0.75, h * 0.45, 40, '#9fc8ff', 'bold');
  }),
  aisleSign: (fa: string, en: string, col: string) => T('aisle' + fa, 512, 160, (c, w, h) => {
    c.fillStyle = col; c.fillRect(0, 0, w, h); c.fillStyle = 'rgba(255,255,255,0.12)'; c.fillRect(0, 0, w, h * 0.45);
    txt(c, fa, w / 2, h * 0.42, 62, '#ffffff', '900'); txt(c, en, w / 2, h * 0.8, 28, 'rgba(255,255,255,0.85)', 'bold');
  }),
  cigs: () => T('cigwall', 512, 256, (c, w, h) => {
    c.fillStyle = '#141414'; c.fillRect(0, 0, w, h);
    const brands = [['#c41e1e', 'Winston'], ['#f2f2f2', 'Bahman'], ['#1a3a8a', 'Kent'], ['#d8b040', 'Esse'], ['#2a2a2a', 'Montana'], ['#e8e8e8', 'Marlboro']];
    for (let r = 0; r < 4; r++) for (let k = 0; k < 16; k++) {
      const [bc, bn] = brands[(k + r * 3) % brands.length]; const x = 4 + k * 32, y = 6 + r * 62;
      c.fillStyle = bc; c.fillRect(x, y, 28, 44); c.fillStyle = 'rgba(255,255,255,0.25)'; c.fillRect(x, y, 28, 6);
      c.fillStyle = '#111'; c.fillRect(x + 2, y + 30, 24, 12); c.fillStyle = '#fff'; c.font = 'bold 6px Arial'; c.textAlign = 'center'; c.fillText('سیگار کشیدن', x + 14, y + 35); c.fillText('کشنده است', x + 14, y + 40);
      c.fillStyle = bc === '#f2f2f2' || bc === '#e8e8e8' ? '#c41e1e' : '#fff'; c.font = 'bold 7px Arial'; c.fillText(bn, x + 14, y + 20);
      c.fillStyle = '#ffd400'; c.fillRect(x + 2, y + 48, 24, 8); c.fillStyle = '#c00'; c.font = 'bold 6px Arial'; c.fillText(`${(k * 13 + r * 7) % 90 + 10}٬۰۰۰`, x + 14, y + 54);
    }
  }),
  banknote: (col: string, val: string) => T('note' + val, 256, 120, (c, w, h) => {
    c.fillStyle = col; c.fillRect(0, 0, w, h);
    c.strokeStyle = 'rgba(0,0,0,0.25)'; c.lineWidth = 2; c.strokeRect(6, 6, w - 12, h - 12);
    for (let i = 0; i < 30; i++) { c.strokeStyle = 'rgba(255,255,255,0.15)'; c.beginPath(); c.arc(w * 0.7, h / 2, 6 + i * 2, 0, Math.PI * 2); c.stroke(); }
    c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(w * 0.28, h / 2, 26, 34, 0, 0, Math.PI * 2); c.fill();
    txt(c, val, w * 0.7, h * 0.5, 30, '#1a1a1a', '900'); txt(c, 'بانک مرکزی', w * 0.7, h * 0.82, 14, '#1a1a1a', 'bold');
  }),
  binderSpine: (i: number) => T('binder' + i, 128, 512, (c, w, h) => {
    const cols = ['#1d4fa8', '#c41e1e', '#2a7a3a', '#2a2a2a', '#d8a020'];
    c.fillStyle = cols[i % cols.length]; c.fillRect(0, 0, w, h);
    c.fillStyle = 'rgba(255,255,255,0.12)'; c.fillRect(0, 0, w * 0.3, h);
    c.fillStyle = '#f6f4ee'; c.fillRect(16, 60, w - 32, 170); c.strokeStyle = '#aaa'; c.strokeRect(16, 60, w - 32, 170);
    const labels = ['فاکتورها', 'شیفت شب', 'موجودی', 'تحویل سوخت', 'حسابداری'];
    c.save(); c.translate(w / 2, 145); c.rotate(-Math.PI / 2); txt(c, labels[i % labels.length], 0, 0, 22, '#222', '900'); c.restore();
    txt(c, `${1400 + i}`, w / 2, 210, 16, '#444', 'bold');
    c.fillStyle = '#ddd'; c.beginPath(); c.arc(w / 2, h - 80, 18, 0, Math.PI * 2); c.fill(); c.fillStyle = '#222'; c.beginPath(); c.arc(w / 2, h - 80, 10, 0, Math.PI * 2); c.fill();
  }),
  invoice: () => T('invoice', 256, 360, (c, w, h) => {
    c.fillStyle = '#fbfaf6'; c.fillRect(0, 0, w, h);
    c.fillStyle = '#0d3a6a'; c.fillRect(0, 0, w, 40); txt(c, 'فاکتور فروش — پترو ۲۴', w / 2, 20, 18, '#fff', '900');
    for (let r = 0; r < 14; r++) { c.fillStyle = r % 2 ? '#f0f0ec' : '#fff'; c.fillRect(12, 56 + r * 18, w - 24, 18); c.fillStyle = '#555'; c.fillRect(w - 40, 61 + r * 18, 24, 6); c.fillRect(20, 61 + r * 18, 60 + rnd() * 60, 6); }
    c.strokeStyle = 'rgba(160,20,30,0.7)'; c.lineWidth = 3; c.beginPath(); c.arc(70, 330, 26, 0, Math.PI * 2); c.stroke(); txt(c, 'پرداخت شد', 70, 330, 11, 'rgba(160,20,30,0.8)', '900');
  }),
  spine: (i: number) => T('bookspine' + i, 64, 256, (c, w, h) => {
    const cols = ['#5a1a1a', '#1a2a4a', '#2a4a2a', '#4a3a1a', '#1a1a1a', '#6a4a2a', '#3a1a3a', '#c8b890', '#7a2a1a', '#1a3a3a', '#8a7a5a', '#2a2a3a'];
    const titles = ['شاهنامه', 'دیوان حافظ', 'بوف کور', 'کلیدر', 'سووشون', 'مثنوی', 'گلستان', 'جای خالی سلوچ', 'سمفونی مردگان', 'رستم و سهراب', 'بینوایان', 'جنایت و مکافات'];
    const g = c.createLinearGradient(0, 0, w, 0); g.addColorStop(0, 'rgba(0,0,0,0.35)'); g.addColorStop(0.3, 'rgba(255,255,255,0.08)'); g.addColorStop(1, 'rgba(0,0,0,0.3)');
    c.fillStyle = cols[i % cols.length]; c.fillRect(0, 0, w, h); c.fillStyle = g; c.fillRect(0, 0, w, h);
    const gold = i % 3 === 0 ? '#d8b860' : '#efe6d0';
    c.fillStyle = gold; c.fillRect(0, 18, w, 3); c.fillRect(0, 26, w, 1.5); c.fillRect(0, h - 22, w, 3); c.fillRect(0, h - 30, w, 1.5);
    c.save(); c.translate(w / 2, h / 2); c.rotate(-Math.PI / 2); txt(c, titles[i % titles.length], 0, 0, 20, gold, '900'); c.restore();
    for (let k = 0; k < 200; k++) { c.fillStyle = `rgba(0,0,0,${rnd() * 0.12})`; c.fillRect(rnd() * w, rnd() * h, 1, 1); }
  }),
  pages: () => T('pages', 64, 64, (c, w, h) => { c.fillStyle = '#ece4cc'; c.fillRect(0, 0, w, h); for (let y = 0; y < h; y += 2) { c.fillStyle = `rgba(120,100,60,${0.06 + rnd() * 0.06})`; c.fillRect(0, y, w, 1); } }),
};

// ---------------- reusable models ----------------
const rb = new Map<string, THREE.BufferGeometry>();
export function rbox(w: number, h: number, d: number, r = 0.01) { const k = [w, h, d, r].map((v) => v.toFixed(3)).join('_'); let g = rb.get(k); if (!g) { g = new RoundedBoxGeometry(w, h, d, 2, r); rb.set(k, g); } return g; }

/** stainless pedal / push-flap bin with black liner bag rolled over the rim */
export function steelBin(h = 0.78) {
  const g = new THREE.Group();
  const steel = mat({ map: tex.metal(), color: 0xd8dcdf, metal: 0.92, rough: 0.22, key: 'bin-steel' });
  const black = mat({ color: 0x111112, rough: 0.35, key: 'bin-black' });
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.15, h, 28, 1, true), steel); (body.material as THREE.Material).side = THREE.DoubleSide; body.position.y = h / 2; g.add(body);
  const bottom = new THREE.Mesh(new THREE.CylinderGeometry(0.155, 0.155, 0.02, 24), black); bottom.position.y = 0.01; g.add(bottom);
  const liner = new THREE.Mesh(new THREE.TorusGeometry(0.172, 0.012, 6, 28), mat({ color: 0x0b0b0c, rough: 0.2, metal: 0.1, key: 'bin-liner' })); liner.rotation.x = Math.PI / 2; liner.position.y = h - 0.01; g.add(liner);
  const lid = new THREE.Mesh(new THREE.SphereGeometry(0.175, 28, 10, 0, Math.PI * 2, 0, Math.PI / 2.6), steel); lid.position.y = h; lid.scale.y = 0.55; g.add(lid);
  const flap = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.08, 0.01), black); flap.position.set(0, h + 0.05, 0.13); flap.rotation.x = -0.6; g.add(flap);
  const pedal = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.02, 0.07), black); pedal.position.set(0, 0.035, 0.17); g.add(pedal);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.153, 0.008, 6, 28), black); ring.rotation.x = Math.PI / 2; ring.position.y = 0.03; g.add(ring);
  return g;
}

/** 240 L wheelie bin (outdoor) */
export function wheelieBin(color = 0x1f5a2a) {
  const g = new THREE.Group();
  const plast = mat({ color, rough: 0.55, key: 'wb' + color });
  const dark = mat({ color: 0x141414, rough: 0.6, key: 'wb-dark' });
  const body = new THREE.Mesh(rbox(0.58, 0.92, 0.72, 0.03), plast); body.position.set(0, 0.5, 0); body.scale.set(1, 1, 1); g.add(body);
  // taper (narrower at the bottom)
  const p = (body.geometry as THREE.BufferGeometry).clone(); const pa = p.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pa.count; i++) { const y = pa.getY(i); const k = 0.86 + (y + 0.46) / 0.92 * 0.14; pa.setX(i, pa.getX(i) * k); pa.setZ(i, pa.getZ(i) * k); }
  p.computeVertexNormals(); body.geometry = p;
  const lid = new THREE.Mesh(rbox(0.62, 0.05, 0.78, 0.02), plast); lid.position.set(0, 0.985, 0.02); lid.rotation.x = -0.03; g.add(lid);
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.5, 8).rotateZ(Math.PI / 2), dark); handle.position.set(0, 0.97, -0.4); g.add(handle);
  for (const sx of [-0.24, 0.24]) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.05, 16).rotateZ(Math.PI / 2), dark); w.position.set(sx, 0.1, -0.33); g.add(w); }
  const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.56, 6).rotateZ(Math.PI / 2), dark); axle.position.set(0, 0.1, -0.33); g.add(axle);
  for (let k = 0; k < 3; k++) { const rib = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.015, 0.005), dark); rib.position.set(0, 0.35 + k * 0.18, 0.345); g.add(rib); }
  return g;
}

/** steel commercial dumpster (1100 L) with two lids, lifting pockets and caster wheels */
export function dumpster() {
  const g = new THREE.Group();
  const steel = mat({ map: tex.metal(), color: 0x2a5a32, metal: 0.55, rough: 0.55, key: 'dump-steel' });
  const dark = mat({ color: 0x1a1a1a, rough: 0.6, key: 'wb-dark' });
  const body = new THREE.Mesh(rbox(2.3, 1.15, 1.25, 0.04), steel); body.position.y = 0.72; g.add(body);
  for (const sx of [-0.57, 0.57]) { const lid = new THREE.Mesh(rbox(1.12, 0.06, 1.32, 0.02), mat({ color: 0x141414, rough: 0.4, key: 'dump-lid' })); lid.position.set(sx, 1.33, 0); lid.rotation.x = sx > 0 ? -0.05 : 0; g.add(lid); }
  for (const sz of [-0.63, 0.63]) { const pocket = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.12, 0.06), dark); pocket.position.set(0, 1.0, sz); g.add(pocket); }
  for (const [x, z] of [[-1.0, -0.5], [1.0, -0.5], [-1.0, 0.5], [1.0, 0.5]]) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.05, 14).rotateX(Math.PI / 2), dark); w.position.set(x, 0.08, z); g.add(w); }
  const rust = new THREE.MeshBasicMaterial({ map: tex.glow(), color: 0x2a1408, transparent: true, opacity: 0.55, depthWrite: false });
  for (let k = 0; k < 4; k++) { const r = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.4), rust); r.position.set(-0.9 + k * 0.6, 0.45 + Math.random() * 0.4, 0.628); g.add(r); }
  return g;
}

/** classic 20 L jerry can: embossed X panels, triple handle, hinged spout cap */
export function jerryCan(color = 0xb81414) {
  const g = new THREE.Group();
  const paint = mat({ color, metal: 0.45, rough: 0.42, key: 'jerry' + color });
  const dark = mat({ color: 0x1a1a1a, metal: 0.6, rough: 0.4, key: 'jerry-dark' });
  const body = new THREE.Mesh(rbox(0.34, 0.46, 0.165, 0.025), paint); body.position.y = 0.25; g.add(body);
  // embossed "X" on both faces + rim seam
  for (const sz of [-1, 1]) for (const r of [0.62, -0.62]) {
    const x = new THREE.Mesh(rbox(0.38, 0.03, 0.012, 0.006), paint); x.position.set(0, 0.24, sz * 0.084); x.rotation.z = r; g.add(x);
  }
  const seam = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.47, 0.012), paint); seam.position.y = 0.25; g.add(seam);
  // three-bar handle
  for (const hx of [-0.09, 0, 0.09]) { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.011, 0.07, 8), paint); b.position.set(hx, 0.51, 0); g.add(b); }
  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.24, 10).rotateZ(Math.PI / 2), paint); grip.position.set(0, 0.55, 0); g.add(grip);
  // spout with cap & lever
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.035, 0.05, 14), dark); neck.position.set(0.13, 0.5, 0); neck.rotation.z = -0.5; g.add(neck);
  const capM = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.036, 0.03, 14), paint); capM.position.set(0.147, 0.525, 0); capM.rotation.z = -0.5; g.add(capM);
  const lever = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.06, 0.02), dark); lever.position.set(0.11, 0.54, 0.04); g.add(lever);
  const label = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 0.06), new THREE.MeshStandardMaterial({ map: T('jerrylabel', 128, 64, (c, w, h) => { c.fillStyle = '#f2c400'; c.fillRect(0, 0, w, h); txt(c, 'بنزین', w / 2, h * 0.38, 22, '#111'); txt(c, '⚠ قابل اشتعال', w / 2, h * 0.78, 12, '#111', 'bold'); }), roughness: 0.5 }));
  label.position.set(-0.07, 0.36, 0.0905); g.add(label);
  return g;
}

/** realistic hardcover books row: varied heights/thickness, gold-tooled spines, page block, a few leaning */
export function bookRow(parent: THREE.Object3D, x0: number, x1: number, y: number, z: number, facing: 1 | -1, axis: 'x' | 'z' = 'x') {
  const pagesM = new THREE.MeshStandardMaterial({ map: rt.pages(), roughness: 0.9 });
  let a = x0; let i = Math.floor(Math.random() * 12);
  while (a < x1 - 0.03) {
    const th = 0.025 + Math.random() * 0.035, ht = 0.2 + Math.random() * 0.09, dp = 0.15 + Math.random() * 0.05;
    if (a + th > x1) break;
    const spine = new THREE.MeshStandardMaterial({ map: rt.spine(i++), roughness: 0.6, metalness: 0.05 });
    const cover = new THREE.MeshStandardMaterial({ color: (spine.map as THREE.Texture) ? 0x3a2a20 : 0x3a2a20, roughness: 0.7 });
    // box faces: +x,-x,+y,-y,+z,-z ; the spine faces the room
    const mats = axis === 'x' ? (facing > 0 ? [cover, cover, pagesM, pagesM, spine, pagesM] : [cover, cover, pagesM, pagesM, pagesM, spine]) : (facing > 0 ? [spine, pagesM, pagesM, pagesM, cover, cover] : [pagesM, spine, pagesM, pagesM, cover, cover]);
    const b = new THREE.Mesh(axis === 'x' ? new THREE.BoxGeometry(th, ht, dp) : new THREE.BoxGeometry(dp, ht, th), mats);
    const lean = Math.random() < 0.07 ? 0.25 : 0;
    if (axis === 'x') { b.position.set(a + th / 2, y + ht / 2, z); b.rotation.z = lean; } else { b.position.set(z, y + ht / 2, a + th / 2); b.rotation.x = lean; }
    parent.add(b);
    a += th + (lean ? 0.06 : 0.002);
    if (Math.random() < 0.05) a += 0.08; // gap
  }
}

// ---------------- store revamp ----------------
export interface RevampOpts { group: THREE.Group; dyn: THREE.Group; col: Collision; reg: (m: THREE.Material) => void; regLight: (l: THREE.Light) => void; q: string }
export function revampStore(o: RevampOpts) {
  const { group, dyn, col, reg, q } = o;
  const add = (g: THREE.BufferGeometry, m: THREE.Material | THREE.Material[], x: number, y: number, z: number, parent: THREE.Object3D = group) => { const me = new THREE.Mesh(g, m as THREE.Material); me.position.set(x, y, z); parent.add(me); return me; };
  // 1. polished porcelain floor (sales) – reflective
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(27.8, 8.8), new THREE.MeshStandardMaterial({ map: rt.porcelain(), roughness: 0.14, metalness: 0.05, envMapIntensity: 1.4 }));
  floor.rotation.x = -Math.PI / 2; floor.position.set(0, 0.058, -0.5); group.add(floor);
  // entrance logo mat
  const matT = T('logomat', 512, 256, (c, w, h) => { c.fillStyle = '#1a1a1c'; c.fillRect(0, 0, w, h); c.strokeStyle = '#c8141f'; c.lineWidth = 10; c.strokeRect(14, 14, w - 28, h - 28); txt(c, 'PETRO 24', w / 2, h * 0.42, 70, '#ffffff'); txt(c, 'خوش آمدید', w / 2, h * 0.75, 34, '#c8141f'); for (let i = 0; i < 6000; i++) { c.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`; c.fillRect(Math.random() * w, Math.random() * h, 1, 1); } });
  const lmat = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 1.0), new THREE.MeshStandardMaterial({ map: matT, roughness: 1 })); lmat.rotation.x = -Math.PI / 2; lmat.position.set(0, 0.075, 3.1); group.add(lmat);
  // 2. branded wall cladding (inner faces of the sales walls)
  const clad = new THREE.MeshStandardMaterial({ map: rt.cladding(), roughness: 0.55 });
  const wallPlane = (w: number, x: number, z: number, ry: number) => { const t = rt.cladding().clone(); t.repeat.set(w / 9, 1); t.needsUpdate = true; const m = new THREE.Mesh(new THREE.PlaneGeometry(w, 3.1), new THREE.MeshStandardMaterial({ map: t, roughness: 0.55 })); m.position.set(x, 1.55, z); m.rotation.y = ry; group.add(m); };
  void clad;
  // segments avoid every door opening (storage −8, corridor 0, office 11) and the tools pegboard
  wallPlane(5.3, -11.25, -4.894, 0); wallPlane(6.6, -4.1, -4.894, 0); wallPlane(9.6, 5.6, -4.894, 0); wallPlane(2.3, 12.85, -4.894, 0);
  // door openings: the cladding must not cover them → the 2.3 m high openings are cut by placing a lintel strip only
  for (const dx of [-8, 0, 11]) { const w = dx === 0 ? 1.6 : 1.2; const t = rt.cladding().clone(); t.repeat.set(w / 9, 0.26); t.offset.y = 0.74; t.needsUpdate = true; const m = new THREE.Mesh(new THREE.PlaneGeometry(w, 0.8), new THREE.MeshStandardMaterial({ map: t, roughness: 0.55 })); m.position.set(dx, 2.7, -4.894); group.add(m); }
  wallPlane(4.5, 13.894, 1.65, -Math.PI / 2);
  // 3. drop ceiling + linear LED troffers along the aisles
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(27.8, 8.8), new THREE.MeshStandardMaterial({ map: rt.ceiling(), roughness: 0.95 })); ceil.rotation.x = Math.PI / 2; ceil.position.set(0, 3.1, -0.5); group.add(ceil);
  const led = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xf4f8ff, emissiveIntensity: 2.2 }); reg(led);
  const housing = mat({ color: 0xd8dadc, metal: 0.6, rough: 0.35, key: 'led-housing' });
  for (const z of [-3.4, -0.6, 2.2]) for (const x of [-8.5, -3.5, 3.5, 9.5]) {
    add(new THREE.BoxGeometry(3.6, 0.05, 0.14), housing, x, 3.06, z);
    add(new THREE.BoxGeometry(3.5, 0.012, 0.09), led, x, 3.03, z);
  }
  // 4. hanging aisle signs (double sided)
  const sign = (fa: string, en: string, col: string, x: number, z: number, ry = 0) => {
    const g = new THREE.Group(); g.position.set(x, 2.55, z); g.rotation.y = ry; group.add(g);
    for (const sx of [-0.5, 0.5]) add(new THREE.CylinderGeometry(0.004, 0.004, 0.5, 4), housing, sx, 0.33, 0, g);
    const m = new THREE.MeshStandardMaterial({ map: rt.aisleSign(fa, en, col), emissive: 0xffffff, emissiveMap: rt.aisleSign(fa, en, col), emissiveIntensity: 0.25, roughness: 0.4 }); reg(m);
    add(rbox(1.2, 0.38, 0.03, 0.01), [housing, housing, housing, housing, m, m] as unknown as THREE.Material, 0, 0, 0, g);
  };
  sign('تنقلات', 'SNACKS • CHIPS', '#c8141f', -6.5, -0.6);
  sign('نوشیدنی سرد', 'COLD DRINKS', '#1f6ac4', -12.2, -0.6, Math.PI / 2);
  sign('ابزار و خودرو', 'AUTO • TOOLS', '#e0a000', 12.8, -2.6, -Math.PI / 2);
  sign('بستنی', 'ICE CREAM', '#2a8cff', 11.4, -0.4);
  // 5. checkout redesign: branded front panel, quartz top, register, back bar, documents, safe
  const cf = new THREE.MeshStandardMaterial({ map: rt.counterFront(), roughness: 0.4, emissive: 0xffffff, emissiveMap: rt.counterFront(), emissiveIntensity: 0.08 });
  const front = new THREE.Mesh(new THREE.PlaneGeometry(5.02, 0.98), cf); front.position.set(5.5, 0.5, 1.206); group.add(front);
  const quartz = new THREE.MeshStandardMaterial({ color: 0xece8e2, roughness: 0.18, metalness: 0.05, envMapIntensity: 1.2 });
  add(rbox(5.16, 0.035, 0.94, 0.012), quartz, 5.5, 1.04, 0.8);
  const kick = mat({ color: 0x9aa0a6, metal: 0.8, rough: 0.3, key: 'kick' }); add(new THREE.BoxGeometry(5.02, 0.08, 0.02), kick, 5.5, 0.04, 1.21);
  cashRegister(dyn, 5.35, 1.058, 0.62, reg);
  // facade: aluminium composite panels above the shopfront + red LED contour strip
  const acm = T('acm', 1024, 64, (c, w, h) => { c.fillStyle = '#2b2e33'; c.fillRect(0, 0, w, h); for (let x = 0; x < w; x += 128) { c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(x, 0, 3, h); c.fillStyle = 'rgba(255,255,255,0.08)'; c.fillRect(x + 3, 0, 2, h); } const g2 = c.createLinearGradient(0, 0, 0, h); g2.addColorStop(0, 'rgba(255,255,255,0.12)'); g2.addColorStop(1, 'rgba(0,0,0,0.2)'); c.fillStyle = g2; c.fillRect(0, 0, w, h); });
  acm.repeat.set(2, 1);
  const facade = new THREE.Mesh(new THREE.PlaneGeometry(28.3, 0.62), new THREE.MeshStandardMaterial({ map: acm, metalness: 0.6, roughness: 0.3 })); facade.position.set(0, 2.9, 4.131); group.add(facade);
  const ledR = new THREE.MeshStandardMaterial({ color: 0xff2030, emissive: 0xff1020, emissiveIntensity: 2.4 }); reg(ledR);
  add(new THREE.BoxGeometry(28.3, 0.03, 0.03), ledR, 0, 2.6, 4.15);
  add(new THREE.BoxGeometry(28.3, 0.03, 0.03), ledR, 0, 3.22, 4.15);
  // back bar: cigarette wall face + glass doors + documents desk + safe
  const cig = new THREE.MeshStandardMaterial({ map: rt.cigs(), roughness: 0.45, emissive: 0xffffff, emissiveMap: rt.cigs(), emissiveIntensity: 0.12 }); reg(cig);
  const cigP = new THREE.Mesh(new THREE.PlaneGeometry(3.8, 1.25), cig); cigP.position.set(5.5, 1.3, -1.395); group.add(cigP);
  const shutter = new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.12, roughness: 0.02, depthWrite: false });
  add(new THREE.PlaneGeometry(3.8, 1.25), shutter, 5.5, 1.3, -1.385);
  add(new THREE.BoxGeometry(3.9, 0.06, 0.46), housing, 5.5, 2.0, -1.6);
  const desk = mat({ map: tex.wood(), color: 0x3a2a20, rough: 0.5, key: 'backdesk' });
  add(new THREE.BoxGeometry(1.15, 0.85, 0.32), desk, 4.15, 0.425, -1.23); col.addCentered(4.15, -1.23, 1.15, 0.32, { sight: false, maxY: 0.9 });
  // binders
  for (let i = 0; i < 6; i++) { const bt = rt.binderSpine(i); const bm = new THREE.MeshStandardMaterial({ map: bt, roughness: 0.5 }); const side = mat({ color: [0x1d4fa8, 0xc41e1e, 0x2a7a3a, 0x2a2a2a, 0xd8a020][i % 5], rough: 0.5, key: 'binder' + (i % 5) }); const b = add(new THREE.BoxGeometry(0.075, 0.31, 0.26), [side, side, side, side, bm, side] as unknown as THREE.Material, 3.67 + i * 0.08, 1.0, -1.24, dyn); b.rotation.y = (i === 5 ? 0.2 : 0); }
  // invoices stack, clipboard, stapler, calculator, pen cup
  const inv = new THREE.MeshStandardMaterial({ map: rt.invoice(), roughness: 0.9 });
  for (let k = 0; k < 4; k++) { const p = add(new THREE.PlaneGeometry(0.21, 0.297), inv, 4.35 + (Math.random() - 0.5) * 0.02, 0.853 + k * 0.002, -1.2, dyn); p.rotation.set(-Math.PI / 2, 0, (Math.random() - 0.5) * 0.3); }
  const clip = add(new THREE.BoxGeometry(0.23, 0.008, 0.32), mat({ color: 0x5a3a20, rough: 0.6, key: 'clipboard' }), 4.68, 0.856, -1.2, dyn); clip.rotation.y = 0.3;
  const clipP = add(new THREE.PlaneGeometry(0.2, 0.28), inv, 4.68, 0.862, -1.2, dyn); clipP.rotation.set(-Math.PI / 2, 0, 0.3);
  add(new THREE.BoxGeometry(0.15, 0.03, 0.04), mat({ color: 0x1a1a1a, metal: 0.5, key: 'stapler' }), 3.75, 0.865, -1.15, dyn);
  const calc = add(new THREE.BoxGeometry(0.1, 0.015, 0.15), mat({ color: 0x2a2a2c, rough: 0.5, key: 'calc' }), 3.92, 0.86, -1.15, dyn); calc.rotation.y = -0.2;
  add(new THREE.CylinderGeometry(0.035, 0.03, 0.1, 12), mat({ color: 0x1a1a1a, rough: 0.5, key: 'pencup' }), 3.66, 0.9, -1.32, dyn);
  for (let k = 0; k < 4; k++) { const pn = add(new THREE.CylinderGeometry(0.004, 0.004, 0.14, 6), mat({ color: [0x1d4fa8, 0xc41e1e, 0x111111, 0x2a7a3a][k], key: 'pen' + k }), 3.66 + (k - 1.5) * 0.008, 0.98, -1.32, dyn); pn.rotation.z = (k - 1.5) * 0.15; }
  // small steel safe under the desk & key box
  const safe = new THREE.Group(); safe.position.set(4.6, 0, -1.05); group.add(safe);
  add(rbox(0.42, 0.42, 0.4, 0.02), mat({ color: 0x3a3c40, metal: 0.7, rough: 0.35, key: 'safe' }), 0, 0.21, 0, safe);
  add(new THREE.CylinderGeometry(0.045, 0.045, 0.02, 20).rotateX(Math.PI / 2), mat({ color: 0xb8bcc0, metal: 1, rough: 0.2, key: 'safedial' }), 0.05, 0.25, 0.205, safe);
  add(new THREE.BoxGeometry(0.06, 0.012, 0.02), mat({ color: 0xb8bcc0, metal: 1, rough: 0.2, key: 'safedial' }), -0.1, 0.25, 0.21, safe);
  void q;
}

/** realistic cash register: customer pole display, angled keypad, receipt printer w/ paper, open cash drawer with banknotes & coins */
export function cashRegister(parent: THREE.Object3D, x: number, y: number, z: number, reg: (m: THREE.Material) => void) {
  const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = Math.PI; parent.add(g); // faces the cashier (−z)
  const body = mat({ color: 0x1c1d20, rough: 0.35, metal: 0.25, key: 'creg' });
  const add = (geo: THREE.BufferGeometry, m: THREE.Material, px: number, py: number, pz: number, rx = 0) => { const o = new THREE.Mesh(geo, m); o.position.set(px, py, pz); o.rotation.x = rx; g.add(o); return o; };
  add(rbox(0.42, 0.11, 0.44, 0.01), body, 0, 0.055, 0);                     // cash drawer housing
  const drawer = add(rbox(0.38, 0.08, 0.36, 0.008), mat({ color: 0x2a2b2f, rough: 0.4, metal: 0.3, key: 'creg-dr' }), 0, 0.045, 0.2); // pulled out
  void drawer;
  const trayM = mat({ color: 0x0e0e10, rough: 0.6, key: 'creg-tray' });
  add(new THREE.BoxGeometry(0.36, 0.005, 0.2), trayM, 0, 0.088, 0.27);
  const notes: [string, string][] = [['#c8a060', '۱۰۰٬۰۰۰'], ['#7a5aa0', '۵۰٬۰۰۰'], ['#3a8a5a', '۲۰٬۰۰۰'], ['#c86a3a', '۱۰٬۰۰۰'], ['#5a8ac8', '۵٬۰۰۰']];
  notes.forEach(([colr, val], i) => {
    const nm = new THREE.MeshStandardMaterial({ map: rt.banknote(colr, val), roughness: 0.85 });
    for (let k = 0; k < 4; k++) { const n = add(new THREE.PlaneGeometry(0.062, 0.13), nm, -0.14 + i * 0.07, 0.092 + k * 0.0015, 0.27 + (Math.random() - 0.5) * 0.01, -Math.PI / 2); n.rotation.z = (Math.random() - 0.5) * 0.06; }
    const clip = add(new THREE.BoxGeometry(0.01, 0.02, 0.06), mat({ color: 0x9aa0a6, metal: 0.9, rough: 0.3, key: 'creg-clip' }), -0.14 + i * 0.07, 0.1, 0.33); void clip;
  });
  const coinM = mat({ color: 0xc8a050, metal: 1, rough: 0.3, key: 'coin' });
  for (let k = 0; k < 14; k++) add(new THREE.CylinderGeometry(0.011, 0.011, 0.003, 12), coinM, -0.15 + (k % 7) * 0.05, 0.093 + Math.floor(k / 7) * 0.003, 0.36);
  // terminal top: angled keypad + operator screen
  add(rbox(0.36, 0.08, 0.26, 0.01), body, 0, 0.15, -0.06, -0.2);
  const keyM = mat({ color: 0xd8dcde, rough: 0.4, key: 'creg-key' }), fKey = mat({ color: 0x2a7ad8, rough: 0.4, key: 'creg-fk' }), totK = mat({ color: 0x2aa84a, rough: 0.4, key: 'creg-tot' });
  const kg = rbox(0.03, 0.012, 0.026, 0.004);
  for (let r = 0; r < 5; r++) for (let k = 0; k < 7; k++) { const m = k > 4 ? fKey : r === 4 && k === 4 ? totK : keyM; add(kg, m, -0.12 + k * 0.036, 0.195 + r * 0.006, -0.13 + r * 0.032, -0.2); }
  const scrCv = document.createElement('canvas'); scrCv.width = 256; scrCv.height = 128; const sc = scrCv.getContext('2d')!;
  sc.fillStyle = '#071a10'; sc.fillRect(0, 0, 256, 128); sc.fillStyle = '#5fff9a'; sc.font = 'bold 22px monospace'; sc.fillText('TOTAL', 12, 34); sc.font = 'bold 36px monospace'; sc.fillText('187,500', 12, 84); sc.font = '900 16px Vazirmatn, Tahoma'; sc.direction = 'rtl'; sc.fillText('ریال', 244, 110);
  const st = new THREE.CanvasTexture(scrCv); st.colorSpace = THREE.SRGBColorSpace;
  const sm = new THREE.MeshStandardMaterial({ map: st, emissive: 0xffffff, emissiveMap: st, emissiveIntensity: 0.8 }); reg(sm);
  add(rbox(0.26, 0.16, 0.025, 0.008), body, 0, 0.32, -0.22, -0.35);
  add(new THREE.PlaneGeometry(0.23, 0.13), sm, 0, 0.322, -0.205, -0.35);
  // customer pole display (faces the customer)
  add(new THREE.CylinderGeometry(0.012, 0.012, 0.3, 8), body, 0.17, 0.3, -0.2);
  const cd = add(rbox(0.18, 0.06, 0.04, 0.008), body, 0.17, 0.47, -0.2);
  const cdm = new THREE.MeshStandardMaterial({ map: (() => { const cv = document.createElement('canvas'); cv.width = 128; cv.height = 40; const c = cv.getContext('2d')!; c.fillStyle = '#021208'; c.fillRect(0, 0, 128, 40); c.fillStyle = '#3aff7a'; c.font = 'bold 20px monospace'; c.fillText('187,500', 8, 28); const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t; })(), emissive: 0xffffff, emissiveIntensity: 0.6 }); reg(cdm);
  cdm.emissiveMap = cdm.map;
  const cdp = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.045), cdm); cdp.position.set(0, 0, -0.021); cdp.rotation.y = Math.PI; cd.add(cdp);
  // receipt printer with curled paper
  add(rbox(0.12, 0.1, 0.14, 0.01), body, -0.16, 0.16, -0.2);
  const paper = add(new THREE.PlaneGeometry(0.075, 0.12), mat({ color: 0xf8f6f0, rough: 0.9, key: 'receipt' }), -0.16, 0.24, -0.15, -0.6); (paper.material as THREE.Material).side = THREE.DoubleSide;
  return g;
}
