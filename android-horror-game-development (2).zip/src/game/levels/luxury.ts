// Luxury interior for Arash & Mina's house + a spreading house-fire system (chapter 7)
import * as THREE from 'three';
import { mat, tex } from '../textures';
import { hiCanvas, finishTex } from '../gfx';
import { registerLight } from '../lightpool';
import type { Collision } from '../physics';
import { bookRow } from '../storeRevamp';

const cache = new Map<string, THREE.CanvasTexture>();
let seed = 1; const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
function T(key: string, w: number, h: number, draw: (c: CanvasRenderingContext2D, w: number, h: number) => void, repeat?: [number, number]) {
  const hit = cache.get(key); if (hit) return hit;
  const { cv, c } = hiCanvas(w, h); seed = key.length * 131 + 7; draw(c, w, h);
  const t = finishTex(new THREE.CanvasTexture(cv)); t.wrapS = t.wrapT = THREE.RepeatWrapping; if (repeat) t.repeat.set(...repeat);
  cache.set(key, t); return t;
}
export const lux = {
  herringbone: () => T('herring', 512, 512, (c, w, h) => {
    c.fillStyle = '#5a3a22'; c.fillRect(0, 0, w, h);
    const pw = 32, pl = 128;
    for (let y = -pl; y < h + pl; y += pw) for (let x = -pl; x < w + pl; x += pl) {
      for (const flip of [0, 1]) {
        c.save(); c.translate(x + flip * pw + (y / pw) % 2 * 0, y + flip * pw); c.rotate(flip ? -Math.PI / 4 : Math.PI / 4);
        const b = 120 + rnd() * 50; c.fillStyle = `rgb(${b},${b * 0.68},${b * 0.42})`; c.fillRect(0, 0, pl, pw - 2);
        c.strokeStyle = 'rgba(40,20,8,0.18)'; for (let k = 0; k < 4; k++) { c.beginPath(); c.moveTo(0, 4 + k * 7 + rnd() * 3); c.lineTo(pl, 4 + k * 7 + rnd() * 3); c.stroke(); }
        c.restore();
      }
    }
    const g = c.createLinearGradient(0, 0, w, h); g.addColorStop(0, 'rgba(255,255,255,0.06)'); g.addColorStop(1, 'rgba(0,0,0,0.06)'); c.fillStyle = g; c.fillRect(0, 0, w, h);
  }, [2.5, 2]),
  marble: () => T('marble', 512, 512, (c, w, h) => {
    c.fillStyle = '#ece8e2'; c.fillRect(0, 0, w, h);
    for (let i = 0; i < 26; i++) {
      c.strokeStyle = `rgba(${90 + rnd() * 50},${85 + rnd() * 40},${80 + rnd() * 40},${0.12 + rnd() * 0.25})`; c.lineWidth = 0.6 + rnd() * 2.2;
      c.beginPath(); let x = rnd() * w, y = rnd() * h; c.moveTo(x, y);
      for (let k = 0; k < 14; k++) { x += (rnd() - 0.3) * 60; y += (rnd() - 0.5) * 40; c.lineTo(x, y); } c.stroke();
    }
    c.fillStyle = 'rgba(180,150,90,0.05)'; for (let i = 0; i < 40; i++) { c.beginPath(); c.arc(rnd() * w, rnd() * h, 20 + rnd() * 60, 0, Math.PI * 2); c.fill(); }
    c.strokeStyle = 'rgba(120,110,100,0.35)'; c.lineWidth = 2; c.strokeRect(0, 0, w, h); // tile joints
  }, [3, 2]),
  wainscot: () => T('wainscot', 512, 512, (c, w, h) => {
    c.fillStyle = '#e9e1d2'; c.fillRect(0, 0, w, h);
    c.fillStyle = '#f4efe6'; c.fillRect(0, h * 0.64, w, h * 0.36);
    for (let x = 16; x < w; x += 128) { c.strokeStyle = 'rgba(120,100,70,0.35)'; c.lineWidth = 3; c.strokeRect(x, h * 0.69, 96, h * 0.26); c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 1.5; c.strokeRect(x + 3, h * 0.69 + 3, 90, h * 0.26 - 6); }
    c.fillStyle = '#d8ccb8'; c.fillRect(0, h * 0.63, w, 8); c.fillStyle = '#cdbfa8'; c.fillRect(0, h - 14, w, 14);
    for (let i = 0; i < 4000; i++) { c.fillStyle = `rgba(0,0,0,${rnd() * 0.03})`; c.fillRect(rnd() * w, rnd() * h * 0.62, 2, 2); }
  }, [2, 1]),
  velvet: () => T('velvet', 256, 256, (c, w, h) => {
    const g = c.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#1e5a4a'); g.addColorStop(0.5, '#2b7360'); g.addColorStop(1, '#174a3c'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    for (let i = 0; i < 6000; i++) { c.fillStyle = `rgba(255,255,255,${rnd() * 0.05})`; c.fillRect(rnd() * w, rnd() * h, 1, 2); }
    for (let x = 32; x < w; x += 64) for (let y = 32; y < h; y += 64) { c.fillStyle = 'rgba(0,0,0,0.35)'; c.beginPath(); c.arc(x, y, 3, 0, Math.PI * 2); c.fill(); } // tufting
  }, [2, 1]),
  stone: () => T('stone', 512, 512, (c, w, h) => {
    c.fillStyle = '#6a625a'; c.fillRect(0, 0, w, h);
    let y = 0; while (y < h) { const rh = 30 + rnd() * 30; let x = -rnd() * 60; while (x < w) { const rw = 50 + rnd() * 90; const b = 150 + rnd() * 60; c.fillStyle = `rgb(${b},${b * 0.93},${b * 0.84})`; c.fillRect(x + 2, y + 2, rw - 4, rh - 4); c.fillStyle = 'rgba(0,0,0,0.12)'; c.fillRect(x + 2, y + rh - 8, rw - 4, 6); x += rw; } y += rh; }
  }, [3, 1.2]),
  rug: () => T('rug', 512, 384, (c, w, h) => {
    c.fillStyle = '#7a1420'; c.fillRect(0, 0, w, h);
    c.strokeStyle = '#0e1e4a'; c.lineWidth = 26; c.strokeRect(20, 20, w - 40, h - 40);
    c.strokeStyle = '#d8b46a'; c.lineWidth = 4; c.strokeRect(36, 36, w - 72, h - 72); c.strokeRect(8, 8, w - 16, h - 16);
    for (let x = 30; x < w - 30; x += 22) { c.fillStyle = '#d8b46a'; c.beginPath(); c.arc(x, 20, 5, 0, Math.PI * 2); c.arc(x, h - 20, 5, 0, Math.PI * 2); c.fill(); }
    c.save(); c.translate(w / 2, h / 2);
    for (let r = 0; r < 6; r++) { c.rotate(Math.PI / 3); c.fillStyle = r % 2 ? '#0e1e4a' : '#d8b46a'; c.beginPath(); c.ellipse(0, 50, 22, 60, 0, 0, Math.PI * 2); c.fill(); }
    c.fillStyle = '#f0e2c0'; c.beginPath(); c.arc(0, 0, 26, 0, Math.PI * 2); c.fill(); c.fillStyle = '#7a1420'; c.beginPath(); c.arc(0, 0, 12, 0, Math.PI * 2); c.fill();
    c.restore();
    for (let i = 0; i < 60; i++) { const x = 60 + rnd() * (w - 120), y = 60 + rnd() * (h - 120); if (Math.hypot(x - w / 2, y - h / 2) < 110) continue; c.fillStyle = ['#d8b46a', '#0e1e4a', '#2a6a4a', '#f0e2c0'][i % 4]; c.beginPath(); c.moveTo(x, y - 8); c.lineTo(x + 6, y); c.lineTo(x, y + 8); c.lineTo(x - 6, y); c.fill(); }
    for (let i = 0; i < 9000; i++) { c.fillStyle = `rgba(0,0,0,${rnd() * 0.08})`; c.fillRect(rnd() * w, rnd() * h, 1, 1); }
  }),
  painting: (i: number) => T('paint' + i, 256, 192, (c, w, h) => {
    if (i === 0) { const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#f2a65a'); g.addColorStop(0.6, '#c45a3a'); g.addColorStop(1, '#3a2a40'); c.fillStyle = g; c.fillRect(0, 0, w, h); c.fillStyle = '#2a1a2a'; c.beginPath(); c.moveTo(0, h); c.lineTo(70, 110); c.lineTo(140, 150); c.lineTo(210, 90); c.lineTo(w, 130); c.lineTo(w, h); c.fill(); c.fillStyle = '#ffe2a0'; c.beginPath(); c.arc(170, 70, 22, 0, Math.PI * 2); c.fill(); }
    else if (i === 1) { c.fillStyle = '#e8e0d0'; c.fillRect(0, 0, w, h); for (let k = 0; k < 14; k++) { c.fillStyle = ['#1e3a6a', '#c43a2a', '#e8b030', '#2a2a2a'][k % 4]; c.globalAlpha = 0.8; c.fillRect(rnd() * w, rnd() * h, 20 + rnd() * 80, 10 + rnd() * 60); } c.globalAlpha = 1; }
    else { c.fillStyle = '#1a2a3a'; c.fillRect(0, 0, w, h); c.strokeStyle = '#d8c070'; c.lineWidth = 3; for (let k = 0; k < 8; k++) { c.beginPath(); c.arc(w / 2, h / 2, 10 + k * 12, 0, Math.PI * 2); c.stroke(); } c.font = '900 40px Vazirmatn, Tahoma'; c.fillStyle = '#d8c070'; c.textAlign = 'center'; c.direction = 'rtl'; c.fillText('عشق', w / 2, h / 2 + 14); }
  }),
};

export interface LuxuryHandles { chandelier: THREE.PointLight; lamps: THREE.PointLight[]; tvScreenPos: THREE.Vector3 }

export function luxuryDecor(group: THREE.Group, col: Collision, q: string): LuxuryHandles {
  const add = (g: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, parent: THREE.Object3D = group) => { const o = new THREE.Mesh(g, m); o.position.set(x, y, z); parent.add(o); return o; };
  const gold = mat({ color: 0xc8a050, metal: 1, rough: 0.25, key: 'lux-gold' });
  const black = mat({ color: 0x111113, metal: 0.4, rough: 0.35, key: 'lux-black' });
  const walnut = mat({ map: tex.wood(), color: 0x6a4a30, rough: 0.45, key: 'lux-walnut' });
  // floors: marble in living / kitchen, rug under the coffee table, bedroom rug
  const marble = new THREE.Mesh(new THREE.PlaneGeometry(5.5, 6), mat({ map: lux.marble(), rough: 0.12, metal: 0.05, key: 'lux-marble' })); marble.rotation.x = -Math.PI / 2; marble.position.set(7.25, 0.05, 3); group.add(marble);
  const rug = new THREE.Mesh(new THREE.PlaneGeometry(2.8, 2.0), mat({ map: lux.rug(), rough: 1, key: 'lux-rug' })); rug.rotation.x = -Math.PI / 2; rug.position.set(6.4, 0.07, 1.8); group.add(rug);
  const rug2 = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.4), mat({ map: lux.rug(), color: 0xc8b8a8, rough: 1, key: 'lux-rug2' })); rug2.rotation.x = -Math.PI / 2; rug2.position.set(1.1, 0.07, 3.3); group.add(rug2);
  // crown moulding & skirting
  for (const [x, z, w, d] of [[5, 0.11, 10, 0.06], [5, 5.89, 10, 0.06], [0.11, 3, 0.06, 6], [9.89, 3, 0.06, 6]] as number[][]) {
    add(new THREE.BoxGeometry(w, 0.12, d), mat({ color: 0xf2ece0, rough: 0.5, key: 'lux-mould' }), x, 2.68, z);
    add(new THREE.BoxGeometry(w, 0.1, d), mat({ color: 0xe8e0d2, rough: 0.5, key: 'lux-skirt' }), x, 0.1, z);
  }
  // crystal chandelier (living)
  const ch = new THREE.Group(); ch.position.set(6.6, 2.2, 2.6); group.add(ch);
  add(new THREE.CylinderGeometry(0.01, 0.01, 0.55, 6), gold, 0, 0.3, 0, ch);
  add(new THREE.TorusGeometry(0.38, 0.015, 6, 28), gold, 0, 0, 0, ch).rotation.x = Math.PI / 2;
  add(new THREE.TorusGeometry(0.22, 0.012, 6, 20), gold, 0, -0.14, 0, ch).rotation.x = Math.PI / 2;
  const crystal = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff2d8, emissiveIntensity: 0.5, roughness: 0.02, metalness: 0.2, transparent: true, opacity: 0.85 });
  const cg = new THREE.OctahedronGeometry(0.03, 0);
  for (let i = 0; i < 24; i++) { const a = (i / 24) * Math.PI * 2; const r = i % 2 ? 0.38 : 0.22; const cy = i % 2 ? -0.08 : -0.22; const cr = add(cg, crystal, Math.cos(a) * r, cy, Math.sin(a) * r, ch); cr.scale.y = 1.8; }
  for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2; add(new THREE.CylinderGeometry(0.012, 0.012, 0.08, 8), new THREE.MeshBasicMaterial({ color: 0xfff0d0 }), Math.cos(a) * 0.38, 0.05, Math.sin(a) * 0.38, ch); }
  const chandelier = new THREE.PointLight(0xffe2b8, 0, 9, 2); chandelier.position.set(6.6, 2.05, 2.6); group.add(chandelier);
  // velvet sofa upgrade (covers the old block), cushions, glass coffee table
  const velvet = mat({ map: lux.velvet(), rough: 0.85, key: 'lux-velvet' });
  add(new THREE.BoxGeometry(2.5, 0.48, 0.95), velvet, 6.2, 0.25, 0.6);
  add(new THREE.BoxGeometry(2.5, 0.55, 0.24), velvet, 6.2, 0.68, 0.2);
  for (const sx of [-1.2, 1.2]) add(new THREE.BoxGeometry(0.2, 0.62, 0.95), velvet, 6.2 + sx, 0.33, 0.6);
  for (const [cx, cc] of [[5.4, 0xd8b46a], [6.0, 0xf0e6d0], [7.0, 0xd8b46a]] as [number, number][]) { const cu = add(new THREE.BoxGeometry(0.42, 0.42, 0.14), mat({ color: cc, rough: 0.9, key: 'lux-cush' + cc }), cx, 0.66, 0.38); cu.rotation.x = -0.25; cu.rotation.z = (cx - 6) * 0.1; }
  const glassTop = new THREE.MeshStandardMaterial({ color: 0xcfe0e8, transparent: true, opacity: 0.35, roughness: 0.02, metalness: 0.3, depthWrite: false });
  add(new THREE.BoxGeometry(1.1, 0.02, 0.65), glassTop, 6.2, 0.42, 2.2); add(new THREE.BoxGeometry(1.0, 0.36, 0.55), gold, 6.2, 0.2, 2.2).scale.set(1, 1, 1);
  (group.children[group.children.length - 1] as THREE.Mesh).material = new THREE.MeshStandardMaterial({ color: 0xc8a050, metalness: 1, roughness: 0.3, wireframe: true });
  const vase = add(new THREE.CylinderGeometry(0.05, 0.08, 0.22, 14), mat({ color: 0x1e3a6a, rough: 0.2, metal: 0.1, key: 'lux-vase' }), 6.2, 0.54, 2.2);
  for (let i = 0; i < 7; i++) { const st = add(new THREE.CylinderGeometry(0.004, 0.004, 0.3, 4), mat({ color: 0x2a5a2a, key: 'lux-stem' }), 6.2 + (rnd() - 0.5) * 0.06, 0.75, 2.2 + (rnd() - 0.5) * 0.06); st.rotation.z = (rnd() - 0.5) * 0.4; add(new THREE.SphereGeometry(0.035, 8, 6), mat({ color: [0xe8304a, 0xfff0f0, 0xff9ab0][i % 3], rough: 0.7, key: 'lux-rose' + (i % 3) }), st.position.x + Math.sin(st.rotation.z) * -0.15, 0.9, st.position.z); }
  void vase;
  // wall-mounted 65" TV with LED back-glow + sound bar over a walnut console
  const tvScreenPos = new THREE.Vector3(8.8, 1.38, 0.155);
  add(new THREE.BoxGeometry(1.72, 1.0, 0.04), black, 8.8, 1.38, 0.13);
  const glow = add(new THREE.PlaneGeometry(2.1, 1.35), new THREE.MeshBasicMaterial({ map: tex.glow(), color: 0x3a5aff, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false }), 8.8, 1.38, 0.112); void glow;
  add(new THREE.BoxGeometry(1.3, 0.07, 0.09), black, 8.8, 0.8, 0.2);
  // floor lamp, bedside lamps, kitchen pendants
  const lampShade = new THREE.MeshStandardMaterial({ color: 0xf6ead0, emissive: 0xffd8a0, emissiveIntensity: 0.6, side: THREE.DoubleSide, roughness: 0.9 });
  add(new THREE.CylinderGeometry(0.015, 0.015, 1.5, 8), gold, 4.95, 0.75, 0.45); add(new THREE.CylinderGeometry(0.18, 0.18, 0.02, 16), gold, 4.95, 0.01, 0.45);
  add(new THREE.CylinderGeometry(0.16, 0.24, 0.3, 16, 1, true), lampShade, 4.95, 1.55, 0.45);
  const lamps: THREE.PointLight[] = [];
  const lamp1 = new THREE.PointLight(0xffd8a0, 0, 4.5, 2); lamp1.position.set(4.95, 1.5, 0.5); group.add(lamp1); lamps.push(lamp1);
  for (const lz of [0.45]) { add(new THREE.SphereGeometry(0.08, 12, 8), gold, 2.6, 0.62, lz); add(new THREE.CylinderGeometry(0.1, 0.14, 0.16, 14, 1, true), lampShade, 2.6, 0.78, lz); }
  const bl = new THREE.PointLight(0xffc890, 0, 3, 2); bl.position.set(2.6, 0.85, 0.5); group.add(bl); lamps.push(bl);
  for (const px of [6.8, 7.6, 8.4]) { add(new THREE.CylinderGeometry(0.004, 0.004, 0.7, 4), black, px, 2.45, 5.3); const sh = add(new THREE.SphereGeometry(0.12, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), gold, px, 2.1, 5.3); (sh.material as THREE.Material).side = THREE.DoubleSide; add(new THREE.SphereGeometry(0.04, 8, 6), new THREE.MeshBasicMaterial({ color: 0xfff0d0 }), px, 2.08, 5.3); }
  // kitchen: marble worktop, upper cabinets, fridge
  add(new THREE.BoxGeometry(4.26, 0.05, 0.74), mat({ map: lux.marble(), color: 0x2a2a2c, rough: 0.1, key: 'lux-worktop' }), 7.5, 0.93, 5.6);
  add(new THREE.BoxGeometry(3.0, 0.7, 0.35), mat({ color: 0xf2efe8, rough: 0.35, key: 'lux-cab' }), 7.9, 2.0, 5.78);
  for (let i = 0; i < 5; i++) add(new THREE.BoxGeometry(0.02, 0.6, 0.02), gold, 6.6 + i * 0.6, 2.0, 5.6);
  add(new THREE.BoxGeometry(0.8, 2.0, 0.7), mat({ color: 0xc8ccd0, metal: 0.8, rough: 0.25, key: 'lux-fridge' }), 9.45, 1.0, 5.55); col.addCentered(9.45, 5.55, 0.8, 0.7);
  // plants
  const pot = mat({ color: 0xe8e0d0, rough: 0.6, key: 'lux-pot' }); const leaf = mat({ color: 0x2a5a2a, rough: 0.8, key: 'lux-leaf' });
  for (const [px, pz] of [[9.55, 0.45], [4.9, 5.5], [0.45, 0.45]] as [number, number][]) {
    add(new THREE.CylinderGeometry(0.2, 0.15, 0.4, 14), pot, px, 0.2, pz); col.addCentered(px, pz, 0.4, 0.4);
    for (let i = 0; i < 12; i++) { const l = add(new THREE.SphereGeometry(0.16, 8, 6), leaf, px + (rnd() - 0.5) * 0.4, 0.6 + rnd() * 0.9, pz + (rnd() - 0.5) * 0.4); l.scale.set(0.5, 1.6, 0.2); l.rotation.set(rnd(), rnd() * 6, rnd()); }
  }
  // paintings in gold frames
  const art = (i: number, x: number, y: number, z: number, ry: number, w: number) => {
    const f = new THREE.Group(); f.position.set(x, y, z); f.rotation.y = ry; group.add(f);
    add(new THREE.BoxGeometry(w + 0.08, w * 0.75 + 0.08, 0.04), gold, 0, 0, 0, f);
    add(new THREE.PlaneGeometry(w, w * 0.75), mat({ map: lux.painting(i), rough: 0.7, key: 'lux-art' + i }), 0, 0, 0.022, f);
  };
  art(0, 6.2, 1.75, 0.13, 0, 1.1); art(1, 4.62, 1.6, 2.4, Math.PI / 2, 0.8); art(2, 1.1, 1.7, 0.19, 0, 0.9);
  // tufted headboard & bedding
  add(new THREE.BoxGeometry(2.2, 1.1, 0.12), velvet, 1.1, 0.95, 0.2);
  add(new THREE.BoxGeometry(1.96, 0.05, 1.6), mat({ color: 0xf4efe6, rough: 1, key: 'lux-duvet' }), 1.1, 0.585, 1.95);
  for (const px of [0.6, 1.6]) { const pw = add(new THREE.BoxGeometry(0.6, 0.14, 0.35), mat({ color: 0xffffff, rough: 1, key: 'lux-pillow' }), px, 0.62, 0.55); pw.rotation.x = -0.2; }
  // curtains at the living window & bedroom window
  const curtain = mat({ color: 0x8a6a4a, rough: 1, key: 'lux-curtain' });
  for (const z of [3.35, 4.95]) { const cu = add(new THREE.BoxGeometry(0.06, 2.4, 0.35), curtain, 9.84, 1.3, z); cu.scale.z = 1; }
  for (const x of [1.45, 2.95]) add(new THREE.BoxGeometry(0.35, 2.3, 0.06), curtain, x, 1.3, 5.84);
  // bookshelf
  add(new THREE.BoxGeometry(0.35, 2.0, 1.0), walnut, 4.38, 1.0, 1.2); col.addCentered(4.38, 1.2, 0.35, 1.0);
  for (let s = 0; s < 4; s++) bookRow(group, 0.73, 1.68, 0.19 + s * 0.48, 4.36, -1, 'z');
  for (let s = 0; s < 0; s++) for (let b = 0; b < 9; b++) { const bk = add(new THREE.BoxGeometry(0.22, 0.26 + rnd() * 0.08, 0.06 + rnd() * 0.04), mat({ color: [0x7a1420, 0x1e3a6a, 0x2a5a3a, 0xd8b46a, 0x3a2a20][b % 5], rough: 0.8, key: 'lux-book' + (b % 5) }), 4.36, 0.32 + s * 0.48, 0.78 + b * 0.095); bk.rotation.x = (rnd() - 0.5) * 0.08; }
  void q;
  return { chandelier, lamps, tvScreenPos };
}

// ---------------- house fire ----------------
export interface HouseFire { group: THREE.Group; level: number; setLevel: (k: number) => void; update: (dt: number) => void; light: THREE.PointLight }
export function createHouseFire(parent: THREE.Object3D): HouseFire {
  const g = new THREE.Group(); parent.add(g);
  const fl = (() => { const cv = document.createElement('canvas'); cv.width = 64; cv.height = 128; const c = cv.getContext('2d')!; const gr = c.createRadialGradient(32, 96, 2, 32, 80, 60); gr.addColorStop(0, 'rgba(255,250,210,1)'); gr.addColorStop(0.3, 'rgba(255,170,50,0.95)'); gr.addColorStop(0.7, 'rgba(230,60,10,0.6)'); gr.addColorStop(1, 'rgba(120,10,0,0)'); c.fillStyle = gr; c.beginPath(); c.moveTo(32, 2); c.bezierCurveTo(62, 50, 60, 124, 32, 126); c.bezierCurveTo(4, 124, 2, 50, 32, 2); c.fill(); const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t; })();
  const fm = new THREE.SpriteMaterial({ map: fl, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
  const sm = new THREE.SpriteMaterial({ map: tex.glow(), color: 0x1a1612, transparent: true, opacity: 0.55, depthWrite: false });
  const flames: { s: THREE.Sprite; base: THREE.Vector3; t0: number; ph: number }[] = [];
  const smokes: { s: THREE.Sprite; t0: number; ph: number }[] = [];
  // fire starts at the stove and spreads through kitchen → living room → hallway
  const path = [[6.4, 5.4], [7.2, 5.4], [8.2, 5.3], [9.2, 5.0], [8.8, 4.0], [7.6, 3.4], [6.2, 0.6], [8.8, 0.5], [5.6, 2.2], [9.3, 2.0], [5.2, 4.6], [6.8, 1.8]];
  path.forEach(([x, z], i) => { for (let k = 0; k < 4; k++) { const s = new THREE.Sprite(fm); s.visible = false; g.add(s); flames.push({ s, base: new THREE.Vector3(x + (Math.random() - 0.5) * 0.6, 0.1, z + (Math.random() - 0.5) * 0.4), t0: i / path.length, ph: Math.random() * 6 }); } });
  for (let i = 0; i < 40; i++) { const s = new THREE.Sprite(sm); s.visible = false; s.position.set(4.7 + Math.random() * 5.1, 2.2 + Math.random() * 0.5, 0.3 + Math.random() * 5.4); s.scale.setScalar(1.4 + Math.random() * 1.4); g.add(s); smokes.push({ s, t0: Math.random() * 0.9, ph: Math.random() * 6 }); }
  const light = new THREE.PointLight(0xff6a20, 0, 12, 2); light.position.set(7.4, 1.4, 4.4); registerLight(light); g.add(light);
  const f: HouseFire = {
    group: g, level: 0, light,
    setLevel(k) { f.level = k; },
    update(dt) {
      const k = f.level, t = performance.now() * 0.001;
      flames.forEach((o) => {
        const on = k > o.t0; o.s.visible = on; if (!on) return;
        const grow = Math.min(1, (k - o.t0) * 4);
        const fl2 = 0.8 + Math.sin(t * (9 + o.ph) + o.ph) * 0.15 + Math.random() * 0.08;
        o.s.scale.set(0.7 * grow, 1.4 * grow * fl2, 1); o.s.position.set(o.base.x + Math.sin(t * 3 + o.ph) * 0.04, o.base.y + 0.65 * grow * fl2, o.base.z);
      });
      smokes.forEach((o) => { const on = k > o.t0 * 0.8; o.s.visible = on; if (on) { o.s.position.y = 2.1 + Math.sin(t * 0.3 + o.ph) * 0.15; o.s.material.opacity = Math.min(0.55, (k - o.t0 * 0.8) * 1.5); } });
      light.intensity = k > 0 ? (6 + k * 18) * (0.85 + Math.sin(t * 17) * 0.1 + Math.random() * 0.1) : 0;
      void dt;
    },
  };
  return f;
}
