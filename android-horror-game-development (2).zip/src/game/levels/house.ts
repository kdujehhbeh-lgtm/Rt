// Chapter 1 – the protagonist's small house at 2 AM + the street outside
import * as THREE from 'three';
import { Collision } from '../physics';
import { Builder, Door, freezeStatic } from '../world';
import { mat, tex } from '../textures';
import { type Humanoid } from '../characters';
import { buildTallMan } from '../creatures';
import { buildCar, keyModel } from '../props';
import { luxuryDecor, lux, type LuxuryHandles } from './luxury';
import { buildVilla } from './villa';
import { NavGraph } from '../physics';
import type { HideSpot } from './station';
import { art } from '../art';
import type { Quality } from '../store';

export interface HouseLevel {
  group: THREE.Group; dyn: THREE.Group; col: Collision;
  door: Door;
  a: Record<string, THREE.Vector3>;
  items: Record<string, THREE.Object3D>;
  phoneLight: THREE.PointLight;
  tall: Humanoid;
  setBlinds: (k: number) => void;
  tv: { on: boolean; set: (v: boolean) => void; update: (dt: number) => void; play: (url: string, tint?: number) => void };
  nav: NavGraph; hide: HideSpot[];
  lux: LuxuryHandles;
  heightAt: (x: number, z: number, y: number) => number;
  update: (dt: number) => void;
}

export function buildHouse(scene: THREE.Scene, q: Quality): HouseLevel {
  const group = new THREE.Group(); const dyn = new THREE.Group(); scene.add(group); scene.add(dyn);
  const col = new Collision();
  const B = new Builder(group, col, q === 'high');
  const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
  const H = 2.8;
  // luxury materials: herringbone parquet, panelled cream walls, stone facade, emerald velvet
  const mFloor = mat({ map: lux.herringbone(), rough: 0.35, key: 'hfloor-lux' });
  const mWall = mat({ map: lux.wainscot(), rough: 0.8, key: 'hwall-lux' });
  const mExt = mat({ map: lux.stone(), rough: 0.95, key: 'hext-lux' });
  const mFab = mat({ map: lux.velvet(), rough: 0.85, key: 'fabric-lux' });
  const mSheet = mat({ color: 0xb8b8c0, rough: 1, key: 'sheet' });
  const mDarkWood = mat({ map: tex.wood(), color: 0x5a4030, rough: 0.7, key: 'dwood' });
  const mDark = mat({ color: 0x18181a, rough: 0.5, key: 'hdark' });
  const mGlass = new THREE.MeshStandardMaterial({ color: 0x8090a0, transparent: true, opacity: 0.15, roughness: 0.05, metalness: 0.5, depthWrite: false });

  // floors / ceiling
  B.plane(5, 0.03, 3, 10, 6, mFloor);
  B.plane(5, H - 0.04, 3, 10, 6, mat({ color: 0x8a8a88, rough: 1, key: 'hceil' }), Math.PI / 2);
  B.box(5, H + 0.02, 3, 10.4, 0.3, 6.4, mExt);
  // walls
  B.wallX(0, 0, 10, H, mWall);
  // window wall z=6 (bedroom window at x 1.6..2.8)
  B.box(0.8, 0, 6, 1.6, H, 0.2, mWall, { collide: true });
  B.box(2.2, 0, 6, 1.2, 1.0, 0.2, mWall, { collide: true });
  B.box(2.2, 2.2, 6, 1.2, H - 2.2, 0.2, mWall);
  B.box(6.4, 0, 6, 7.2, H, 0.2, mWall, { collide: true });
  const win = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.2), mGlass); win.position.set(2.2, 1.6, 6); group.add(win);
  B.box(2.2, 1.6, 6, 0.05, 1.2, 0.22, mDark); B.box(2.2, 1.6, 6, 1.2, 0.05, 0.22, mDark);
  // blinds
  // dynamic blind (12 slats + bottom rail + cord) that can be pulled up
  const blindM = mat({ color: 0xd8d0c0, rough: 0.6, key: 'blind' });
  const blinds = new THREE.Group(); dyn.add(blinds);
  const slats: THREE.Mesh[] = [];
  const headrail = new THREE.Mesh(new THREE.BoxGeometry(1.26, 0.05, 0.07), mat({ color: 0xbab2a2, rough: 0.5, key: 'headrail' })); headrail.position.set(2.2, 2.22, 5.86); blinds.add(headrail);
  for (let i = 0; i < 12; i++) {
    const s = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.012, 0.06), blindM); s.position.set(2.2, 2.17 - i * 0.092, 5.86); s.rotation.x = 0.55; blinds.add(s); slats.push(s);
  }
  const rail = new THREE.Mesh(new THREE.BoxGeometry(1.22, 0.025, 0.07), mat({ color: 0xbab2a2, rough: 0.5, key: 'headrail' })); rail.position.set(2.2, 1.08, 5.86); blinds.add(rail);
  const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 1, 4), mat({ color: 0xeeeeee, key: 'cord' })); cord.position.set(2.75, 1.7, 5.84); blinds.add(cord);
  const setBlinds = (k: number) => { // 0 = closed, 1 = fully raised
    slats.forEach((s, i) => { const closedY = 2.17 - i * 0.092; const openY = 2.17 - i * 0.013; s.position.y = closedY + (openY - closedY) * k; s.rotation.x = 0.55 * (1 - k) + 1.4 * k; });
    rail.position.y = 1.08 + (2.0 - 1.08) * k;
    cord.scale.y = 1 + k * 0.6; cord.position.y = 1.7 - k * 0.3;
  };
  setBlinds(0);
  B.wallZ(0, 0, 6, H, mWall);
  // front wall x=10: door at z=3, window at z=5
  B.box(10, 0, 0.625 + 0.6, 0.2, H, 2.45 - 0.6 + 0.6, mWall, { collide: true });
  col.add(9.9, 10.1, 0, 2.5);
  B.box(10, 0, 4.15, 0.2, 1.0, 1.3, mWall, { collide: true });
  B.box(10, 2.2, 4.15, 0.2, H - 2.2, 1.3, mWall);
  B.box(10, 0, 5.4, 0.2, H, 1.2, mWall, { collide: true });
  B.box(10, 2.2, 3, 0.2, H - 2.2, 1.0, mWall);
  const win2 = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 1.2), mGlass); win2.rotation.y = Math.PI / 2; win2.position.set(10, 1.6, 4.15); group.add(win2);
  col.add(9.9, 10.1, 3.5, 4.8, { sight: false });
  // interior wall bedroom/living
  B.wallZ(4.5, 0, 6, H, mWall, [[4.6, 0.95]]);
  // bed
  B.box(1.1, 0, 1.5, 2.0, 0.35, 2.4, mDarkWood, { collide: true, maxY: 0.5 });
  B.box(1.1, 0.35, 1.5, 1.9, 0.18, 2.3, mSheet);
  B.box(1.1, 0.52, 0.55, 1.2, 0.12, 0.4, mat({ color: 0xd8d8d8, rough: 1, key: 'pillow' }));
  const blanket = B.box(1.1, 0.53, 2.0, 1.95, 0.06, 1.5, mat({ color: 0x2d3a52, rough: 1, key: 'blanket' })); blanket.rotation.z = 0.02;
  B.box(1.1, 0, 0.12, 2.0, 1.0, 0.1, mDarkWood);
  // nightstand + phone
  B.box(2.6, 0, 0.45, 0.5, 0.55, 0.45, mDarkWood, { collide: true });
  const phone = B.box(2.6, 0.55, 0.45, 0.08, 0.012, 0.16, mat({ color: 0x050505, rough: 0.2, key: 'cphone' }), { parent: dyn });
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.07, 0.14), new THREE.MeshBasicMaterial({ color: 0x9fd0ff }));
  screen.rotation.x = -Math.PI / 2; screen.position.set(0, 0.008, 0); phone.add(screen);
  const phoneLight = new THREE.PointLight(0x8ab8ff, 1.6, 3.5, 2); phoneLight.position.set(2.6, 0.75, 0.45); dyn.add(phoneLight);
  // wardrobe, desk
  B.box(3.9, 0, 3.2, 0.6, 2.1, 1.4, mDarkWood, { collide: true });
  B.box(1.0, 0, 5.4, 1.4, 0.75, 0.6, mDarkWood, { collide: true, sight: false });
  B.box(1.0, 0.75, 5.5, 0.6, 0.4, 0.05, mDark);
  // living room
  B.box(6.2, 0, 0.6, 2.4, 0.45, 0.9, mFab, { collide: true, maxY: 0.8 });
  B.box(6.2, 0.45, 0.2, 2.4, 0.5, 0.2, mFab);
  B.box(6.2, 0, 2.2, 1.0, 0.4, 0.6, mDarkWood, { collide: true, maxY: 0.4 });
  B.box(8.8, 0, 0.35, 1.6, 0.5, 0.45, mDarkWood, { collide: true });
  const luxH = luxuryDecor(group, col, q);
  // wall-mounted 65" TV (static when switched on by "something", real footage otherwise)
  const tvCv = document.createElement('canvas'); tvCv.width = 320; tvCv.height = 180;
  const tvCtx = tvCv.getContext('2d')!;
  const tvTex = new THREE.CanvasTexture(tvCv); tvTex.colorSpace = THREE.SRGBColorSpace;
  const tvScreen = new THREE.Mesh(new THREE.PlaneGeometry(1.64, 0.92), new THREE.MeshBasicMaterial({ map: tvTex, color: 0x050505, toneMapped: false }));
  tvScreen.position.copy(luxH.tvScreenPos); dyn.add(tvScreen);
  // subtle glass glare on the panel
  const glare = new THREE.Mesh(new THREE.PlaneGeometry(1.64, 0.92), new THREE.MeshBasicMaterial({ map: tex.glow(), color: 0x222833, transparent: true, opacity: 0.25, blending: THREE.AdditiveBlending, depthWrite: false }));
  glare.position.copy(luxH.tvScreenPos).add(new THREE.Vector3(0.3, 0.15, 0.003)); glare.scale.set(0.6, 0.5, 1); dyn.add(glare);
  const tvLight = new THREE.PointLight(0xaabbdd, 0, 6, 2); tvLight.position.set(8.8, 1.3, 0.9); dyn.add(tvLight);
  const tvMat = tvScreen.material as THREE.MeshBasicMaterial;
  const tv = {
    on: false, t: 0, face: 0, video: null as HTMLVideoElement | null, tint: 0xffffff,
    set(v: boolean) {
      tv.on = v; tvMat.color.set(v ? tv.tint : 0x050505); tvLight.intensity = v ? 2.2 : 0;
      if (tv.video) { if (v) tv.video.play().catch(() => {}); else tv.video.pause(); }
    },
    /** real footage on the TV (falls back to static if the clip can't load / CORS blocked) */
    play(url: string, tint = 0xffffff) {
      tv.tint = tint;
      const v = document.createElement('video');
      v.crossOrigin = 'anonymous'; v.src = url; v.loop = true; v.muted = true; v.playsInline = true; v.setAttribute('playsinline', ''); v.preload = 'auto';
      v.addEventListener('playing', () => {
        if (tv.video === v) return;
        const vt = new THREE.VideoTexture(v); vt.colorSpace = THREE.SRGBColorSpace; vt.minFilter = THREE.LinearFilter; vt.magFilter = THREE.LinearFilter; vt.anisotropy = 4;
        if (tv.video) { tv.video.pause(); tv.video.removeAttribute('src'); tv.video.load(); }
        tvMat.map = vt; tvMat.needsUpdate = true; tv.video = v; if (tv.on) tvMat.color.set(tint);
      });
      v.play().catch(() => {});
    },
    update(dt: number) {
      if (!tv.on) return;
      if (tv.video) { tvLight.intensity = 1.8 + Math.random() * 0.6; return; }
      tv.t += dt; if (tv.t < 0.06) return; tv.t = 0;
      const d = tvCtx.createImageData(320, 180);
      for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; }
      tvCtx.putImageData(d, 0, 0);
      tvCtx.setTransform(2, 0, 0, 2, 0, 0);
      tv.face -= 1;
      if (tv.face <= 0 && Math.random() < 0.04) tv.face = 6;
      if (tv.face > 0) { // a tall silhouette flickers in the static
        tvCtx.fillStyle = 'rgba(0,0,0,0.85)'; tvCtx.fillRect(74, 8, 12, 80); tvCtx.beginPath(); tvCtx.ellipse(80, 10, 7, 9, 0, 0, Math.PI * 2); tvCtx.fill();
        tvCtx.fillRect(66, 22, 4, 50); tvCtx.fillRect(90, 22, 4, 50);
      }
      tvCtx.fillStyle = 'rgba(255,255,255,0.9)'; tvCtx.font = 'bold 10px monospace'; tvCtx.fillText('CH 24', 120, 14);
      tvCtx.setTransform(1, 0, 0, 1, 0, 0);
      tvTex.needsUpdate = true;
      tvLight.intensity = 1.6 + Math.random() * 1.2;
    },
  };
  // envelope pushed under the front door + work uniform in the wardrobe
  const envCv = document.createElement('canvas'); envCv.width = 256; envCv.height = 160; const ec = envCv.getContext('2d')!;
  ec.fillStyle = '#f2ead8'; ec.fillRect(0, 0, 256, 160); ec.fillStyle = '#0d3a6a'; ec.fillRect(12, 12, 70, 22); ec.fillStyle = '#fff'; ec.font = '900 13px Arial'; ec.fillText('PETRO 24', 18, 28);
  ec.fillStyle = '#8a1a1a'; ec.beginPath(); ec.arc(128, 88, 14, 0, Math.PI * 2); ec.fill();
  ec.strokeStyle = 'rgba(0,0,0,0.15)'; ec.beginPath(); ec.moveTo(0, 0); ec.lineTo(128, 88); ec.lineTo(256, 0); ec.stroke();
  const envTex = new THREE.CanvasTexture(envCv); envTex.colorSpace = THREE.SRGBColorSpace;
  const envelope = new THREE.Mesh(new THREE.PlaneGeometry(0.24, 0.15), new THREE.MeshStandardMaterial({ map: envTex, roughness: 0.9 }));
  envelope.rotation.set(-Math.PI / 2, 0, 0.5); envelope.position.set(9.45, 0.015, 3.1); dyn.add(envelope);
  const uniform = new THREE.Group(); uniform.position.set(3.58, 1.25, 3.2); dyn.add(uniform);
  const shirt = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.6, 0.45), mat({ color: 0x1d3a6a, rough: 0.9, key: 'uniform' })); uniform.add(shirt);
  const badge = new THREE.Mesh(new THREE.PlaneGeometry(0.08, 0.04), mat({ color: 0xf2f2ee, key: 'badge' })); badge.position.set(-0.027, 0.12, -0.1); badge.rotation.y = -Math.PI / 2; uniform.add(badge);
  const hanger = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.006, 4, 16, Math.PI), mat({ color: 0x8a6a40, key: 'hanger' })); hanger.position.y = 0.3; hanger.rotation.y = Math.PI / 2; uniform.add(hanger);
  B.box(7.5, 0, 5.6, 4.2, 0.9, 0.7, mat({ color: 0xc8c0b0, rough: 0.5, key: 'kcounter' }), { collide: true, sight: false });
  B.box(6.4, 0.9, 5.65, 0.6, 0.35, 0.4, mDark);
  const clock = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 0.07), new THREE.MeshBasicMaterial({ map: tex.sign('02:00', '#000', '#33ff66', 128, 48, 'bold 36px monospace') }));
  clock.rotation.y = Math.PI; clock.position.set(6.4, 1.08, 5.44); group.add(clock);
  B.box(7.6, 0, 3.4, 1.4, 0.75, 0.9, mDarkWood, { collide: true, sight: false, maxY: 0.8 });
  const keys = keyModel('car'); keys.position.set(7.8, 0.765, 3.3); keys.rotation.y = 0.7; keys.scale.setScalar(1.3); dyn.add(keys);
  const front = new Door(dyn, col, { x: 10, z: 3, width: 1.0, axis: 'z', material: mDarkWood, name: 'hfront', dir: 1 });
  // exterior
  B.plane(25, 0.0, 3, 40, 50, mat({ map: tex.grass(), rough: 1, key: 'hgrass' }));
  B.plane(14, 0.03, 1.5, 6, 3.5, mat({ map: tex.concrete(), rough: 0.8, key: 'hdrive' }));
  B.plane(23.5, 0.035, 3, 7, 60, mat({ map: tex.asphalt(), rough: 0.4, color: 0x777777, key: 'hroad' }));
  for (let z = -25; z < 30; z += 6) B.box(23.5, 0.05, z, 0.15, 0.008, 2.5, mat({ color: 0xcfc9a0, key: 'hlane' }));
  // car
  const car = buildCar(0x4a5a6a, q === 'high', { dirt: true });
  car.group.position.set(14.2, 0, 1.2); group.add(car.group);
  // posters: job ad on the fridge, missing-person flyers on the street pole and house front
  const pm = (k: Parameters<typeof art.poster>[0], v: number, x: number, y: number, z: number, ry: number, w = 0.4) => {
    const p = new THREE.Mesh(new THREE.PlaneGeometry(w, w * 1.406), new THREE.MeshStandardMaterial({ map: art.poster(k, v), roughness: 0.9 }));
    p.position.set(x, y, z); p.rotation.y = ry; group.add(p);
  };
  pm('hiring', 0, 8.6, 1.75, 5.885, Math.PI, 0.34);
  pm('missing', 0, 19.39, 1.6, 6, -Math.PI / 2, 0.36);
  pm('missing', 1, 19.5, 1.65, 5.89, Math.PI, 0.36);
  pm('missing', 2, 10.11, 1.5, 0.8, Math.PI / 2, 0.42);
  pm('dog', 0, 10.11, 1.5, 5.7, Math.PI / 2, 0.38);
  col.add(13.2, 15.2, -1, 3.4, { sight: false, maxY: 1.5 });
  // houses across street
  for (let i = 0; i < 4; i++) {
    const z = -18 + i * 12;
    B.box(33, 0, z, 8, 3.5, 8, mExt);
    const roof = new THREE.Mesh(new THREE.ConeGeometry(6.2, 2.5, 4), mat({ color: 0x2a1c18, rough: 1, key: 'roof' }));
    roof.position.set(33, 4.7, z); roof.rotation.y = Math.PI / 4; group.add(roof);
    if (i === 2) { const w = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 1), new THREE.MeshBasicMaterial({ color: 0xffb860 })); w.position.set(28.95, 1.7, z + 2); w.rotation.y = -Math.PI / 2; group.add(w); }
  }
  // street light
  B.cyl(19.5, 0, 6, 0.1, 6, mat({ color: 0x555555, metal: 0.7, key: 'pole' }), 8, true);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffc890 })); bulb.position.set(20.2, 5.9, 6); group.add(bulb);
  const sl = new THREE.PointLight(0xffb070, 30, 26, 2); sl.position.set(20.2, 5.7, 6); group.add(sl);
  const cone = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 3.2, 5.9, 16, 1, true), new THREE.MeshBasicMaterial({ map: tex.cone(), color: 0xffc890, transparent: true, opacity: 0.08, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
  cone.position.set(20.2, 2.95, 6); group.add(cone);
  // window light shaft into bedroom (street light coming through blinds)
  const ws = new THREE.SpotLight(0x9fb4d8, 22, 14, 0.42, 0.6, 1.4); ws.position.set(2.2, 3.4, 9); ws.target.position.set(1.4, 0, 2.2); group.add(ws); group.add(ws.target);
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 1.2, 4.4, 10, 1, true), new THREE.MeshBasicMaterial({ map: tex.cone(), color: 0x9fb4d8, transparent: true, opacity: 0.05, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
  shaft.position.set(1.9, 1.3, 4.3); shaft.rotation.x = -0.75; group.add(shaft);
  // boundaries
  col.add(10, 30, -12, -11.8); col.add(10, 30, 17.8, 18); col.add(29.8, 30, -12, 18);
  // the tall figure across the street (foreshadowing)
  const tall = buildTallMan(false); tall.root.position.set(29, 0, 9); tall.root.rotation.y = -Math.PI / 2; dyn.add(tall.root);

  const villa = buildVilla(group, col, q);
  freezeStatic(group);
  // navigation graph (used by creatures in the nightmare chapters)
  const nav = new NavGraph();
  ([[1.6, 3.6], [3.0, 2.0], [3.6, 4.7], [2.2, 5.0], [5.4, 4.7], [6.3, 3.2], [5.6, 1.6], [8.2, 1.6], [9.2, 3.0], [8.7, 4.6], [6.0, 4.8], [11, 3], [12.5, 4.8], [16.5, 3], [17.5, 8], [16, -3], [20, 0], [12.2, -0.6]] as [number, number][]).forEach(([x, z]) => nav.add(x, z));
  nav.build(col);
  const hide: HideSpot[] = [
    { id: 'wardrobe', name: 'کمد لباس', pos: V(3.9, 1.5, 3.2), yaw: -Math.PI / 2, exit: V(3.2, 0, 3.2), open: false },
    { id: 'underbed', name: 'زیر تخت', pos: V(1.1, 0.22, 1.6), yaw: Math.PI / 2, exit: V(2.4, 0, 1.6), open: true },
  ];
  const a = { bed: V(1.1, 0.75, 1.6), stand: V(2.1, 0, 1.4), phone: phone.position.clone(), keys: keys.position.clone(), car: V(13.1, 1, 1.5), door: V(10, 1.2, 3) };
  return {
    group, dyn, col, door: front, a, items: { phone, keys, envelope, uniform }, phoneLight, tall, setBlinds, tv, nav, hide, lux: luxH,
    heightAt: villa.heightAt,
    update: (dt) => { front.update(dt); tv.update(dt); villa.update(dt); phoneLight.intensity = phone.visible ? 1.2 + Math.sin(performance.now() * 0.01) * 0.4 : 0; },
  };
}
