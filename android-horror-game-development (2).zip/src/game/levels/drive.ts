// Driving level: player-controlled car through a foggy city road (arrival) or away from the station (endings)
import * as THREE from 'three';
import { mat, tex } from '../textures';
import { art, type PosterKind } from '../art';
import { buildTallMan, buildDog, buildFaceless } from '../creatures';
import { input } from '../input';
import { audio, type LoopHandle } from '../audio';
import type { Quality } from '../store';
import type { Humanoid } from '../characters';

export type DriveMode = 'arrive' | 'fire' | 'dawn' | 'passenger';

export interface DriveLevel {
  group: THREE.Group; car: THREE.Group; seat: THREE.Object3D; mode: DriveMode;
  state: { x: number; z: number; speed: number; steer: number; t: number; stall: number };
  finished: boolean;
  update: (dt: number) => void;
  preRender: (r: THREE.WebGLRenderer, scene: THREE.Scene) => void;
  onEvent: (id: string) => void;
  passenger: Humanoid;
  setDawn: (k: number) => void;
}

export function buildDrive(scene: THREE.Scene, q: Quality, mode: DriveMode): DriveLevel {
  const group = new THREE.Group(); scene.add(group);
  const LEN = 760;
  const roadTex = tex.asphalt().clone(); roadTex.repeat.set(3, 200); roadTex.needsUpdate = true;
  const road = new THREE.Mesh(new THREE.PlaneGeometry(10, LEN), new THREE.MeshStandardMaterial({ map: roadTex, color: 0x6a6a6a, roughness: 0.32, metalness: 0.1 }));
  road.rotation.x = -Math.PI / 2; road.position.set(0, 0, -LEN / 2 + 60); group.add(road);
  const side = new THREE.Mesh(new THREE.PlaneGeometry(80, LEN), mat({ color: 0x141518, rough: 1, key: 'dside' }));
  side.rotation.x = -Math.PI / 2; side.position.set(0, -0.02, -LEN / 2 + 60); group.add(side);
  for (const sx of [-5.6, 5.6]) { const curb = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.15, LEN), mat({ map: tex.concrete(), color: 0x777777, rough: 0.9, key: 'dcurb' })); curb.position.set(sx, 0.07, -LEN / 2 + 60); group.add(curb); }
  const m4 = new THREE.Matrix4();
  const laneM = new THREE.InstancedMesh(new THREE.BoxGeometry(0.15, 0.01, 3), mat({ color: 0xd8d0a0, key: 'dlane' }), 115);
  for (let i = 0; i < 115; i++) { m4.makeTranslation(0, 0.01, 50 - i * 7); laneM.setMatrixAt(i, m4); }
  group.add(laneM);

  // street lamps (instanced) + missing posters on every pole
  const N = 24; const lampZ: number[] = []; const lampX: number[] = [];
  const poles = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.1, 0.12, 7, 6), mat({ color: 0x444444, metal: 0.6, key: 'dpole' }), N);
  const bulbs = new THREE.InstancedMesh(new THREE.SphereGeometry(0.2, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffc080 }), N);
  const cones = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.2, 3.2, 6.8, 14, 1, true), new THREE.MeshBasicMaterial({ map: tex.glow(), color: 0xffc080, transparent: true, opacity: 0.07, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }), N);
  const zero = new THREE.Matrix4().makeScale(0, 0, 0);
  const posterKinds: PosterKind[] = ['missing', 'missing', 'dog', 'missing', 'tall', 'dontlook', 'missing', 'smile'];
  const posterMats = posterKinds.map((k, i) => new THREE.MeshStandardMaterial({ map: art.poster(k, i, i > 4), roughness: 0.9 }));
  const pGeo = new THREE.PlaneGeometry(0.42, 0.59);
  for (let i = 0; i < N; i++) {
    const z = 30 - i * 32; const x = i % 2 ? 6.4 : -6.4;
    const dead = i % 5 === 3 || (i > 7 && i < 11);
    lampZ.push(dead ? 9999 : z); lampX.push(x);
    m4.makeTranslation(x, 3.5, z); poles.setMatrixAt(i, m4);
    m4.makeTranslation(x * 0.82, 6.9, z); bulbs.setMatrixAt(i, dead ? zero : m4);
    m4.makeTranslation(x * 0.82, 3.45, z); cones.setMatrixAt(i, dead ? zero : m4);
    const p = new THREE.Mesh(pGeo, posterMats[i % posterMats.length]); p.position.set(x - Math.sign(x) * 0.12, 1.7, z); p.rotation.y = -Math.sign(x) * Math.PI / 2; p.rotation.z = (Math.random() - 0.5) * 0.1; group.add(p);
    if (i % 3 === 0) { const p2 = new THREE.Mesh(pGeo, posterMats[(i + 3) % posterMats.length]); p2.position.set(x, 2.35, z + 0.12); p2.rotation.z = (Math.random() - 0.5) * 0.15; group.add(p2); }
  }
  group.add(poles, bulbs, cones);
  const lampLights = [0, 1].map(() => { const l = new THREE.PointLight(0xffb070, 26, 24, 2); group.add(l); return l; });

  // buildings with lit windows + a few posters on walls
  const bN = 76;
  const bld = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), mat({ map: tex.plaster('#3a3a40', 'db'), color: 0x55555a, rough: 1, key: 'dbld' }), bN);
  const winM = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1.2), new THREE.MeshBasicMaterial({ color: 0xffb860 }), bN);
  for (let i = 0; i < bN; i++) {
    const sd = i % 2 ? 1 : -1; const z = 40 - i * 10 - Math.random() * 5; const w = 6 + Math.random() * 8; const h = 4 + Math.random() * 14; const d = 6 + Math.random() * 6;
    const x = sd * (14 + Math.random() * 6 + w / 2);
    bld.setMatrixAt(i, new THREE.Matrix4().compose(new THREE.Vector3(x, h / 2, z), new THREE.Quaternion(), new THREE.Vector3(w, h, d)));
    const lit = Math.random() < 0.16;
    winM.setMatrixAt(i, new THREE.Matrix4().compose(new THREE.Vector3(x - sd * (w / 2 + 0.02), 2 + Math.random() * (h - 3), z), new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), -sd * Math.PI / 2), lit ? new THREE.Vector3(1, 1, 1) : new THREE.Vector3(0, 0, 0)));
  }
  group.add(bld, winM);
  // creepy billboard
  const bb = new THREE.Group(); bb.position.set(-11, 0, mode === 'arrive' ? -250 : -150); bb.rotation.y = Math.PI / 2 - 0.35; group.add(bb);
  for (const sx of [-2, 2]) { const leg = new THREE.Mesh(new THREE.BoxGeometry(0.2, 6, 0.2), mat({ color: 0x333333, metal: 0.6, key: 'bbleg' })); leg.position.set(sx, 3, 0); bb.add(leg); }
  const bbm = new THREE.MeshStandardMaterial({ map: art.poster('smile', 0, true), emissive: 0xffffff, emissiveMap: art.poster('smile', 0, true), emissiveIntensity: 0.25 });
  const bbp = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 5.9), bbm); bbp.position.y = 7.5; bb.add(bbp);
  const bbl = new THREE.SpotLight(0xffe0b0, 25, 12, 0.6, 0.6); bbl.position.set(0, 3.8, 2.5); bbl.target = bbp; bb.add(bbl);

  // station
  const stationZ = mode === 'arrive' ? -600 : 34;
  const st = new THREE.Group(); st.position.set(18, 0, stationZ); group.add(st);
  const canopy = new THREE.Mesh(new THREE.BoxGeometry(14, 0.6, 9), mat({ color: 0xdddddd, key: 'dcan' })); canopy.position.y = 5; st.add(canopy);
  const can2 = new THREE.Mesh(new THREE.PlaneGeometry(13, 8), new THREE.MeshBasicMaterial({ color: mode === 'fire' ? 0x553020 : 0xfff0d0 })); can2.rotation.x = Math.PI / 2; can2.position.y = 4.69; st.add(can2);
  const signT = tex.sign('PETRO 24', '#0d3a6a', '#fff', 512, 256, 'bold 100px Arial');
  const sign = new THREE.Mesh(new THREE.BoxGeometry(4, 2, 0.4), new THREE.MeshBasicMaterial({ map: signT })); sign.position.set(-6, 8.5, 6); st.add(sign);
  const stl = new THREE.PointLight(mode === 'fire' ? 0xff6a20 : 0xfff0d8, mode === 'fire' ? 140 : 60, 45, 2); stl.position.set(0, 4, 0); st.add(stl);
  const storeB = new THREE.Mesh(new THREE.BoxGeometry(16, 3.4, 10), mat({ color: 0x6a6660, key: 'dstore' })); storeB.position.set(4, 1.7, -14); st.add(storeB);
  for (const pz of [-1.5, 1.5]) { const pump = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.8, 0.9), mat({ color: 0xb8bcc0, key: 'dpump' })); pump.position.set(0, 0.9, pz); st.add(pump); }
  const flames: THREE.Sprite[] = [];
  if (mode === 'fire') {
    const fm = new THREE.SpriteMaterial({ map: tex.glow(), color: 0xff7a20, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true });
    const sm = new THREE.SpriteMaterial({ map: tex.glow(), color: 0x222222, transparent: true, opacity: 0.5, depthWrite: false });
    for (let i = 0; i < 40; i++) { const s = new THREE.Sprite(i < 28 ? fm : sm); s.position.set((Math.random() - 0.5) * 18, Math.random() * 7, -14 + (Math.random() - 0.5) * 16); s.scale.setScalar(i < 28 ? 2 + Math.random() * 3 : 6 + Math.random() * 6); st.add(s); flames.push(s); }
    audio.fire(new THREE.Vector3(18, 2, stationZ), 0.9);
  }
  // roadside figures
  const tall = buildTallMan(false); tall.root.position.set(7.4, 0, mode === 'arrive' ? -300 : -120); tall.root.rotation.y = -Math.PI / 2; group.add(tall.root);
  const dog = buildDog(false); dog.root.visible = false; group.add(dog.root);
  const roadGhost = buildFaceless(false); roadGhost.root.visible = false; group.add(roadGhost.root);

  // ---------------- car interior ----------------
  const car = new THREE.Group(); group.add(car);
  const dashM = mat({ color: 0x141414, rough: 0.75, key: 'dash' });
  const trimM = mat({ color: 0x2a2622, rough: 0.85, key: 'trim' });
  const paint = new THREE.MeshStandardMaterial({ color: 0x3e4d5c, metalness: 0.75, roughness: 0.3 });
  const add = (g: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0) => { const o = new THREE.Mesh(g, m); o.position.set(x, y, z); o.rotation.set(rx, ry, rz); car.add(o); return o; };
  add(new THREE.BoxGeometry(1.75, 0.32, 0.7), dashM, 0, 0.92, -0.8);
  add(new THREE.BoxGeometry(1.7, 0.08, 0.35), dashM, 0, 1.1, -1.0, -0.25);
  const hood = add(new THREE.BoxGeometry(1.8, 0.12, 2.0), paint, 0, 0.86, -2.15, 0.06); void hood;
  add(new THREE.BoxGeometry(1.84, 0.2, 0.15), paint, 0, 0.9, -3.15);
  for (const x of [-0.86, 0.86]) { add(new THREE.BoxGeometry(0.07, 0.85, 0.09), dashM, x, 1.42, -0.62, -0.5); add(new THREE.BoxGeometry(0.08, 0.5, 1.6), trimM, x * 1.02, 0.78, 0.15); add(new THREE.BoxGeometry(0.05, 0.4, 0.06), dashM, x, 1.58, 0.5, 0.2); }
  add(new THREE.BoxGeometry(1.75, 0.05, 1.7), trimM, 0, 1.82, 0.15);
  add(new THREE.BoxGeometry(0.4, 0.02, 0.22), trimM, -0.4, 1.76, -0.45, 0.25); // sun visor
  // side glass
  const sg = new THREE.MeshStandardMaterial({ color: 0x0a0f14, transparent: true, opacity: 0.25, roughness: 0.05, metalness: 0.6, side: THREE.DoubleSide, depthWrite: false });
  for (const x of [-0.87, 0.87]) add(new THREE.PlaneGeometry(1.2, 0.5), sg, x, 1.3, 0.05, 0, Math.PI / 2);
  // instrument cluster + needles
  const cluster = add(new THREE.PlaneGeometry(0.42, 0.21), new THREE.MeshBasicMaterial({ map: art.gauge() }), -0.38, 1.1, -0.53, -0.35);
  const needleM = new THREE.MeshBasicMaterial({ color: 0xff3a2a });
  const mkNeedle = (x: number) => { const piv = new THREE.Group(); piv.position.set(x, 0.0, 0.002); cluster.add(piv); const n = new THREE.Mesh(new THREE.PlaneGeometry(0.004, 0.07), needleM); n.position.y = 0.032; piv.add(n); return piv; };
  const speedN = mkNeedle(-0.105), rpmN = mkNeedle(0.105);
  speedN.position.y = -0.01; rpmN.position.y = -0.01;
  // steering wheel
  const wheel = new THREE.Group(); wheel.position.set(-0.38, 1.05, -0.4); wheel.rotation.x = -0.5; car.add(wheel);
  wheel.add(new THREE.Mesh(new THREE.TorusGeometry(0.19, 0.022, 8, 28), dashM));
  for (let k = 0; k < 3; k++) { const sp = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.03, 0.02), dashM); sp.rotation.z = Math.PI / 2 + (k / 3) * Math.PI * 2; sp.position.set(Math.cos(Math.PI / 2 + (k / 3) * Math.PI * 2) * 0.09, Math.sin(Math.PI / 2 + (k / 3) * Math.PI * 2) * 0.09, 0); wheel.add(sp); }
  wheel.add(new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.05, 12).rotateX(Math.PI / 2), mat({ color: 0x222222, rough: 0.4, key: 'hub' })));
  // radio, console, gear stick
  add(new THREE.PlaneGeometry(0.2, 0.06), new THREE.MeshBasicMaterial({ map: art.sign('FM 88.2', '#000', '#5fff8a', 128, 40, 26) }), 0.05, 1.03, -0.47, -0.45);
  add(new THREE.BoxGeometry(0.25, 0.3, 0.8), dashM, 0, 0.6, -0.15);
  add(new THREE.CylinderGeometry(0.012, 0.012, 0.2, 6), mat({ color: 0x777777, metal: 0.9, key: 'gear' }), 0, 0.83, -0.05, 0.3);
  add(new THREE.SphereGeometry(0.03, 8, 6), dashM, 0, 0.93, -0.08);
  // seats
  const seatM = mat({ color: 0x2a2420, rough: 0.95, key: 'seat' });
  add(new THREE.BoxGeometry(0.5, 0.12, 0.5), seatM, 0.4, 0.62, 0.15); add(new THREE.BoxGeometry(0.5, 0.65, 0.12), seatM, 0.4, 0.98, 0.45, -0.15);
  add(new THREE.BoxGeometry(0.28, 0.18, 0.1), seatM, 0.4, 1.4, 0.5);
  add(new THREE.BoxGeometry(1.5, 0.15, 0.55), seatM, 0, 0.62, 1.2); add(new THREE.BoxGeometry(1.5, 0.65, 0.12), seatM, 0, 0.98, 1.5, -0.12);
  // rear-view mirror
  const mirrorFrame = add(new THREE.BoxGeometry(0.26, 0.085, 0.03), dashM, 0, 1.68, -0.6, 0.1);
  let rt: THREE.WebGLRenderTarget | null = null; let mirrorCam: THREE.PerspectiveCamera | null = null;
  if (q !== 'low') {
    rt = new THREE.WebGLRenderTarget(256, 90);
    rt.texture.colorSpace = THREE.SRGBColorSpace;
    const mt = rt.texture; mt.wrapS = THREE.RepeatWrapping; mt.repeat.x = -1; mt.offset.x = 1;
    mirrorCam = new THREE.PerspectiveCamera(42, 256 / 90, 0.1, 140);
    mirrorCam.position.set(0, 1.6, -0.5); mirrorCam.rotation.set(-0.02, Math.PI, 0); car.add(mirrorCam);
  }
  const mirror = new THREE.Mesh(new THREE.PlaneGeometry(0.24, 0.07), rt ? new THREE.MeshBasicMaterial({ map: rt.texture }) : new THREE.MeshStandardMaterial({ color: 0x223040, metalness: 1, roughness: 0.1 }));
  mirror.position.set(0, 0, 0.016); mirrorFrame.add(mirror);
  // air freshener
  const fresh = new THREE.Group(); fresh.position.set(0, 1.63, -0.6); car.add(fresh);
  const str = new THREE.Mesh(new THREE.CylinderGeometry(0.002, 0.002, 0.1, 3), dashM); str.position.y = -0.05; fresh.add(str);
  const tree = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.08, 3), mat({ color: 0x1a8a3a, rough: 0.8, key: 'fresh' })); tree.position.y = -0.13; fresh.add(tree);
  // windshield handprints (scare)
  const hands = add(new THREE.PlaneGeometry(1.1, 0.6), new THREE.MeshBasicMaterial({ map: art.handprints(), transparent: true, depthWrite: false }), 0.1, 1.42, -0.98, -0.95);
  hands.visible = false;
  // windshield & rear window glass (subtle tint + reflections, a few smudges)
  const wsCv = document.createElement('canvas'); wsCv.width = 256; wsCv.height = 128; const wc = wsCv.getContext('2d')!;
  const wg = wc.createLinearGradient(0, 0, 0, 128); wg.addColorStop(0, 'rgba(40,60,80,0.55)'); wg.addColorStop(0.25, 'rgba(40,60,80,0.12)'); wg.addColorStop(1, 'rgba(40,60,80,0.05)');
  wc.fillStyle = wg; wc.fillRect(0, 0, 256, 128);
  for (let i = 0; i < 14; i++) { wc.strokeStyle = `rgba(200,210,220,${0.04 + Math.random() * 0.05})`; wc.lineWidth = 1 + Math.random() * 2; wc.beginPath(); wc.arc(128, 160, 60 + i * 6, Math.PI * 1.15, Math.PI * 1.85); wc.stroke(); } // wiper arcs
  const wsTex = new THREE.CanvasTexture(wsCv); wsTex.colorSpace = THREE.SRGBColorSpace;
  const wsMat = new THREE.MeshStandardMaterial({ map: wsTex, transparent: true, roughness: 0.03, metalness: 0.6, depthWrite: false, side: THREE.DoubleSide, envMapIntensity: 0.8 });
  const windshield = add(new THREE.PlaneGeometry(1.74, 0.9), wsMat, 0, 1.43, -0.96, -0.95); windshield.renderOrder = 3;
  const rearGlass = add(new THREE.PlaneGeometry(1.5, 0.5), wsMat, 0, 1.45, 1.75, 0.9); rearGlass.renderOrder = 3;
  // headlights
  const head = new THREE.SpotLight(0xfff4e0, 75, 70, 0.45, 0.5, 1.3); head.position.set(0, 0.8, -3.1); head.target.position.set(0, 0, -28); car.add(head); car.add(head.target);
  const headGlow = new THREE.Mesh(new THREE.PlaneGeometry(9, 22), new THREE.MeshBasicMaterial({ map: tex.glow(), color: 0x5a5040, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
  headGlow.rotation.x = -Math.PI / 2; headGlow.position.set(0, 0.03, -13); car.add(headGlow);
  const seat = new THREE.Object3D(); seat.position.set(-0.38, 1.33, 0.12); car.add(seat);
  // back-seat passenger (passenger ending / mirror scares)
  const passenger = buildFaceless(false); passenger.root.position.set(0.35, 0.05, 1.2); passenger.root.rotation.y = Math.PI; passenger.root.scale.setScalar(0.92);
  passenger.lLeg.rotation.x = -1.4; passenger.rLeg.rotation.x = -1.4; passenger.root.position.y = -0.14; passenger.root.visible = false; car.add(passenger.root);

  const state = { x: 1.8, z: mode === 'arrive' ? 0 : 20, speed: 6, steer: 0, t: 0, stall: 0 };
  const engine: LoopHandle | null = audio.engine(0.13);
  const fired = new Set<string>();
  const once = (id: string) => { if (fired.has(id)) return false; fired.add(id); lvl.onEvent(id); return true; };
  let dogX = 0; let dogActive = false; let flick = 0; let mirrorTick = 0;
  const baseFog = (scene.fog as THREE.FogExp2 | null)?.color.clone() ?? new THREE.Color(0x06080c);

  const lvl: DriveLevel = {
    group, car, seat, mode, state, finished: false, passenger, onEvent: () => {},
    setDawn(k: number) {
      const dawn = new THREE.Color(0x8a6a7a).lerp(new THREE.Color(0xd8a080), k);
      const c = baseFog.clone().lerp(dawn, k);
      if (scene.fog) (scene.fog as THREE.FogExp2).color.copy(c);
      scene.background = c;
    },
    preRender(r, sc) {
      if (!rt || !mirrorCam) return;
      mirrorTick++; if (mirrorTick % (q === 'high' ? 2 : 5) !== 0) return; // the mirror is tiny – refresh it rarely
      r.setRenderTarget(rt); r.render(sc, mirrorCam); r.setRenderTarget(null);
    },
    update(dt) {
      state.t += dt;
      const thr = input.move.y, steerIn = input.move.x;
      const cruise = 9;
      let target = thr > 0.15 ? cruise + thr * 15 : thr < -0.15 ? 0 : cruise;
      if (state.stall > 0) { state.stall -= dt; target = 1.5; }
      const k = thr < -0.15 ? 2.2 : target < state.speed ? 0.9 : 0.6;
      state.speed += (target - state.speed) * Math.min(1, dt * k);
      state.steer += (steerIn - state.steer) * Math.min(1, dt * 5);
      state.x += state.steer * dt * (1.5 + state.speed * 0.2);
      let shake = 0;
      if (Math.abs(state.x) > 4.2) { state.speed *= 1 - dt * 0.8; shake = 0.02; if (Math.random() < dt * 8) audio.footstep('concrete', 0.15); }
      state.x = Math.max(-5.6, Math.min(5.6, state.x));
      state.z -= state.speed * dt;
      car.position.set(state.x + (Math.random() - 0.5) * shake, Math.sin(state.t * 11) * 0.005 * (state.speed / 10) + (Math.random() - 0.5) * shake, state.z);
      car.rotation.y = -state.steer * 0.06;
      car.rotation.z = state.steer * 0.01;
      wheel.rotation.z = -state.steer * 1.8;
      speedN.rotation.z = 2.2 - (state.speed * 3.6 / 200) * 4.4;
      rpmN.rotation.z = 2.2 - Math.min(1, 0.12 + state.speed / 30) * 4.4 + Math.sin(state.t * 20) * 0.02;
      fresh.rotation.z = Math.sin(state.t * 2.3) * 0.15 - state.steer * 0.3; fresh.rotation.x = Math.sin(state.t * 1.7) * 0.1;
      engine?.setLevel?.(state.stall > 0 ? 0.05 : state.speed / 22);
      // lamp light recycling
      const near = lampZ.map((z, i) => ({ i, d: state.z - z })).filter((o) => o.d > -12 && o.d < 70).sort((a, b) => a.d - b.d).slice(0, 2);
      lampLights.forEach((l, i) => { const o = near[i]; if (o) { l.position.set(lampX[o.i] * 0.82, 6.7, lampZ[o.i]); l.intensity = 26; } else l.intensity = 0; });
      // headlight flicker
      if (flick > 0) { flick -= dt; head.intensity = Math.random() < 0.5 ? 0 : 75; headGlow.visible = head.intensity > 0; } else { head.intensity = 75; headGlow.visible = true; }
      // tall man: visible only from afar
      const td = state.z - tall.root.position.z;
      tall.root.visible = td > 12 && td < 80;
      flames.forEach((f, i) => { if (i < 28) { f.position.y += dt * (1 + (i % 3)); if (f.position.y > 8) f.position.y = 0; } });

      if (mode === 'arrive') {
        if (state.z < -40) once('radio');
        if (state.z < -170) once('thought');
        if (state.z < -280 && td > 0) once('tall');
        // dog crossing
        if (state.z < -385 && !dogActive && !fired.has('dog')) { dogActive = true; fired.add('dog'); dogX = -7; dog.root.visible = true; dog.root.position.set(dogX, 0, state.z - 40); dog.root.rotation.y = Math.PI / 2; }
        if (dogActive) {
          dogX += dt * 6.5; dog.root.position.x = dogX;
          const ph = state.t * 16; dog.parts.lLeg.rotation.x = Math.sin(ph) * 0.7; dog.parts.rLeg.rotation.x = -Math.sin(ph) * 0.7;
          const dz = dog.root.position.z - state.z;
          if (Math.abs(dz) < 3 && Math.abs(dogX - state.x) < 1.6) { dogActive = false; dog.root.visible = false; lvl.onEvent('hit'); hands.visible = true; flick = 1.5; state.speed *= 0.4; }
          else if (dogX > 8 || dz > 4) { dogActive = false; dog.root.visible = false; lvl.onEvent('dogpass'); }
        }
        if (state.z < -480 && once('stall')) { state.stall = 3.5; flick = 3; roadGhost.root.visible = true; roadGhost.root.position.set(state.x, 0, state.z + 22); roadGhost.root.rotation.y = Math.PI; setTimeout(() => { roadGhost.root.visible = false; hands.visible = false; }, 4500); }
        if (state.z < -540) once('title');
        if (state.z < -592 && !lvl.finished) { lvl.finished = true; lvl.onEvent('arrive'); }
      } else {
        if (mode === 'dawn') lvl.setDawn(Math.min(1, state.t / 30));
        if (state.t > 3) once('start');
        if (mode === 'passenger' && state.t > 11 && once('passenger')) { passenger.root.visible = true; flick = 2; }
        if (state.z < -230 && !lvl.finished) { lvl.finished = true; lvl.onEvent('end'); }
      }
    },
  };
  return lvl;
}
