// Villa upgrade for the house level: second storey (duplex) reached by an exterior stone staircase,
// balcony with glass railing, a study with real books, garden walls, lawn, cypress trees, lamps and a
// swimming pool with animated water (moving normals + caustics + underwater lights).
import * as THREE from 'three';
import { mat, tex } from '../textures';
import { hiCanvas, finishTex } from '../gfx';
import type { Collision } from '../physics';
import { bookRow, rbox } from '../storeRevamp';
import { lux } from './luxury';

const UP = 3.12;                 // upstairs floor height
const ST_X0 = 5.0, ST_X1 = 10.7; // stair run (top at ST_X0)
const ST_Z0 = 6.2, ST_Z1 = 7.4;

function canvasT(w: number, h: number, draw: (c: CanvasRenderingContext2D, w: number, h: number) => void, rep?: [number, number]) {
  const { cv, c } = hiCanvas(w, h); draw(c, w, h);
  const t = finishTex(new THREE.CanvasTexture(cv)); t.wrapS = t.wrapT = THREE.RepeatWrapping; if (rep) t.repeat.set(...rep); return t;
}
/** tileable water normal map from summed sine waves */
function waterNormals() {
  const S = 256; const cv = document.createElement('canvas'); cv.width = cv.height = S; const c = cv.getContext('2d')!;
  const id = c.createImageData(S, S); const h = (x: number, y: number) => {
    let v = 0; for (let k = 1; k <= 5; k++) { const a = k * 2 * Math.PI / S; v += Math.sin(x * a * (k % 3 + 1) + y * a * ((k + 1) % 2)) / k + Math.cos(y * a * (k % 2 + 1) - x * a) / (k * 1.7); } return v;
  };
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const dx = h(x + 1, y) - h(x - 1, y), dy = h(x, y + 1) - h(x, y - 1);
    const nx = -dx * 0.6, ny = -dy * 0.6, nz = 1; const l = Math.hypot(nx, ny, nz);
    const i = (y * S + x) * 4; id.data[i] = (nx / l * 0.5 + 0.5) * 255; id.data[i + 1] = (ny / l * 0.5 + 0.5) * 255; id.data[i + 2] = (nz / l * 0.5 + 0.5) * 255; id.data[i + 3] = 255;
  }
  c.putImageData(id, 0, 0);
  const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
}
function causticsTex() {
  return canvasT(256, 256, (c, w, h) => {
    c.fillStyle = '#000'; c.fillRect(0, 0, w, h); c.strokeStyle = 'rgba(255,255,255,0.55)';
    for (let i = 0; i < 70; i++) { c.lineWidth = 1 + Math.random() * 2.5; c.beginPath(); const x = Math.random() * w, y = Math.random() * h, r = 10 + Math.random() * 30; c.ellipse(x, y, r, r * (0.5 + Math.random() * 0.6), Math.random() * 3, 0, Math.PI * 1.5); c.stroke(); }
  }, [3, 2]);
}

export interface Villa { heightAt: (x: number, z: number, y: number) => number; update: (dt: number) => void }

export function buildVilla(group: THREE.Group, col: Collision, q: string): Villa {
  const add = (g: THREE.BufferGeometry, m: THREE.Material | THREE.Material[], x: number, y: number, z: number, parent: THREE.Object3D = group) => { const me = new THREE.Mesh(g, m as THREE.Material); me.position.set(x, y, z); parent.add(me); return me; };
  const stone = mat({ map: lux.stone(), rough: 0.95, key: 'hext-lux' });
  const white = mat({ color: 0xf4f1ea, rough: 0.7, key: 'villa-white' });
  const trav = canvasT(256, 256, (c, w, h) => { c.fillStyle = '#e2d6c0'; c.fillRect(0, 0, w, h); for (let i = 0; i < 5000; i++) { c.fillStyle = `rgba(${150 + Math.random() * 40},${130 + Math.random() * 30},${100},${Math.random() * 0.12})`; c.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 3, 1); } c.strokeStyle = 'rgba(120,100,70,0.45)'; c.lineWidth = 2; c.strokeRect(0, 0, w, h); c.beginPath(); c.moveTo(w / 2, 0); c.lineTo(w / 2, h); c.stroke(); }, [1, 1]);
  const travM = new THREE.MeshStandardMaterial({ map: trav, roughness: 0.6 });
  const glassRail = new THREE.MeshStandardMaterial({ color: 0xcfe6f0, transparent: true, opacity: 0.22, roughness: 0.03, metalness: 0.3, depthWrite: false, side: THREE.DoubleSide });
  const steel = mat({ color: 0xb8bcc0, metal: 0.95, rough: 0.2, key: 'villa-steel' });
  const wallBox = (x: number, y: number, z: number, w: number, h: number, d: number, m: THREE.Material = stone, collide = true, minY = y - 0.05) => {
    add(new THREE.BoxGeometry(w, h, d), m, x, y + h / 2, z);
    if (collide) col.add(x - w / 2, x + w / 2, z - d / 2, z + d / 2, { minY, maxY: y + h });
  };

  // ================= ground: lawn, paths, garden walls =================
  // lawn strips around the pool area (x −6.8..5, z 8.2..17.4 is the pool deck)
  const grassM = mat({ map: tex.grass(), color: 0x5a7a4a, rough: 1, key: 'villa-grass' });
  for (const [cx, cz, w, d] of [[-1.5, -1.9, 13, 20.2], [-1.5, 22.7, 13, 10.6], [-7.4, 12.8, 1.2, 9.2]] as number[][]) {
    const gp = new THREE.Mesh(new THREE.PlaneGeometry(w, d), grassM); gp.rotation.x = -Math.PI / 2; gp.position.set(cx, 0.01, cz); group.add(gp);
  }
  for (const [x, z, w, d] of [[-8.1, 6, 0.3, 36], [1, 24.1, 18.5, 0.3], [1, -12.1, 18.5, 0.3], [10, 21, 0.3, 6]] as number[][]) {
    wallBox(x, 0, z, w, 1.9, d, stone, true, -0.5);
    add(new THREE.BoxGeometry(w + 0.1, 0.08, d + 0.1), white, x, 1.94, z);
  }
  // stepping-stone path from the front yard round to the pool
  for (let k = 0; k < 9; k++) { const s = add(rbox(0.7, 0.05, 0.45, 0.02), travM, 10.6 - k * 0.15, 0.03, 8.2 + k * 0.75); s.rotation.y = 0.2; }

  // ================= swimming pool =================
  const PX0 = -5, PX1 = 3, PZ0 = 10, PZ1 = 15, DEPTH = 1.4;
  const tileT = canvasT(256, 256, (c, w, h) => { c.fillStyle = '#4ab8d8'; c.fillRect(0, 0, w, h); for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) { const b = Math.random() * 30; c.fillStyle = `rgb(${50 + b},${170 + b},${210 + b * 0.5})`; c.fillRect(i * 32 + 1, j * 32 + 1, 30, 30); } }, [4, 2]);
  const poolTile = new THREE.MeshStandardMaterial({ map: tileT, roughness: 0.25 });
  const caus = causticsTex(); const causM = new THREE.MeshBasicMaterial({ map: caus, color: 0x9fe8ff, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false });
  const caus2 = caus.clone(); caus2.needsUpdate = true; const causM2 = causM.clone(); causM2.map = caus2;
  const pw = PX1 - PX0, pd = PZ1 - PZ0;
  const pfloor = new THREE.Mesh(new THREE.PlaneGeometry(pw, pd), poolTile); pfloor.rotation.x = -Math.PI / 2; pfloor.position.set((PX0 + PX1) / 2, -DEPTH, (PZ0 + PZ1) / 2); group.add(pfloor);
  for (const cm of [causM, causM2]) { const cp = new THREE.Mesh(new THREE.PlaneGeometry(pw, pd), cm); cp.rotation.x = -Math.PI / 2; cp.position.set((PX0 + PX1) / 2, -DEPTH + 0.01, (PZ0 + PZ1) / 2); group.add(cp); }
  const wallT = tileT.clone(); wallT.repeat.set(4, 0.7); wallT.needsUpdate = true; const pwM = new THREE.MeshStandardMaterial({ map: wallT, roughness: 0.25, side: THREE.DoubleSide });
  for (const [x, z, w, ry] of [[(PX0 + PX1) / 2, PZ0, pw, 0], [(PX0 + PX1) / 2, PZ1, pw, Math.PI], [PX0, (PZ0 + PZ1) / 2, pd, Math.PI / 2], [PX1, (PZ0 + PZ1) / 2, pd, -Math.PI / 2]] as number[][]) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, DEPTH), pwM); m.position.set(x, -DEPTH / 2, z); m.rotation.y = ry; group.add(m);
  }
  // mosaic waterline band
  const bandT = canvasT(512, 32, (c, w, h) => { for (let x = 0; x < w; x += 8) for (let y = 0; y < h; y += 8) { c.fillStyle = ['#0d3a6a', '#1a6aa8', '#e8f4ff', '#0a2a4a'][(x / 8 + y / 8) % 4]; c.fillRect(x, y, 7, 7); } }, [6, 1]);
  const bandM = new THREE.MeshStandardMaterial({ map: bandT, roughness: 0.2, side: THREE.DoubleSide });
  for (const [x, z, w, ry] of [[(PX0 + PX1) / 2, PZ0 + 0.003, pw, 0], [(PX0 + PX1) / 2, PZ1 - 0.003, pw, Math.PI], [PX0 + 0.003, (PZ0 + PZ1) / 2, pd, Math.PI / 2], [PX1 - 0.003, (PZ0 + PZ1) / 2, pd, -Math.PI / 2]] as number[][]) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, 0.18), bandM); m.position.set(x, -0.14, z); m.rotation.y = ry; group.add(m);
  }
  // water surface
  const nrm = waterNormals(); nrm.repeat.set(3, 2);
  const water = new THREE.MeshStandardMaterial({ color: 0x1a90c8, transparent: true, opacity: 0.78, roughness: 0.03, metalness: 0.2, normalMap: nrm, normalScale: new THREE.Vector2(0.5, 0.5), envMapIntensity: 3.2, depthWrite: false });
  const wsurf = new THREE.Mesh(new THREE.PlaneGeometry(pw, pd, 1, 1), water); wsurf.rotation.x = -Math.PI / 2; wsurf.position.set((PX0 + PX1) / 2, -0.18, (PZ0 + PZ1) / 2); wsurf.renderOrder = 4; group.add(wsurf);
  // travertine deck & bull-nose coping (4 strips around the hole)
  const deck = (x: number, z: number, w: number, d: number) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({ map: (() => { const t = trav.clone(); t.repeat.set(w / 0.6, d / 0.6); t.needsUpdate = true; return t; })(), roughness: 0.6 })); m.rotation.x = -Math.PI / 2; m.position.set(x, 0.035, z); group.add(m); };
  deck(-0.9, PZ0 - 0.9, 11.8, 1.8); deck(-0.9, PZ1 + 1.2, 11.8, 2.4); deck(PX0 - 0.9, (PZ0 + PZ1) / 2, 1.8, pd); deck(PX1 + 1.0, (PZ0 + PZ1) / 2, 2.0, pd);
  for (const [x, z, w, d] of [[(PX0 + PX1) / 2, PZ0, pw + 0.3, 0.3], [(PX0 + PX1) / 2, PZ1, pw + 0.3, 0.3], [PX0, (PZ0 + PZ1) / 2, 0.3, pd], [PX1, (PZ0 + PZ1) / 2, 0.3, pd]] as number[][]) add(rbox(w, 0.06, d, 0.025), mat({ color: 0xf2ebdc, rough: 0.5, key: 'coping' }), x, 0.05, z);
  col.add(PX0, PX1, PZ0, PZ1, { sight: false, maxY: 0.3 });
  // pool ladder
  for (const sz of [-0.25, 0.25]) { const r = add(new THREE.TorusGeometry(0.3, 0.02, 8, 16, Math.PI), steel, PX1 - 0.15, 0.25, PZ0 + 1.2 + sz); r.rotation.set(0, Math.PI / 2, 0); add(new THREE.CylinderGeometry(0.02, 0.02, 1.3, 8), steel, PX1 - 0.45, -0.5, PZ0 + 1.2 + sz); }
  for (let k = 0; k < 3; k++) add(new THREE.BoxGeometry(0.08, 0.02, 0.5), steel, PX1 - 0.45, -0.3 - k * 0.3, PZ0 + 1.2);
  // underwater lights (pooled)
  for (const lx of [-3, 1]) { const l = new THREE.PointLight(0x40c8ff, 6, 6, 2); l.position.set(lx, -0.9, (PZ0 + PZ1) / 2); group.add(l); const lens = add(new THREE.CircleGeometry(0.1, 16), new THREE.MeshBasicMaterial({ color: 0xbff0ff }), lx, -0.7, PZ0 + 0.01); void lens; }
  // loungers + umbrella
  const cushion = mat({ color: 0xf4f0e6, rough: 0.9, key: 'lounger-c' });
  for (let k = 0; k < 3; k++) {
    const g = new THREE.Group(); g.position.set(-4 + k * 2.6, 0, PZ1 + 1.4); group.add(g);
    add(rbox(0.7, 0.08, 1.9, 0.03), mat({ map: tex.wood(), color: 0x8a6a4a, rough: 0.6, key: 'lounger-w' }), 0, 0.32, 0, g);
    add(rbox(0.66, 0.08, 1.2, 0.03), cushion, 0, 0.4, 0.3, g);
    const back = add(rbox(0.66, 0.08, 0.7, 0.03), cushion, 0, 0.6, -0.6, g); back.rotation.x = 0.8;
    for (const [lx, lz] of [[-0.3, -0.85], [0.3, -0.85], [-0.3, 0.85], [0.3, 0.85]]) add(new THREE.BoxGeometry(0.05, 0.3, 0.05), mat({ map: tex.wood(), color: 0x8a6a4a, rough: 0.6, key: 'lounger-w' }), lx, 0.15, lz, g);
    col.addCentered(-4 + k * 2.6, PZ1 + 1.4, 0.7, 1.9, { sight: false, maxY: 0.5 });
  }
  const umb = new THREE.Group(); umb.position.set(5.2, 0, PZ1 + 1.5); group.add(umb);
  add(new THREE.CylinderGeometry(0.025, 0.025, 2.5, 8), steel, 0, 1.25, 0, umb);
  add(new THREE.ConeGeometry(1.4, 0.45, 8, 1, true), new THREE.MeshStandardMaterial({ color: 0xf2ece0, roughness: 0.9, side: THREE.DoubleSide }), 0, 2.45, 0, umb);

  // ================= cypress trees, flower beds, garden lamps =================
  const cyp = mat({ color: 0x1e3a24, rough: 0.95, key: 'cypress' });
  for (const [x, z] of [[-7, -10], [-7, -5], [-7, 0], [-7, 5], [-7, 20], [-3, 23], [3, 23], [8.6, 23], [-7, 14.5]]) {
    const t = add(new THREE.CylinderGeometry(0.06, 0.08, 0.6, 6), mat({ color: 0x3a2a1a, key: 'trunk2' }), x, 0.3, z); void t;
    const c = add(new THREE.SphereGeometry(0.55, 10, 12), cyp, x, 2.1, z); c.scale.set(1, 3.4, 1);
  }
  const flowers = [0xd83a5a, 0xf2c400, 0xf4f0f0, 0x8a3ab8];
  for (let k = 0; k < 40; k++) { const fx = -7.2 + Math.random() * 0.6, fz = -10 + Math.random() * 32; add(new THREE.SphereGeometry(0.06, 6, 4), mat({ color: flowers[k % 4], rough: 0.8, key: 'flw' + (k % 4) }), fx, 0.18, fz); }
  for (const [x, z] of [[9.0, 8.2], [4.0, 17.8], [-6.2, 17.8], [-6.2, 8.4]]) {
    add(new THREE.CylinderGeometry(0.04, 0.05, 1.2, 8), mat({ color: 0x1a1a1c, metal: 0.6, key: 'lamp-post' }), x, 0.6, z);
    add(new THREE.SphereGeometry(0.12, 12, 8), new THREE.MeshBasicMaterial({ color: 0xfff0c8 }), x, 1.28, z);
    const l = new THREE.PointLight(0xffd8a0, 4, 7, 2); l.position.set(x, 1.3, z); group.add(l);
  }

  // ================= upstairs (duplex) =================
  // floor (oak), walls (stone outside / plaster inside via double boxes), roof slab with eaves
  const oak = mat({ map: lux.herringbone(), rough: 0.4, key: 'up-floor' });
  const uf = new THREE.Mesh(new THREE.PlaneGeometry(10, 6), oak); uf.rotation.x = -Math.PI / 2; uf.position.set(5, UP + 0.012, 3); group.add(uf);
  const inner = mat({ map: lux.wainscot(), rough: 0.8, key: 'hwall-lux' });
  const H2 = 2.7, T = 0.2;
  const upWall = (x: number, z: number, w: number, d: number) => { add(new THREE.BoxGeometry(w, H2, d), stone, x, UP + H2 / 2, z); col.add(x - w / 2, x + w / 2, z - d / 2, z + d / 2, { minY: UP - 0.12, maxY: UP + H2 }); };
  upWall(5, -T / 2 + 0.1, 10.2, T); upWall(-T / 2 + 0.1, 3, T, 6); upWall(10 - 0.1 + T / 2 - 0.1, 3, T, 6);
  // back wall z=6 with sliding door (x 2..4) + big window (x 6..9)
  upWall(1, 6, 2, T); upWall(5, 6, 2, T); upWall(9.6, 6, 0.8, T);
  add(new THREE.BoxGeometry(2, 0.5, T), stone, 3, UP + H2 - 0.25, 6); add(new THREE.BoxGeometry(3.2, 0.5, T), stone, 7.6, UP + H2 - 0.25, 6); add(new THREE.BoxGeometry(3.2, 0.9, T), stone, 7.6, UP + 0.45, 6);
  col.add(6, 9.2, 5.9, 6.1, { minY: UP - 0.12, maxY: UP + H2 });
  const glassM = new THREE.MeshStandardMaterial({ color: 0x9ab0c0, transparent: true, opacity: 0.16, roughness: 0.03, metalness: 0.5, depthWrite: false, side: THREE.DoubleSide });
  add(new THREE.PlaneGeometry(3.2, 1.3), glassM, 7.6, UP + 1.55, 6);
  const slider = add(new THREE.PlaneGeometry(1.0, 2.2), glassM, 2.5, UP + 1.1, 6.02); void slider;
  add(new THREE.BoxGeometry(2.0, 0.05, 0.08), steel, 3, UP + 2.2, 6); add(new THREE.BoxGeometry(0.05, 2.2, 0.08), steel, 3.0, UP + 1.1, 6.03);
  // inner plaster skins
  for (const [x, z, w, ry] of [[5, 0.205, 9.6, 0], [0.205, 3, 5.6, Math.PI / 2], [9.795, 3, 5.6, -Math.PI / 2]] as number[][]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(w, H2), inner); p.position.set(x, UP + H2 / 2, z); p.rotation.y = ry; group.add(p); }
  // roof with eaves & parapet
  add(new THREE.BoxGeometry(11.2, 0.28, 7.6), white, 5, UP + H2 + 0.14, 3.4);
  add(new THREE.BoxGeometry(11.2, 0.4, 0.15), white, 5, UP + H2 + 0.48, -0.35);
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(9.6, 5.6), mat({ color: 0xf6f4ee, rough: 1, key: 'up-ceil' })); ceil.rotation.x = Math.PI / 2; ceil.position.set(5, UP + H2 - 0.01, 3); group.add(ceil);
  // ---- study: wall-to-wall bookcase with real books, desk, armchair, lamp ----
  const walnut = mat({ map: tex.wood(), color: 0x5a3a24, rough: 0.45, key: 'lux-walnut' });
  add(new THREE.BoxGeometry(5.6, 2.3, 0.36), walnut, 4.6, UP + 1.15, 0.38); col.add(1.8, 7.4, 0.2, 0.56, { minY: UP - 0.1, maxY: UP + 2.4 });
  for (let s = 0; s < 6; s++) {
    add(new THREE.BoxGeometry(5.5, 0.025, 0.3), walnut, 4.6, UP + 0.12 + s * 0.38, 0.46);
    for (const [a, b] of [[1.9, 3.7], [3.75, 5.5], [5.55, 7.3]]) bookRow(group, a, b, UP + 0.135 + s * 0.38, 0.47, 1);
  }
  for (const vx of [1.85, 3.72, 5.52, 7.35]) add(new THREE.BoxGeometry(0.04, 2.3, 0.34), walnut, vx, UP + 1.15, 0.42);
  // desk, chair, lamp, globe, rug, armchair
  add(rbox(1.6, 0.05, 0.8, 0.015), walnut, 4.6, UP + 0.76, 2.4); for (const [lx, lz] of [[-0.75, -0.35], [0.75, -0.35], [-0.75, 0.35], [0.75, 0.35]]) add(new THREE.BoxGeometry(0.05, 0.75, 0.05), walnut, 4.6 + lx, UP + 0.375, 2.4 + lz);
  col.addCentered(4.6, 2.4, 1.6, 0.8, { minY: UP - 0.1, maxY: UP + 0.8 });
  add(rbox(0.5, 0.1, 0.5, 0.03), mat({ color: 0x3a2014, rough: 0.6, key: 'leather' }), 4.6, UP + 0.47, 3.15); add(rbox(0.5, 0.55, 0.08, 0.03), mat({ color: 0x3a2014, rough: 0.6, key: 'leather' }), 4.6, UP + 0.8, 3.42);
  add(new THREE.CylinderGeometry(0.08, 0.1, 0.03, 12), steel, 5.2, UP + 0.8, 2.25); add(new THREE.CylinderGeometry(0.008, 0.008, 0.35, 6), steel, 5.2, UP + 0.97, 2.25);
  add(new THREE.ConeGeometry(0.12, 0.14, 14, 1, true), new THREE.MeshStandardMaterial({ color: 0x1e5a3a, emissive: 0xffd8a0, emissiveIntensity: 0.3, side: THREE.DoubleSide }), 5.2, UP + 1.17, 2.25);
  const dl = new THREE.PointLight(0xffd8a0, 3, 5, 2); dl.position.set(5.2, UP + 1.3, 2.4); group.add(dl);
  add(new THREE.SphereGeometry(0.15, 20, 14), new THREE.MeshStandardMaterial({ map: tex.sign('🌍', '#2a5a8a', '#3a8a4a', 128, 64, '60px Arial'), roughness: 0.5 }), 3.9, UP + 0.98, 2.3);
  const urug = new THREE.Mesh(new THREE.PlaneGeometry(3, 2), mat({ map: lux.rug(), rough: 1, key: 'lux-rug' })); urug.rotation.x = -Math.PI / 2; urug.position.set(4.6, UP + 0.02, 2.8); group.add(urug);
  add(rbox(0.9, 0.42, 0.85, 0.06), mat({ map: lux.velvet(), rough: 0.85, key: 'fabric-lux' }), 8.6, UP + 0.21, 2.0);
  add(rbox(0.9, 0.55, 0.18, 0.06), mat({ map: lux.velvet(), rough: 0.85, key: 'fabric-lux' }), 8.6, UP + 0.6, 1.62);
  col.addCentered(8.6, 1.9, 0.9, 1.0, { minY: UP - 0.1, maxY: UP + 0.9 });
  const cl = new THREE.PointLight(0xfff0dc, 5, 8, 2); cl.position.set(5, UP + 2.4, 3.3); group.add(cl);

  // ================= balcony + exterior stone staircase =================
  add(new THREE.BoxGeometry(5.2, 0.2, 1.6), white, 2.5, UP - 0.1, 6.8);
  const bdeck = new THREE.Mesh(new THREE.PlaneGeometry(5.2, 1.55), travM); bdeck.rotation.x = -Math.PI / 2; bdeck.position.set(2.5, UP + 0.012, 6.8); group.add(bdeck);
  add(new THREE.PlaneGeometry(5.2, 1.0), glassRail, 2.5, UP + 0.5, 7.58); add(new THREE.PlaneGeometry(1.6, 1.0), glassRail, -0.08, UP + 0.5, 6.8).rotation.y = Math.PI / 2;
  add(new THREE.BoxGeometry(5.2, 0.05, 0.06), steel, 2.5, UP + 1.0, 7.58); add(new THREE.BoxGeometry(0.06, 0.05, 1.6), steel, -0.08, UP + 1.0, 6.8);
  col.add(-0.1, 5.1, 7.52, 7.64, { minY: UP - 0.2, maxY: UP + 1.1 }); col.add(-0.14, -0.02, 6.0, 7.64, { minY: UP - 0.2, maxY: UP + 1.1 });
  const N = 16, run = (ST_X1 - ST_X0) / N, rise = UP / N;
  for (let k = 0; k < N; k++) {
    const x = ST_X1 - run * (k + 0.5), y = rise * (k + 1);
    add(new THREE.BoxGeometry(run + 0.02, rise, ST_Z1 - ST_Z0), travM, x, y - rise / 2, (ST_Z0 + ST_Z1) / 2);
    add(new THREE.BoxGeometry(run, y - rise, ST_Z1 - ST_Z0 - 0.02), stone, x, (y - rise) / 2, (ST_Z0 + ST_Z1) / 2); // solid stone base
  }
  // outer stair stringer wall + glass balustrade
  const len = Math.hypot(ST_X1 - ST_X0, UP), ang = Math.atan2(UP, ST_X1 - ST_X0);
  const gr = add(new THREE.PlaneGeometry(len, 1.0), glassRail, (ST_X0 + ST_X1) / 2, UP / 2 + 0.5, ST_Z1 + 0.04); gr.rotation.z = ang;
  const hr = add(new THREE.BoxGeometry(len, 0.05, 0.06), steel, (ST_X0 + ST_X1) / 2, UP / 2 + 1.0, ST_Z1 + 0.04); hr.rotation.z = ang;
  col.add(ST_X0, ST_X1 + 0.2, ST_Z1, ST_Z1 + 0.12, { minY: -0.5, maxY: 6 });
  // under the balcony you can't walk into the high end of the staircase
  col.add(ST_X0 - 0.12, ST_X0 + 0.02, 6.0, 7.6, { minY: -0.5, maxY: 2.9 });
  // villa entrance portico at the front door
  for (const pz of [2.1, 3.9]) { add(new THREE.CylinderGeometry(0.13, 0.15, 2.7, 16), white, 10.9, 1.35, pz); col.addCentered(10.9, pz, 0.3, 0.3); }
  add(new THREE.BoxGeometry(1.4, 0.18, 2.4), white, 10.7, 2.8, 3);
  for (let k = 0; k < 2; k++) add(rbox(1.2, 0.08, 2.0 - k * 0.3, 0.02), travM, 10.75 + k * 0.05, 0.04 + k * 0.08, 3);
  void q;

  const t0 = performance.now();
  return {
    heightAt(x, z, y) {
      if (x > ST_X0 - 0.05 && x < ST_X1 && z > ST_Z0 && z < ST_Z1) return Math.max(0, Math.min(UP, ((ST_X1 - x) / (ST_X1 - ST_X0)) * UP));
      if (y > 1.5 && ((x > -0.2 && x < 10.2 && z > -0.2 && z < 6.1) || (x > -0.2 && x < ST_X0 + 0.1 && z >= 6.0 && z < 7.6))) return UP;
      return 0;
    },
    update(dt) {
      const t = (performance.now() - t0) * 0.001;
      nrm.offset.set(t * 0.018, t * 0.011);
      caus.offset.set(t * 0.03, t * 0.02); caus2.offset.set(-t * 0.025, t * 0.031);
      causM.opacity = 0.32 + Math.sin(t * 1.3) * 0.06;
      void dt;
    },
  };
}
