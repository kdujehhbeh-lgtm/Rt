// Realistic documents & signage textures: handwritten notes, notice boards, logbook cover, contract,
// shift schedule, proper bilingual door plates, coffee machine panel.
import * as THREE from 'three';
import { gfx, hiCanvas, finishTex } from './gfx';

const FONT = 'Vazirmatn, Tahoma, Arial, sans-serif';
const cache = new Map<string, THREE.CanvasTexture>();
let seed = 1;
const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
function T(key: string, w: number, h: number, draw: (c: CanvasRenderingContext2D, w: number, h: number) => void) {
  const k = key + '@' + gfx.texScale;
  const hit = cache.get(k); if (hit) return hit;
  const { cv, c } = hiCanvas(w, h);
  seed = 11; for (let i = 0; i < key.length; i++) seed = (seed * 29 + key.charCodeAt(i)) % 2147483647;
  draw(c, w, h);
  const t = finishTex(new THREE.CanvasTexture(cv));
  cache.set(k, t); return t;
}
export function rrect(c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r); c.lineTo(x + w, y + h - r);
  c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r); c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
}
function txt(c: CanvasRenderingContext2D, s: string, x: number, y: number, size: number, color: string, weight = 'bold', align: CanvasTextAlign = 'center', rot = 0, maxW?: number) {
  c.save(); c.translate(x, y); c.rotate(rot);
  c.font = `${weight} ${size}px ${FONT}`; c.fillStyle = color; c.textAlign = align; c.textBaseline = 'middle';
  c.direction = /[\u0600-\u06FF]/.test(s) ? 'rtl' : 'ltr'; c.fillText(s, 0, 0, maxW); c.restore();
}
function paper(c: CanvasRenderingContext2D, w: number, h: number, base = '#efe9d8', lines = false, age = 0.3) {
  c.fillStyle = base; c.fillRect(0, 0, w, h);
  for (let i = 0; i < w * h / 30; i++) { c.fillStyle = `rgba(${rnd() < 0.5 ? '110,90,50' : '255,255,255'},${rnd() * 0.05})`; c.fillRect(rnd() * w, rnd() * h, 1 + rnd() * 2, 1); }
  if (lines) {
    for (let y = h * 0.14; y < h - 10; y += h / 18) { c.strokeStyle = 'rgba(70,110,180,0.28)'; c.lineWidth = 1; c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke(); }
    c.strokeStyle = 'rgba(200,50,50,0.35)'; c.beginPath(); c.moveTo(w * 0.88, 0); c.lineTo(w * 0.88, h); c.stroke();
  }
  const g = c.createRadialGradient(w / 2, h / 2, w * 0.25, w / 2, h / 2, Math.max(w, h) * 0.75);
  g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(120,85,30,${age})`); c.fillStyle = g; c.fillRect(0, 0, w, h);
}
function stain(c: CanvasRenderingContext2D, x: number, y: number, r: number) {
  c.strokeStyle = 'rgba(120,75,30,0.35)'; c.lineWidth = r * 0.12; c.beginPath(); c.arc(x, y, r, 0.4, Math.PI * 1.85); c.stroke();
  const g = c.createRadialGradient(x, y, r * 0.2, x, y, r); g.addColorStop(0, 'rgba(130,85,35,0.06)'); g.addColorStop(1, 'rgba(130,85,35,0.14)'); c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
}
function stamp(c: CanvasRenderingContext2D, x: number, y: number, r: number, text: string, col = 'rgba(170,20,30,0.75)') {
  c.save(); c.translate(x, y); c.rotate(-0.25); c.strokeStyle = col; c.lineWidth = 4;
  c.beginPath(); c.arc(0, 0, r, 0, Math.PI * 2); c.stroke(); c.beginPath(); c.arc(0, 0, r * 0.78, 0, Math.PI * 2); c.stroke();
  txt(c, text, 0, 0, r * 0.32, col, '900'); txt(c, 'PETRO 24', 0, -r * 0.55, r * 0.2, col, '900'); c.restore();
}
function hand(c: CanvasRenderingContext2D, lines: string[], x: number, y0: number, lh: number, size: number, color = '#1d2a5a', w?: number) {
  lines.forEach((s, i) => txt(c, s, x, y0 + i * lh, size, color, i === 0 ? '900' : 'bold', 'right', (rnd() - 0.5) * 0.04, w));
}

export const docs = {
  rules: () => T('rules', 512, 680, (c, w, h) => {
    paper(c, w, h, '#f1ead6', true, 0.45);
    txt(c, 'قوانین شیفت شب', w / 2, 52, 40, '#111', '900');
    hand(c, ['۱. چراغ‌ها همیشه روشن بمانند. همیشه.', '۲. با بعضی مشتری‌ها... حرف نزن', '   فقط حساب کن.', '۳. کسی پشت شیشه بود؟ در را باز نکن.', '۴. به بی‌چهره خیره نشو.', '۵. تلفن بعد از ساعت ۴ را...', '۶. تا صبح دوام بیاور.'], w - 70, 130, 72, 27, '#1d2a5a', w - 100);
    c.fillStyle = '#efe9d8'; c.beginPath(); c.moveTo(w, h * 0.55); for (let y = h * 0.55; y < h; y += 14) c.lineTo(w - 30 - rnd() * 40, y); c.lineTo(w, h); c.fill(); // torn corner
    stain(c, 120, 560, 60);
  }),
  schedule: () => T('schedule', 512, 360, (c, w, h) => {
    paper(c, w, h, '#fbfbf8', false, 0.15);
    c.fillStyle = '#0d3a6a'; c.fillRect(0, 0, w, 54); txt(c, 'برنامه شیفت — آبان', w / 2, 28, 26, '#fff', '900');
    const names = ['حسین یزدانی', 'محمد رضایی', 'سارا کریمی', 'علی نوروزی', 'کارمند جدید'];
    const days = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
    days.forEach((d, i) => txt(c, d, w - 170 - i * 46, 80, 18, '#333', '900'));
    names.forEach((n, r) => {
      const y = 116 + r * 46; c.strokeStyle = '#bbb'; c.beginPath(); c.moveTo(10, y + 22); c.lineTo(w - 10, y + 22); c.stroke();
      txt(c, n, w - 16, y, 18, r === 4 ? '#a00' : '#222', 'bold', 'right');
      days.forEach((_, i) => {
        const x = w - 170 - i * 46;
        if (r < 4) { c.strokeStyle = 'rgba(160,0,0,0.8)'; c.lineWidth = 3; c.beginPath(); c.moveTo(x - 14, y - 10); c.lineTo(x + 14, y + 10); c.moveTo(x + 14, y - 10); c.lineTo(x - 14, y + 10); c.stroke(); c.lineWidth = 1; }
        else txt(c, 'شب', x, y, 15, '#0d3a6a', '900');
      });
    });
  }),
  safety: () => T('safety', 360, 480, (c, w, h) => {
    paper(c, w, h, '#fffbe6', false, 0.2);
    c.fillStyle = '#f2c400'; c.fillRect(0, 0, w, 80); c.fillStyle = '#111';
    c.beginPath(); c.moveTo(48, 66); c.lineTo(78, 14); c.lineTo(108, 66); c.closePath(); c.fill(); txt(c, '!', 78, 48, 34, '#f2c400', '900');
    txt(c, 'ایمنی جایگاه', w / 2 + 30, 42, 28, '#111', '900');
    hand(c, ['• خاموش کردن موتور الزامی است', '• استعمال دخانیات ممنوع', '• استفاده از تلفن همراه ممنوع', '• کپسول آتش‌نشانی: ستون ۲', '• قطع اضطراری: ستون ۱'], w - 24, 130, 52, 20, '#222', w - 40);
    c.strokeStyle = '#c41e1e'; c.lineWidth = 4; c.strokeRect(10, 92, w - 20, h - 104);
  }),
  staffPhoto: () => T('staffphoto', 400, 300, (c, w, h) => {
    c.fillStyle = '#f4f2ec'; c.fillRect(0, 0, w, h);
    const g = c.createLinearGradient(0, 16, 0, h - 60); g.addColorStop(0, '#6a7480'); g.addColorStop(1, '#2a2e33'); c.fillStyle = g; c.fillRect(16, 16, w - 32, h - 76);
    for (let i = 0; i < 5; i++) {
      const x = 60 + i * 70, y = 130;
      c.fillStyle = '#0d3a6a'; c.beginPath(); c.ellipse(x, y + 70, 30, 46, 0, Math.PI, 0); c.fill();
      c.fillStyle = i === 4 ? '#000' : '#c49a80'; c.beginPath(); c.ellipse(x, y, 18, 23, 0, 0, Math.PI * 2); c.fill();
      if (i !== 4) { c.fillStyle = '#1a120c'; c.beginPath(); c.ellipse(x, y - 12, 19, 12, 0, Math.PI, 0); c.fill(); }
      if (i < 4) { c.strokeStyle = 'rgba(160,0,0,0.85)'; c.lineWidth = 4; c.beginPath(); c.arc(x, y, 26, 0, Math.PI * 2); c.stroke(); }
    }
    txt(c, 'پرسنل پترو ۲۴ — ۱۴۰۱', w / 2, h - 34, 20, '#333', 'bold');
  }),
  logbookCover: () => T('logcover', 512, 368, (c, w, h) => {
    const g = c.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#4a2014'); g.addColorStop(1, '#2a0e08'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    for (let i = 0; i < 4000; i++) { c.fillStyle = `rgba(0,0,0,${rnd() * 0.25})`; c.fillRect(rnd() * w, rnd() * h, 2, 2); }
    c.strokeStyle = '#b8902a'; c.lineWidth = 4; c.strokeRect(24, 24, w - 48, h - 48);
    txt(c, 'دفتر مدیریت', w / 2, h * 0.42, 46, '#d8b04a', '900'); txt(c, '۱۳۶۶ — ', w / 2, h * 0.6, 28, '#b8902a', 'bold');
    c.fillStyle = 'rgba(120,0,0,0.6)'; for (let i = 0; i < 3; i++) { c.beginPath(); c.arc(w * 0.75 + rnd() * 40, h * 0.75, 6 + rnd() * 10, 0, Math.PI * 2); c.fill(); }
  }),
  contract: () => T('contract', 512, 700, (c, w, h) => {
    paper(c, w, h, '#f3eedd', false, 0.35);
    c.fillStyle = '#0d3a6a'; c.fillRect(30, 30, w - 60, 6);
    txt(c, 'قرارداد استخدام دائم', w / 2, 80, 34, '#111', '900'); txt(c, 'شیفت شب — پمپ بنزین پترو ۲۴', w / 2, 122, 20, '#333', 'bold');
    const body = ['ماده ۱: امضاکننده می‌پذیرد که از امشب', 'تا ابد، شیفت شب را بر عهده بگیرد.', 'ماده ۲: کارمند هرگز گرسنه، خسته', 'یا تنها نخواهد بود.', 'ماده ۳: فسخ قرارداد ممکن نیست.'];
    body.forEach((s, i) => txt(c, s, w - 50, 190 + i * 42, 20, '#222', 'normal', 'right'));
    txt(c, 'کارکنان دائم:', w - 50, 420, 20, '#111', '900', 'right');
    ['حسین یزدانی', 'محمد رضایی', 'سارا کریمی', 'علی نوروزی'].forEach((n, i) => { txt(c, n, w - 70 - (i % 2) * 210, 465 + Math.floor(i / 2) * 50, 20, '#333', 'bold', 'right'); c.strokeStyle = 'rgba(20,20,80,0.7)'; c.lineWidth = 2; c.beginPath(); c.moveTo(w - 230 - (i % 2) * 210, 482 + Math.floor(i / 2) * 50); c.bezierCurveTo(w - 200 - (i % 2) * 210, 460 + Math.floor(i / 2) * 50, w - 170 - (i % 2) * 210, 495 + Math.floor(i / 2) * 50, w - 150 - (i % 2) * 210, 475 + Math.floor(i / 2) * 50); c.stroke(); });
    txt(c, 'کارمند جدید شیفت شب — امشب', w - 50, 600, 22, '#a00', '900', 'right');
    c.strokeStyle = '#555'; c.setLineDash([6, 4]); c.beginPath(); c.moveTo(60, 640); c.lineTo(280, 640); c.stroke(); c.setLineDash([]);
    txt(c, 'محل امضا', 170, 660, 15, '#666', 'normal');
    stamp(c, 120, 470, 64, 'محرمانه');
    for (let i = 0; i < 4; i++) { c.fillStyle = 'rgba(110,0,0,0.75)'; c.beginPath(); c.arc(330 + rnd() * 100, 650 + rnd() * 30, 3 + rnd() * 6, 0, Math.PI * 2); c.fill(); }
  }),
  crumpled: () => T('crumpled', 400, 512, (c, w, h) => {
    paper(c, w, h, '#ece6d2', true, 0.5);
    for (let i = 0; i < 24; i++) { const x = rnd() * w, y = rnd() * h; c.strokeStyle = 'rgba(0,0,0,0.12)'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(x, y); c.lineTo(x + (rnd() - 0.5) * 220, y + (rnd() - 0.5) * 220); c.stroke(); c.strokeStyle = 'rgba(255,255,255,0.3)'; c.beginPath(); c.moveTo(x + 2, y + 1); c.lineTo(x + 2 + (rnd() - 0.5) * 200, y + (rnd() - 0.5) * 200); c.stroke(); }
    hand(c, ['شب نهم.', 'اونا از زیر دفتر مدیر میان.', 'صدای نفسش از لوله‌ها میاد.', 'مرد بلند... هر شب کنار جاده‌ست.', 'از بی‌چهره سؤال نپرس.', '                   — م. رضایی'], w - 34, 80, 56, 21, '#262626', w - 60);
    stain(c, 90, 430, 50);
  }),
  envelope: () => T('envelope', 512, 320, (c, w, h) => {
    c.fillStyle = '#f2ead8'; c.fillRect(0, 0, w, h);
    c.strokeStyle = 'rgba(0,0,0,0.12)'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, 0); c.lineTo(w / 2, h * 0.55); c.lineTo(w, 0); c.stroke();
    c.fillStyle = '#0d3a6a'; c.fillRect(24, 24, 120, 40); txt(c, 'PETRO 24', 84, 44, 20, '#fff', '900');
    txt(c, 'به: کارمند جدید شیفت شب', w - 40, h * 0.66, 24, '#222', 'bold', 'right');
    txt(c, 'فوری — قبل از ساعت ۳ باز شود', w - 40, h * 0.82, 18, '#a00', 'bold', 'right');
    c.fillStyle = '#8a1a1a'; c.beginPath(); c.arc(w / 2, h * 0.55, 22, 0, Math.PI * 2); c.fill(); txt(c, 'P', w / 2, h * 0.55, 22, '#d8a0a0', '900');
  }),
  /** bilingual plastic door plate */
  plate: (fa: string, en: string, kind: 'staff' | 'wc' | 'manager' | 'exit') => T('plate' + kind, 512, 160, (c, w, h) => {
    const bg = kind === 'staff' ? '#b0101a' : kind === 'wc' ? '#1f4f9a' : kind === 'exit' ? '#0a6a2a' : '#2a2a2c';
    c.fillStyle = '#d8dcde'; rrect(c, 0, 0, w, h, 18); c.fill();
    c.fillStyle = bg; rrect(c, 8, 8, w - 16, h - 16, 14); c.fill();
    const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgba(255,255,255,0.22)'); g.addColorStop(0.5, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    // icon block
    c.fillStyle = '#ffffff'; rrect(c, 22, 22, 116, 116, 10); c.fill();
    c.fillStyle = bg;
    if (kind === 'wc') { [56, 104].forEach((x, i) => { c.beginPath(); c.arc(x, 48, 10, 0, Math.PI * 2); c.fill(); if (i) { c.beginPath(); c.moveTo(x - 16, 110); c.lineTo(x, 62); c.lineTo(x + 16, 110); c.fill(); } else c.fillRect(x - 10, 62, 20, 50); }); c.fillRect(79, 36, 2, 90); }
    else if (kind === 'staff') { c.beginPath(); c.arc(80, 58, 18, 0, Math.PI * 2); c.fill(); c.beginPath(); c.ellipse(80, 118, 34, 28, 0, Math.PI, 0); c.fill(); c.strokeStyle = bg; c.lineWidth = 8; c.beginPath(); c.arc(80, 80, 50, 0, Math.PI * 2); c.moveTo(45, 45); c.lineTo(115, 115); c.stroke(); }
    else if (kind === 'exit') { c.beginPath(); c.arc(70, 46, 10, 0, Math.PI * 2); c.fill(); c.lineWidth = 9; c.strokeStyle = bg; c.lineCap = 'round'; c.beginPath(); c.moveTo(68, 62); c.lineTo(62, 92); c.lineTo(46, 118); c.moveTo(62, 92); c.lineTo(82, 116); c.moveTo(66, 70); c.lineTo(90, 80); c.stroke(); c.fillRect(100, 40, 22, 80); }
    else { c.fillRect(48, 40, 64, 80); c.fillStyle = '#fff'; c.fillRect(56, 50, 48, 6); c.fillRect(56, 64, 48, 6); c.fillRect(56, 78, 30, 6); }
    txt(c, fa, (w + 150) / 2, h * 0.4, 44, '#ffffff', '900');
    txt(c, en, (w + 150) / 2, h * 0.75, 24, 'rgba(255,255,255,0.85)', 'bold');
    for (const [x, y] of [[20, 20], [w - 20, 20], [20, h - 20], [w - 20, h - 20]]) { c.fillStyle = '#9aa0a4'; c.beginPath(); c.arc(x, y, 6, 0, Math.PI * 2); c.fill(); }
  }),
  coffeePanel: () => T('coffeepanel', 512, 200, (c, w, h) => {
    const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#3a1e10'); g.addColorStop(1, '#1a0c06'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    c.strokeStyle = '#c8902a'; c.lineWidth = 4; c.strokeRect(10, 10, w - 20, h - 20);
    // cup icon + steam
    c.fillStyle = '#f4e6cc'; c.beginPath(); c.moveTo(48, 80); c.lineTo(128, 80); c.lineTo(118, 150); c.lineTo(58, 150); c.closePath(); c.fill();
    c.strokeStyle = '#f4e6cc'; c.lineWidth = 7; c.beginPath(); c.arc(132, 108, 16, -1.3, 1.3); c.stroke();
    c.lineWidth = 4; for (let i = 0; i < 3; i++) { c.beginPath(); c.moveTo(66 + i * 22, 70); c.bezierCurveTo(56 + i * 22, 55, 80 + i * 22, 45, 68 + i * 22, 28); c.stroke(); }
    c.save(); c.shadowColor = '#ffb050'; c.shadowBlur = 18;
    txt(c, 'COFFEE', 330, 86, 74, '#ffe2a8', '900'); c.restore();
    txt(c, 'قهوه داغ  •  اسپرسو  •  کاپوچینو', 330, 152, 24, '#e8c48a', 'bold');
  }),
  coffeeButtons: () => T('coffeebtn', 256, 128, (c, w, h) => {
    c.fillStyle = '#111'; c.fillRect(0, 0, w, h);
    ['اسپرسو', 'لاته', 'کاپوچینو', 'آب داغ'].forEach((s, i) => {
      const x = 18 + (i % 2) * 122, y = 14 + Math.floor(i / 2) * 58;
      c.fillStyle = '#2a2a2a'; rrect(c, x, y, 106, 46, 8); c.fill(); c.strokeStyle = i === 0 ? '#ffb050' : '#555'; c.lineWidth = 2; rrect(c, x, y, 106, 46, 8); c.stroke();
      txt(c, s, x + 53, y + 24, 18, i === 0 ? '#ffd090' : '#ddd', 'bold');
    });
  }),
  iceHeader: () => T('icehdr', 512, 128, (c, w, h) => {
    const g = c.createLinearGradient(0, 0, w, 0); g.addColorStop(0, '#2a8cff'); g.addColorStop(0.5, '#59c8ff'); g.addColorStop(1, '#2a8cff'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    for (let i = 0; i < 40; i++) { c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.arc(rnd() * w, rnd() * h, 2 + rnd() * 3, 0, Math.PI * 2); c.fill(); }
    txt(c, 'ICE CREAM', w * 0.62, h * 0.4, 50, '#ffffff', '900'); txt(c, 'بستنی  •  خنک و خوشمزه', w * 0.62, h * 0.78, 24, '#ffffff', 'bold');
    c.fillStyle = '#e8b07a'; c.beginPath(); c.moveTo(60, 60); c.lineTo(100, 60); c.lineTo(80, 120); c.closePath(); c.fill();
    c.fillStyle = '#ff8fb8'; c.beginPath(); c.arc(80, 48, 24, 0, Math.PI * 2); c.fill();
  }),
};
