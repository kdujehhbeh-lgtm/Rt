// Interior-aware fog: fog only accumulates along the part of the view ray that is OUTSIDE the
// current level's building box. Inside the store the air is perfectly clear; looking out through
// the windows you still see the fog outside. Implemented by patching three.js fog shader chunks.
import * as THREE from 'three';

/** minX, maxX, minZ, maxZ – plain object so every material shares the same reference */
export const FOG_BOX = { x: 1e5, y: 1e5 + 1, z: 1e5, w: 1e5 + 1 };
export function setFogBox(minX: number, maxX: number, minZ: number, maxZ: number) { FOG_BOX.x = minX; FOG_BOX.y = maxX; FOG_BOX.z = minZ; FOG_BOX.w = maxZ; }
export function clearFogBox() { setFogBox(1e5, 1e5 + 1, 1e5, 1e5 + 1); }

let installed = false;
export function installInteriorFog() {
  if (installed) return; installed = true;
  const C = THREE.ShaderChunk as unknown as Record<string, string>;
  C.fog_pars_vertex = `#ifdef USE_FOG
	varying float vFogDepth;
	varying vec3 vFogWorld;
#endif`;
  C.fog_vertex = `#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
	vFogWorld = ( mvPosition.xyz - viewMatrix[ 3 ].xyz ) * mat3( viewMatrix );
#endif`;
  C.fog_pars_fragment = `#ifdef USE_FOG
	uniform vec3 fogColor;
	uniform vec4 fogBox;
	varying float vFogDepth;
	varying vec3 vFogWorld;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`;
  C.fog_fragment = `#ifdef USE_FOG
	vec3 fRd = vFogWorld - cameraPosition;
	fRd = mix( fRd, vec3( 1e-4 ), vec3( lessThan( abs( fRd ), vec3( 1e-4 ) ) ) );
	vec3 fT0 = ( vec3( fogBox.x, -60.0, fogBox.z ) - cameraPosition ) / fRd;
	vec3 fT1 = ( vec3( fogBox.y, 6.0, fogBox.w ) - cameraPosition ) / fRd;
	vec3 fTn = min( fT0, fT1 );
	vec3 fTf = max( fT0, fT1 );
	float fIn = clamp( max( max( fTn.x, fTn.y ), fTn.z ), 0.0, 1.0 );
	float fOut = clamp( min( min( fTf.x, fTf.y ), fTf.z ), 0.0, 1.0 );
	float fogD = vFogDepth * ( 1.0 - max( 0.0, fOut - fIn ) );
	// realistic height fog: dense low ground mist, thinning with altitude (sky / roofs read through)
	float fH = clamp( ( vFogWorld.y + cameraPosition.y * 0.5 ) / 16.0, 0.0, 1.0 );
	fogD *= mix( 1.2, 0.45, fH );
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * fogD * fogD );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, fogD );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`;
  // register the shared uniform on every built-in shader (cloned by reference since it is a plain object)
  const lib = THREE.ShaderLib as unknown as Record<string, { uniforms: Record<string, THREE.IUniform> }>;
  for (const k in lib) lib[k].uniforms.fogBox = { value: FOG_BOX };
}
