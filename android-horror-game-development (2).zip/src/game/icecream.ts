// Realistic ice cream merchandiser: printed wrappers, chocolate-coated bars, fruit popsicles,
// soft-serve swirl cones, labelled tubs with flavour photos, frosted glass & cold light.
import * as THREE from 'three';
import { mat } from './textures';
import { docs } from './docs';
import type { PropsCtx } from './props';
import { gfx, hiCanvas, finishTex } from './gfx';

const FONT = 'Vazirmatn, Tahoma, Arial, sans-serif';
const cache = new Map<string, THREE.CanvasTexture>();
function T(key: string, w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) {
  const k = key + '@' + gfx.texScale;
  const hit = cache.get(k); if (hit) return hit;
  const { cv, c } = hiCanvas(w, h); draw(c);
  const t = finishTex(new THREE.CanvasTexture(cv)); cache.set(k, t); return t;
}
function txt(c: CanvasRenderingContext2D, s: string, x: number, y: number, size: number, col: string, rot = 0) {
  c.save(); c.translate(x, y); c.rotate(rot); c.font = `900 ${size}px ${FONT}`; c.fillStyle = col; c.textAlign = 'center'; c.textBaseline = 'middle';
  c.direction = /[\u0600-\u06FF]/.test(s) ? 'rtl' : 'ltr'; c.fillText(s, 0, 0); c.restore();
}
function shine(c: CanvasRenderingContext2D, w: number, h: number) {
  const g = c.createLinearGradient(0, 0, w, 0); g.addColorStop(0, 'rgba(0,0,0,0.25)'); g.addColorStop(0.25, 'rgba(255,255,255,0.45)'); g.addColorStop(0.4, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(0,0,0,0.3)');
  c.fillStyle = g; c.fillRect(0, 0, w, h);
}
interface Wrap { brand: string; sub: string; bg: string; bg2: string; fg: string; art: 'choc' | 'fruit' | 'cone' }
const WRAPS: Wrap[] = [
  { brand: 'شاه‌بستنی', sub: 'روکش شکلات', bg: '#2a120a', bg2: '#5a2e14', fg: '#e8c070', art: 'choc' },
  { brand: 'یخی', sub: 'آلبالو', bg: '#c4101e', bg2: '#ff4a5a', fg: '#ffffff', art: 'fruit' },
  { brand: 'یخی', sub: 'پرتقال', bg: '#ff7a10', bg2: '#ffb050', fg: '#ffffff', art: 'fruit' },
  { brand: 'کیم', sub: 'وانیل', bg: '#1d4fa8', bg2: '#4a8ae1', fg: '#ffffff', art: 'cone' },
  { brand: 'شاه‌بستنی', sub: 'بادام', bg: '#e8d8b0', bg2: '#c8a870', fg: '#5a2e14', art: 'choc' },
];
function wrapTex(w: Wrap) {
  return T('wrap' + w.brand + w.sub, 256, 128, (c) => {
    const g = c.createLinearGradient(0, 0, 256, 128); g.addColorStop(0, w.bg); g.addColorStop(1, w.bg2); c.fillStyle = g; c.fillRect(0, 0, 256, 128);
    // crimped ends
    for (const x of [0, 236]) { c.fillStyle = 'rgba(255,255,255,0.25)'; c.fillRect(x, 0, 20, 128); for (let y = 0; y < 128; y += 5) { c.fillStyle = 'rgba(0,0,0,0.2)'; c.fillRect(x, y, 20, 2); } }
    if (w.art === 'choc') { c.fillStyle = '#3a1a0a'; c.beginPath(); c.ellipse(150, 70, 60, 26, -0.2, 0, Math.PI * 2); c.fill(); c.fillStyle = '#f4ead0'; c.beginPath(); c.ellipse(196, 58, 12, 18, -0.2, 0, Math.PI * 2); c.fill(); c.fillStyle = 'rgba(255,255,255,0.3)'; c.fillRect(110, 54, 70, 4); }
    else if (w.art === 'fruit') { c.fillStyle = 'rgba(255,255,255,0.85)'; c.beginPath(); c.arc(70, 70, 22, 0, Math.PI * 2); c.fill(); c.fillStyle = w.bg; c.beginPath(); c.arc(70, 70, 17, 0, Math.PI * 2); c.fill(); c.fillStyle = '#2a8a2a'; c.fillRect(68, 42, 4, 12); }
    else { c.fillStyle = '#d8a060'; c.beginPath(); c.moveTo(170, 110); c.lineTo(150, 50); c.lineTo(190, 50); c.closePath(); c.fill(); c.fillStyle = '#fff8e0'; c.beginPath(); c.arc(170, 44, 20, 0, Math.PI * 2); c.fill(); }
    txt(c, w.brand, 120, 40, 30, w.fg, -0.05); txt(c, w.sub, 120, 92, 20, w.fg);
    shine(c, 256, 128);
  });
}
const FLAV = [
  { n: 'توت‌فرنگی', c: '#ff7fa8' }, { n: 'شکلات', c: '#5a2e14' }, { n: 'وانیل', c: '#fff3c8' }, { n: 'پسته', c: '#a8d878' }, { n: 'زعفرانی', c: '#ffc23a' }, { n: 'نعناع', c: '#9ae8d0' },
];
function tubLidTex(i: number) {
  const f = FLAV[i];
  return T('lid' + i, 128, 128, (c) => {
    c.fillStyle = '#ffffff'; c.beginPath(); c.arc(64, 64, 64, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#1d4fa8'; c.beginPath(); c.arc(64, 64, 60, 0, Math.PI * 2); c.fill();
    c.fillStyle = f.c; for (let k = 0; k < 3; k++) { c.beginPath(); c.arc(44 + k * 20, 62 - (k % 2) * 8, 18, 0, Math.PI * 2); c.fill(); }
    c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.arc(40, 52, 6, 0, Math.PI * 2); c.fill();
    txt(c, f.n, 64, 100, 15, '#ffffff'); txt(c, 'میهن', 64, 22, 14, '#ffd36a');
  });
}
function tubSideTex(i: number) {
  const f = FLAV[i];
  return T('tubside' + i, 256, 64, (c) => {
    c.fillStyle = '#ffffff'; c.fillRect(0, 0, 256, 64); c.fillStyle = f.c; c.fillRect(0, 34, 256, 30);
    c.fillStyle = '#1d4fa8'; c.fillRect(0, 0, 256, 8);
    txt(c, f.n, 64, 22, 16, '#1d4fa8'); txt(c, f.n, 192, 22, 16, '#1d4fa8'); txt(c, '۱ لیتر', 128, 50, 12, '#333');
  });
}
// swirl soft-serve: lathe with ridged profile
function swirlGeo() {
  const pts: THREE.Vector2[] = [];
  for (let i = 0; i <= 24; i++) { const t = i / 24; const r = 0.04 * (1 - t) * (0.85 + 0.15 * Math.cos(t * Math.PI * 8)) + 0.003; pts.push(new THREE.Vector2(r, t * 0.09)); }
  const g = new THREE.LatheGeometry(pts, 14); return g;
}
function waffleTex() {
  return T('waffle', 128, 128, (c) => {
    c.fillStyle = '#d8a060'; c.fillRect(0, 0, 128, 128); c.strokeStyle = '#a8703a'; c.lineWidth = 3;
    for (let i = -128; i < 256; i += 16) { c.beginPath(); c.moveTo(i, 0); c.lineTo(i + 128, 128); c.stroke(); c.beginPath(); c.moveTo(i + 128, 0); c.lineTo(i, 128); c.stroke(); }
  });
}

const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), pv = new THREE.Vector3(), sv = new THREE.Vector3();
function inst(parent: THREE.Object3D, geo: THREE.BufferGeometry, material: THREE.Material | THREE.Material[], list: [number, number, number, number?, number?, number?][]) {
  if (!list.length) return;
  const im = new THREE.InstancedMesh(geo, material, list.length);
  list.forEach(([x, y, z, ry = 0, rx = 0, rz = 0], i) => { q.setFromEuler(e.set(rx, ry, rz)); m4.compose(pv.set(x, y, z), q, sv.set(1, 1, 1)); im.setMatrixAt(i, m4); });
  im.instanceMatrix.needsUpdate = true; im.frustumCulled = false; parent.add(im);
}

export function iceCreamFreezer(ctx: PropsCtx, x: number, z: number, rotY = 0) {
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rotY; ctx.parent.add(g);
  const white = mat({ color: 0xf2f2f2, rough: 0.3, key: 'frzw' });
  const box = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.85, 0.75), white); box.position.y = 0.425; g.add(box);
  const label = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.3), new THREE.MeshStandardMaterial({ map: docs.iceHeader(), roughness: 0.4 })); label.position.set(0, 0.5, 0.377); g.add(label);
  const inside = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.65), new THREE.MeshStandardMaterial({ color: 0xdff0ff, emissive: 0xa0c8ff, emissiveIntensity: 0.55 }));
  inside.rotation.x = -Math.PI / 2; inside.position.y = 0.852; g.add(inside); ctx.reg(inside.material as THREE.Material);
  // tubs with printed lids / sides, piled in two layers
  const tubGeo = new THREE.CylinderGeometry(0.062, 0.056, 0.085, 16);
  const byFlav: [number, number, number][][] = FLAV.map(() => []);
  for (let i = 0; i < 10; i++) for (let j = 0; j < 4; j++) {
    const fi = (i + j * 2) % FLAV.length; const y = j === 0 || j === 3 ? 0.9 : 0.985;
    byFlav[fi].push([-0.62 + i * 0.137, y, -0.24 + j * 0.16]);
    if (j === 1 || j === 2) byFlav[(fi + 3) % FLAV.length].push([-0.62 + i * 0.137, y - 0.087, -0.24 + j * 0.16]);
  }
  byFlav.forEach((list, fi) => {
    const side = new THREE.MeshStandardMaterial({ map: tubSideTex(fi), roughness: 0.4 });
    const lid = new THREE.MeshStandardMaterial({ map: tubLidTex(fi), roughness: 0.3 });
    inst(g, tubGeo, [side, lid, lid], list.map(([a, b, c]) => [a, b, c, Math.random() * 6] as [number, number, number, number]));
  });
  // frosted sliding lids
  const glass = new THREE.MeshStandardMaterial({ color: 0xd8ecf8, transparent: true, opacity: 0.22, roughness: 0.15, metalness: 0.3, depthWrite: false });
  for (const s of [-0.37, 0.37]) { const l = new THREE.Mesh(new THREE.PlaneGeometry(0.76, 0.73), glass); l.rotation.x = -Math.PI / 2; l.position.set(s, 1.07 + (s > 0 ? 0.01 : 0), 0); g.add(l); }
  for (const sx of [-0.75, 0.75]) { const f = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.22, 0.75), white); f.position.set(sx, 0.96, 0); g.add(f); }
  // upright merchandiser (eye level) with lit header
  const rackM = mat({ color: 0xeef2f5, metal: 0.3, rough: 0.35, key: 'icerack' });
  const board = new THREE.Mesh(new THREE.BoxGeometry(1.46, 0.95, 0.06), rackM); board.position.set(0, 1.55, -0.36); g.add(board);
  const backLight = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.9), new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xe8f4ff, emissiveIntensity: 0.6 }));
  backLight.position.set(0, 1.55, -0.325); g.add(backLight); ctx.reg(backLight.material as THREE.Material);
  for (const sx of [-0.71, 0.71]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.04, 1.2, 0.08), rackM); p.position.set(sx, 1.45, -0.34); g.add(p); }
  const hdrM = new THREE.MeshStandardMaterial({ map: docs.iceHeader(), emissive: 0xffffff, emissiveMap: docs.iceHeader(), emissiveIntensity: 0.75 });
  ctx.reg(hdrM);
  const hdr = new THREE.Mesh(new THREE.PlaneGeometry(1.46, 0.34), hdrM); hdr.position.set(0, 2.2, -0.32); g.add(hdr);
  for (const sy of [1.25, 1.55, 1.85]) { const sh = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.015, 0.16), rackM); sh.position.set(0, sy - 0.11, -0.26); g.add(sh); }
  // row 1 (top): wrapped bars standing in display (printed wrappers)
  const barGeo = new THREE.BoxGeometry(0.075, 0.17, 0.028);
  WRAPS.forEach((w, wi) => {
    const m = new THREE.MeshStandardMaterial({ map: wrapTex(w), roughness: 0.25, metalness: 0.35 });
    const list: [number, number, number, number, number, number][] = [];
    for (let k = 0; k < 3; k++) list.push([-0.62 + (wi * 3 + k) * 0.087, 1.83, -0.27 + k * 0.012, 0, 0, Math.PI / 2 * 0 + (Math.random() - 0.5) * 0.06]);
    inst(g, barGeo, [m, m, m, m, m, m], list.map((l) => { const r = [...l] as [number, number, number, number, number, number]; return r; }));
  });
  // row 2: unwrapped chocolate-coated bars & fruit popsicles on sticks (display samples)
  const chocBar = new THREE.CapsuleGeometry(0.028, 0.08, 4, 10).scale(1, 1, 0.55);
  const chocM = new THREE.MeshStandardMaterial({ color: 0x3a1a0a, roughness: 0.25, metalness: 0.05 });
  const fruitM = [0xd4141e, 0xff8a1a, 0x7ad04a].map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.15, transparent: true, opacity: 0.92 }));
  const stickGeo = new THREE.BoxGeometry(0.014, 0.07, 0.004); const stickM = mat({ color: 0xe0c08a, rough: 0.8, key: 'popstick' });
  const chocs: [number, number, number, number?, number?, number?][] = []; const fruits: [number, number, number, number?, number?, number?][][] = [[], [], []]; const sticks: [number, number, number, number?, number?, number?][] = [];
  for (let i = 0; i < 14; i++) {
    const px = -0.62 + i * 0.095, py = 1.55;
    if (i % 3 === 0) fruits[(i / 3) % 3].push([px, py, -0.26]); else chocs.push([px, py, -0.26]);
    sticks.push([px, py - 0.085, -0.26]);
  }
  inst(g, chocBar, chocM, chocs); fruits.forEach((l, k) => inst(g, chocBar, fruitM[k], l)); inst(g, stickGeo, stickM, sticks);
  // nut sprinkles on some choc bars
  const nutM = mat({ color: 0xe8c890, rough: 0.7, key: 'nuts' }); const nuts: [number, number, number][] = [];
  chocs.forEach(([px, py], i) => { if (i % 2) for (let k = 0; k < 10; k++) nuts.push([px + (Math.random() - 0.5) * 0.045, py + (Math.random() - 0.3) * 0.08, -0.246]); });
  inst(g, new THREE.SphereGeometry(0.005, 4, 3), nutM, nuts);
  // row 3: soft-serve cones in a holder
  const coneGeo = new THREE.ConeGeometry(0.035, 0.13, 14, 1, true).rotateX(Math.PI);
  const coneM = new THREE.MeshStandardMaterial({ map: waffleTex(), roughness: 0.85, side: THREE.DoubleSide });
  const swirl = swirlGeo();
  const swirlM = [0xfff6e0, 0xff9fc0, 0x6a3a1a].map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.55 }));
  const cones: [number, number, number][] = []; const sw: [number, number, number][][] = [[], [], []];
  for (let i = 0; i < 10; i++) { const px = -0.6 + i * 0.133; cones.push([px, 1.27, -0.26]); sw[i % 3].push([px, 1.335, -0.26]); }
  inst(g, coneGeo, coneM, cones); sw.forEach((l, k) => inst(g, swirl, swirlM[k], l));
  const holder = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.04, 0.12), rackM); holder.position.set(0, 1.25, -0.26); g.add(holder);
  // cold light & frost
  const shield = new THREE.Mesh(new THREE.PlaneGeometry(1.42, 0.9), new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.08, roughness: 0.05, depthWrite: false }));
  shield.position.set(0, 1.55, -0.17); g.add(shield);
  return g;
}
