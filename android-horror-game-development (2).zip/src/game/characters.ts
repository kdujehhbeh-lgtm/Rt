// Natural-looking humanoids for mobile: anatomical proportions, jointed limbs (elbows/knees),
// painted faces (eyes, brows, lips, stubble, wrinkles), fabric textures, hairstyles and natural motion.
import * as THREE from 'three';
import { mat } from './textures';
import { withPhoto } from './posters';
import { gfx, hiCanvas, finishTex } from './gfx';

// ---------------- photographic faces ----------------
/** normalized landmarks of each portrait: face centre x, eye line y, chin y */
const PHOTO_FACE: Record<string, { cx: number; eye: number; chin: number }> = {
  man: { cx: 0.52, eye: 0.34, chin: 0.575 },
  old: { cx: 0.53, eye: 0.42, chin: 0.68 },
  woman: { cx: 0.5, eye: 0.39, chin: 0.62 },
  youth: { cx: 0.5, eye: 0.38, chin: 0.61 },
};
// ---------------- sculpted facial relief ----------------
interface FaceLM { eyeY: number; eyeX: number; noseY: number; mouthY: number }
const LM_PAINTED: FaceLM = { eyeY: 0.147, eyeX: 0.275, noseY: -0.22, mouthY: -0.47 };
const LM_PHOTO: FaceLM = { eyeY: 0.19, eyeX: 0.3, noseY: -0.3, mouthY: -0.55 };
const gauss = (x: number, s: number) => Math.exp(-(x * x) / (2 * s * s));
/** push vertices of a head-sized sphere outward/inward to sculpt nose, brow, sockets, cheeks, lips & chin */
function sculpt(geo: THREE.BufferGeometry, R: number, L: FaceLM) {
  const p = geo.attributes.position as THREE.BufferAttribute; const v = new THREE.Vector3(); const n = new THREE.Vector3();
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i);
    // skull: longer occiput, narrower temples, flatter crown sides
    if (v.z <= 0) { v.z *= v.y < -0.45 * R ? 0.95 : 1.13; v.x *= 0.95; if (v.y > 0.55 * R) v.x *= 0.97; p.setXYZ(i, v.x, v.y, v.z); continue; }
    v.x *= Math.abs(v.y) < 0.35 * R ? 0.97 : 0.95;
    const X = v.x / R, Y = v.y / R, w = Math.min(1, (v.z / R) * 1.8);
    let d = 0;
    const top = L.eyeY + 0.03;
    const ridge = Y > L.noseY ? Math.pow(Math.min(1, Math.max(0, (top - Y) / (top - L.noseY))), 1.5) : gauss(Y - L.noseY, 0.06);
    d += 0.3 * ridge * gauss(X, 0.07 + 0.03 * ridge);
    d += 0.09 * gauss(X, 0.15) * gauss(Y - (L.noseY + 0.02), 0.05);
    for (const s of [-1, 1]) {
      d -= 0.12 * gauss(X - s * L.eyeX, 0.1) * gauss(Y - L.eyeY, 0.075);
      d += 0.05 * gauss(X - s * L.eyeX, 0.05) * gauss(Y - L.eyeY, 0.04);
      d += 0.06 * gauss(X - s * 0.43, 0.12) * gauss(Y - (L.eyeY - 0.24), 0.1);
    }
    d += 0.075 * gauss(Y - (L.eyeY + 0.15), 0.05) * gauss(X, 0.42);
    d += 0.08 * gauss(X, 0.16) * gauss(Y - L.mouthY, 0.055);
    d -= 0.035 * gauss(X, 0.13) * gauss(Y - L.mouthY, 0.012);
    d += 0.075 * gauss(X, 0.19) * gauss(Y - (L.mouthY - 0.28), 0.09);
    d -= 0.05 * gauss(Math.abs(X) - 0.62, 0.12) * gauss(Y - (L.mouthY + 0.12), 0.15); // hollow cheeks
    n.copy(v).normalize(); v.addScaledVector(n, d * R * w); p.setXYZ(i, v.x, v.y, v.z);
  }
  geo.computeVertexNormals();
  return geo;
}
const headPainted = sculpt(new THREE.SphereGeometry(0.105, 40, 30), 0.105, LM_PAINTED);
const headPhoto = sculpt(new THREE.SphereGeometry(0.105, 40, 30), 0.105, LM_PHOTO);
let faceShellGeo: THREE.BufferGeometry | null = null;
/** front cap of the head sphere with planar UVs (photo projected from the front), sculpted like the head */
function getFaceShell() {
  if (faceShellGeo) return faceShellGeo;
  const R = 0.1064;
  const g = new THREE.SphereGeometry(R, 40, 30, Math.PI / 2 - 1.25, 2.5, 0.32, Math.PI - 0.6);
  const p = g.attributes.position as THREE.BufferAttribute; const uv = g.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) uv.setXY(i, 0.5 + p.getX(i) / (2 * R), 0.5 + p.getY(i) / (2 * R));
  uv.needsUpdate = true;
  faceShellGeo = sculpt(g, R, LM_PHOTO); return faceShellGeo;
}
const photoTexCache = new Map<string, THREE.CanvasTexture>();
const skinSampled = new Set<string>();
/** feathered face texture from a portrait; also tints the character's skin material to match the photo */
function photoFaceTexture(name: string, skin: THREE.Material) {
  let t = photoTexCache.get(name);
  const cv = t ? (t.image as HTMLCanvasElement) : document.createElement('canvas');
  if (!t) { cv.width = cv.height = 1024; t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; photoTexCache.set(name, t); }
  const tex = t;
  withPhoto(name, (im) => {
    const L = PHOTO_FACE[name]; const W = im.naturalWidth, H = im.naturalHeight;
    const c = cv.getContext('2d', { willReadFrequently: true })!;
    c.setTransform(2, 0, 0, 2, 0, 0); c.imageSmoothingQuality = 'high'; // 1024² texture, layout kept in 512 units
    // canvas landmarks: eyes at y=207, chin at y=487 (matches head geometry)
    const s = 280 / ((L.chin - L.eye) * H);
    c.clearRect(0, 0, 512, 512);
    c.drawImage(im, 256 - L.cx * W * s, 207 - L.eye * H * s, W * s, H * s);
    // sample cheek colour → skin tone for neck/hands/ears
    if (!skinSampled.has(name + (skin as THREE.MeshStandardMaterial).uuid)) {
      skinSampled.add(name + (skin as THREE.MeshStandardMaterial).uuid);
      try {
        let r = 0, gg = 0, b = 0, n = 0;
        for (const sx of [-1, 1]) { const d = c.getImageData((256 + sx * 70 - 12) * 2, 300 * 2, 48, 48).data; for (let i = 0; i < d.length; i += 4) { r += d[i]; gg += d[i + 1]; b += d[i + 2]; n++; } }
        const col = new THREE.Color().setRGB(r / n / 255, gg / n / 255, b / n / 255, THREE.SRGBColorSpace);
        const m = skin as THREE.MeshStandardMaterial; if (m.color) m.color.copy(col);
      } catch { /* ignore */ }
    }
    // feather to transparent around the face oval
    // subtle soft-light grade: lift shadows, add warmth (photos read less flat under game lighting)
    c.globalCompositeOperation = 'soft-light'; c.fillStyle = 'rgba(255,214,190,0.35)'; c.fillRect(0, 0, 512, 512);
    // anatomical face mask (wide cheekbones, tapered jaw, forehead to hairline), heavily feathered
    c.globalCompositeOperation = 'destination-in';
    c.save();
    try { c.filter = 'blur(16px)'; } catch { /* unsupported */ }
    c.beginPath();
    c.moveTo(256, 92);
    c.bezierCurveTo(372, 92, 410, 190, 398, 290);
    c.bezierCurveTo(388, 390, 330, 478, 256, 492);
    c.bezierCurveTo(182, 478, 124, 390, 114, 290);
    c.bezierCurveTo(102, 190, 140, 92, 256, 92);
    c.fillStyle = '#000'; c.fill();
    c.restore();
    c.globalCompositeOperation = 'source-over';
    try { c.filter = 'none'; } catch { /* */ }
    tex.needsUpdate = true;
  });
  return tex;
}

export type Top = 'tshirt' | 'shirt' | 'flannel' | 'hoodie' | 'jacket' | 'knit' | 'suit';
export interface HumanStyle {
  skin: number; shirt: number; pants: number; shoes?: number; hair?: number;
  hairStyle?: 'short' | 'long' | 'bald' | 'cap' | 'hood' | 'grey' | 'scarf' | 'curly';
  cap?: number; height?: number; build?: number; belly?: boolean; vest?: number; coat?: boolean;
  faceless?: boolean; eyes?: 'normal' | 'void' | 'glow' | 'none'; hunch?: number;
  female?: boolean; beard?: 'none' | 'stubble' | 'full' | 'mustache'; age?: number; eyeColor?: string;
  top?: Top; bottom?: 'jeans' | 'pants'; sleeves?: 'short' | 'long'; glasses?: boolean; scarf?: number;
  photo?: 'man' | 'woman' | 'youth' | 'old';
}
export type ShiftVariant = 'stretch' | 'maw' | 'crawler';

// ---------------- procedural textures ----------------
const texCache = new Map<string, THREE.CanvasTexture>();
let seed = 1;
const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
const hex = (n: number) => '#' + n.toString(16).padStart(6, '0');
function shade(n: number, f: number) { const c = new THREE.Color(n); c.multiplyScalar(f); return '#' + c.getHexString(); }
function canvasTex(key: string, w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) {
  const k = key + '@' + gfx.texScale;
  const hit = texCache.get(k); if (hit) return hit;
  const { cv, c } = hiCanvas(w, h);
  seed = 1; for (let i = 0; i < key.length; i++) seed = (seed * 31 + key.charCodeAt(i)) % 2147483647; seed ||= 3;
  draw(c);
  const t = finishTex(new THREE.CanvasTexture(cv));
  texCache.set(k, t); return t;
}

/** face painted on an equirect sphere map: face centred at u=0.25 (x=128 of 512) */
function faceTexture(s: HumanStyle) {
  const key = ['face', s.skin, s.female, s.beard, s.age, s.eyes, s.eyeColor, s.hair].join('|');
  return canvasTex(key, 512, 256, (c) => {
    const W = 512, H = 256, cx = 128;
    const skin = new THREE.Color(s.skin);
    c.fillStyle = hex(s.skin); c.fillRect(0, 0, W, H);
    // pores / tone variation
    for (let i = 0; i < 9000; i++) { c.fillStyle = rnd() < 0.5 ? 'rgba(90,40,30,0.05)' : 'rgba(255,230,210,0.05)'; c.fillRect(rnd() * W, rnd() * H, 1.5, 1.5); }
    // cheeks warmth, under-chin shadow
    for (const sx of [-1, 1]) { const g = c.createRadialGradient(cx + sx * 34, 150, 2, cx + sx * 34, 150, 28); g.addColorStop(0, `rgba(200,80,70,${s.female ? 0.22 : 0.13})`); g.addColorStop(1, 'rgba(200,80,70,0)'); c.fillStyle = g; c.fillRect(0, 0, W, H); }
    const gch = c.createLinearGradient(0, 190, 0, 256); gch.addColorStop(0, 'rgba(0,0,0,0)'); gch.addColorStop(1, 'rgba(40,20,10,0.35)'); c.fillStyle = gch; c.fillRect(0, 0, W, H);
    const age = s.age ?? 30;
    const dark = (a: number) => `rgba(${Math.floor(skin.r * 90)},${Math.floor(skin.g * 55)},${Math.floor(skin.b * 45)},${a})`;
    // beard / stubble zone
    const beardCol = s.hair ?? 0x1b1410;
    if (s.beard === 'stubble' || s.beard === 'full') {
      const a = s.beard === 'full' ? 0.85 : 0.22;
      for (let i = 0; i < (s.beard === 'full' ? 9000 : 4500); i++) {
        const x = cx + (rnd() - 0.5) * 120, y = 140 + rnd() * 116;
        const dx = (x - cx) / 60, dy = (y - 205) / 70;
        if (dx * dx + dy * dy > 1.25 || (y < 160 && Math.abs(x - cx) < 22) || (Math.abs(y - 168) < 6 && Math.abs(x - cx) < 15)) continue;
        c.fillStyle = shade(beardCol, 0.8 + rnd() * 0.4); c.globalAlpha = a * (0.5 + rnd() * 0.5); c.fillRect(x, y, 1.3, 2.2);
      }
      c.globalAlpha = 1;
    }
    if (s.beard === 'mustache' || s.beard === 'full') {
      c.fillStyle = shade(beardCol, 1); c.globalAlpha = 0.85;
      c.beginPath(); c.moveTo(cx - 20, 166); c.quadraticCurveTo(cx, 152, cx + 20, 166); c.quadraticCurveTo(cx, 160, cx - 20, 166); c.fill();
      c.globalAlpha = 1;
    }
    if (s.eyes === 'none') return;
    const ey = 116;
    // eye sockets
    for (const sx of [-1, 1]) { const g = c.createRadialGradient(cx + sx * 23, ey, 2, cx + sx * 23, ey, 18); g.addColorStop(0, dark(0.35)); g.addColorStop(1, dark(0)); c.fillStyle = g; c.fillRect(0, 0, W, H); }
    for (const sx of [-1, 1]) {
      const x = cx + sx * 23;
      if (s.eyes === 'void') { c.fillStyle = '#000'; c.beginPath(); c.ellipse(x, ey, 10, 7, 0, 0, Math.PI * 2); c.fill(); continue; }
      c.fillStyle = '#ece6dc'; c.beginPath(); c.ellipse(x, ey, 9.5, 4.6, 0, 0, Math.PI * 2); c.fill();
      const ic = s.eyeColor ?? '#3a2412';
      const gi = c.createRadialGradient(x, ey, 0.5, x, ey, 4.4); gi.addColorStop(0, '#000'); gi.addColorStop(0.35, ic); gi.addColorStop(1, shade(parseInt(ic.slice(1), 16), 0.55));
      c.fillStyle = gi; c.beginPath(); c.arc(x + sx * -0.5, ey, 4.4, 0, Math.PI * 2); c.fill();
      c.fillStyle = 'rgba(255,255,255,0.85)'; c.fillRect(x - 2, ey - 2.5, 1.6, 1.6);
      // upper lid & lashes, lower lid
      c.strokeStyle = s.female ? '#120a06' : dark(0.9); c.lineWidth = s.female ? 2.2 : 1.6;
      c.beginPath(); c.ellipse(x, ey + 1, 10, 5.6, 0, Math.PI * 1.05, Math.PI * 1.95); c.stroke();
      c.strokeStyle = dark(0.35); c.lineWidth = 1; c.beginPath(); c.ellipse(x, ey - 0.5, 9, 4.8, 0, Math.PI * 0.1, Math.PI * 0.9); c.stroke();
      c.strokeStyle = dark(0.3); c.beginPath(); c.ellipse(x, ey - 2, 10, 6, 0, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); // crease
      if (age > 45) { c.strokeStyle = dark(0.3); c.lineWidth = 0.8; for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(x + sx * 11, ey + k * 2.5); c.lineTo(x + sx * 17, ey - 2 + k * 4); c.stroke(); } c.beginPath(); c.ellipse(x, ey + 7, 7, 2.5, 0, 0, Math.PI); c.stroke(); }
    }
    if (s.eyes === 'void') return;
    // eyebrows
    const browCol = s.age && s.age > 65 ? '#8a8a85' : shade(s.hair ?? 0x1b1410, 1.1);
    for (const sx of [-1, 1]) {
      c.fillStyle = browCol;
      for (let k = 0; k < 60; k++) {
        const t = rnd(); const x = cx + sx * (10 + t * 24);
        const y = ey - 13 - Math.sin(t * Math.PI * (s.female ? 0.95 : 0.7)) * (s.female ? 5 : 3) + (rnd() - 0.5) * (s.female ? 2 : 3.2);
        c.fillRect(x, y, 1.4, 1.6);
      }
    }
    // nose: bridge highlight, side shading, nostrils
    c.fillStyle = 'rgba(255,240,225,0.12)'; c.fillRect(cx - 2.5, ey, 5, 30);
    for (const sx of [-1, 1]) { const g = c.createLinearGradient(cx + sx * 3, 0, cx + sx * 10, 0); g.addColorStop(0, dark(0.25)); g.addColorStop(1, dark(0)); c.fillStyle = g; c.fillRect(Math.min(cx + sx * 3, cx + sx * 10), ey + 4, 7, 28); }
    for (const sx of [-1, 1]) { c.fillStyle = dark(0.75); c.beginPath(); c.ellipse(cx + sx * 5, 146, 3, 1.6, sx * 0.3, 0, Math.PI * 2); c.fill(); }
    // nasolabial folds
    if (age > 35) { c.strokeStyle = dark(age > 60 ? 0.4 : 0.22); c.lineWidth = 1.2; for (const sx of [-1, 1]) { c.beginPath(); c.moveTo(cx + sx * 10, 144); c.quadraticCurveTo(cx + sx * 20, 158, cx + sx * 18, 172); c.stroke(); } }
    // lips
    const lip = s.female ? '#a8444a' : shade(s.skin, 0.72);
    c.fillStyle = lip;
    c.beginPath(); c.moveTo(cx - 15, 168); c.quadraticCurveTo(cx - 7, 161, cx, 164); c.quadraticCurveTo(cx + 7, 161, cx + 15, 168); c.quadraticCurveTo(cx, 170, cx - 15, 168); c.fill();
    c.fillStyle = s.female ? '#b85258' : shade(s.skin, 0.8);
    c.beginPath(); c.moveTo(cx - 14, 168.5); c.quadraticCurveTo(cx, 179, cx + 14, 168.5); c.quadraticCurveTo(cx, 171, cx - 14, 168.5); c.fill();
    c.strokeStyle = dark(0.8); c.lineWidth = 1.2; c.beginPath(); c.moveTo(cx - 15, 168); c.quadraticCurveTo(cx, 170.5, cx + 15, 168); c.stroke();
    c.fillStyle = 'rgba(255,255,255,0.18)'; c.fillRect(cx - 5, 172, 10, 1.5);
    // forehead lines
    if (age > 50) { c.strokeStyle = dark(0.22); c.lineWidth = 1; for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(cx - 28, 82 + k * 7); c.quadraticCurveTo(cx, 78 + k * 7, cx + 28, 82 + k * 7); c.stroke(); } }
  });
}
function hairTexture(col: number, curly = false) {
  return canvasTex('hair' + col + curly, 128, 128, (c) => {
    c.fillStyle = hex(col); c.fillRect(0, 0, 128, 128);
    for (let i = 0; i < 1400; i++) {
      const x = rnd() * 128, y = rnd() * 128; c.strokeStyle = rnd() < 0.5 ? shade(col, 1.6) : shade(col, 0.55); c.globalAlpha = 0.35; c.lineWidth = 1;
      c.beginPath(); c.moveTo(x, y);
      if (curly) c.arc(x, y, 2 + rnd() * 2, 0, Math.PI * 1.5); else c.lineTo(x + (rnd() - 0.5) * 3, y + 6 + rnd() * 8);
      c.stroke();
    }
    c.globalAlpha = 1;
  });
}
/** cloth texture for lathe torso (front at u=0.5) / limbs */
function clothTexture(col: number, kind: Top | 'jeans' | 'pants' | 'sleeve', vest?: number) {
  return canvasTex(['cloth', col, kind, vest].join('|'), 256, 256, (c) => {
    const W = 256, H = 256;
    c.fillStyle = hex(col); c.fillRect(0, 0, W, H);
    if (kind === 'jeans') {
      for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) { if (rnd() < 0.5) { c.fillStyle = `rgba(255,255,255,${rnd() * 0.08})`; c.fillRect(x + (y % 4), y, 2, 1); } }
      const g = c.createLinearGradient(0, 0, W, 0); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.5, 'rgba(255,255,255,0.12)'); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.strokeStyle = 'rgba(200,150,60,0.55)'; c.setLineDash([3, 2]); c.beginPath(); c.moveTo(W * 0.25, 0); c.lineTo(W * 0.25, H); c.moveTo(W * 0.75, 0); c.lineTo(W * 0.75, H); c.stroke(); c.setLineDash([]);
      return;
    }
    if (kind === 'flannel') {
      for (let i = 0; i < W; i += 32) { c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(i, 0, 10, H); c.fillRect(0, i, W, 10); c.fillStyle = 'rgba(255,255,255,0.12)'; c.fillRect(i + 18, 0, 3, H); c.fillRect(0, i + 18, W, 3); }
    } else if (kind === 'knit') {
      for (let y = 0; y < H; y += 6) for (let x = 0; x < W; x += 6) { c.fillStyle = `rgba(0,0,0,${0.08 + rnd() * 0.08})`; c.beginPath(); c.ellipse(x + 3, y + 3, 2, 3, 0.5, 0, Math.PI * 2); c.fill(); }
    } else {
      for (let i = 0; i < 6000; i++) { c.fillStyle = rnd() < 0.5 ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.05)'; c.fillRect(rnd() * W, rnd() * H, 2, 1); }
    }
    // folds
    for (let i = 0; i < 10; i++) { const x = rnd() * W; const g = c.createLinearGradient(x - 8, 0, x + 8, 0); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, 'rgba(0,0,0,0.13)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(x - 8, rnd() * H * 0.5, 16, H); }
    const fx = W / 2;
    if (kind === 'shirt' || kind === 'flannel' || kind === 'suit') {
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(fx - 1, 0, 2, H);
      for (let y = 30; y < H - 10; y += 34) { c.fillStyle = 'rgba(240,240,230,0.85)'; c.beginPath(); c.arc(fx + 5, H - y, 2.5, 0, Math.PI * 2); c.fill(); }
      c.fillStyle = 'rgba(0,0,0,0.3)'; c.beginPath(); c.moveTo(fx - 22, 0); c.lineTo(fx, 22); c.lineTo(fx + 22, 0); c.fill(); // collar shadow
      if (kind === 'suit') { c.fillStyle = 'rgba(225,225,215,1)'; c.beginPath(); c.moveTo(fx - 14, 0); c.lineTo(fx, 60); c.lineTo(fx + 14, 0); c.fill(); c.fillStyle = '#3a0606'; c.beginPath(); c.moveTo(fx - 4, 0); c.lineTo(fx - 5, 50); c.lineTo(fx, 62); c.lineTo(fx + 5, 50); c.lineTo(fx + 4, 0); c.fill(); }
      c.fillStyle = 'rgba(0,0,0,0.18)'; c.fillRect(fx + 26, 70, 30, 34); // pocket
    }
    if (kind === 'hoodie') {
      c.fillStyle = 'rgba(0,0,0,0.22)'; c.beginPath(); c.moveTo(fx - 45, H - 20); c.lineTo(fx - 35, H - 85); c.lineTo(fx + 35, H - 85); c.lineTo(fx + 45, H - 20); c.fill();
      c.strokeStyle = 'rgba(240,240,240,0.8)'; c.lineWidth = 2; c.beginPath(); c.moveTo(fx - 8, 0); c.lineTo(fx - 9, 50); c.moveTo(fx + 8, 0); c.lineTo(fx + 9, 50); c.stroke();
    }
    if (kind === 'jacket') {
      c.fillStyle = 'rgba(190,190,190,0.9)'; c.fillRect(fx - 1.5, 0, 3, H);
      c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(fx - 60, H - 90, 3, 40); c.fillRect(fx + 57, H - 90, 3, 40);
      c.fillStyle = 'rgba(255,255,255,0.08)'; for (let y = 20; y < H; y += 40) c.fillRect(0, y, W, 2);
    }
    if (kind === 'tshirt') { c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(fx, 0, 26, 14, 0, 0, Math.PI); c.fill(); }
    if (vest) {
      c.fillStyle = hex(vest); c.fillRect(0, H * 0.18, fx - 20, H * 0.82); c.fillRect(fx + 20, H * 0.18, W - fx - 20, H * 0.82);
      c.fillStyle = 'rgba(0,0,0,0.12)'; for (let i = 0; i < 3000; i++) c.fillRect(rnd() * W, H * 0.18 + rnd() * H * 0.82, 1, 1);
      for (const y of [H * 0.55, H * 0.75]) { c.fillStyle = '#d8dcde'; c.fillRect(0, y, fx - 20, 10); c.fillRect(fx + 20, y, W - fx - 20, 10); }
    }
    const g = c.createLinearGradient(0, H, 0, H - 30); g.addColorStop(0, 'rgba(0,0,0,0.3)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, H - 30, W, 30);
  });
}

// ---------------- shared geometry ----------------
/** anatomical limb: lathe through a radius profile (top→bottom) + front/back muscle bias, centred at origin */
function anat(prof: [number, number][], L: number, bias: (t: number) => number = () => 0, flat = 1) {
  const pts = prof.map(([r, t]) => new THREE.Vector2(Math.max(0.001, r), (0.5 - t) * L));
  const g = new THREE.LatheGeometry(pts, 14);
  const p = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) {
    const y = p.getY(i), t = 0.5 - y / L; const z = p.getZ(i);
    p.setX(i, p.getX(i) * flat);
    const b = bias(t), k = Math.abs(z) / 0.06;
    if ((b > 0 && z > 0) || (b < 0 && z < 0)) p.setZ(i, z + b * k); // muscle mass on the front (b>0) or back (b<0)
  }
  g.computeVertexNormals();
  return g;
}
const G = {
  // deltoid → biceps bulge → slim above the elbow
  upper: anat([[0.035, 0], [0.052, 0.08], [0.05, 0.3], [0.047, 0.55], [0.04, 0.85], [0.036, 1]], 0.3, (t) => Math.exp(-((t - 0.45) ** 2) / 0.04) * 0.008),
  // forearm muscle mass near the elbow, tapering to a flat wrist
  fore: anat([[0.036, 0], [0.043, 0.18], [0.039, 0.45], [0.031, 0.8], [0.026, 0.95], [0.022, 1]], 0.27, () => 0, 0.92),
  // quadriceps (front) & hamstrings, tapering to the knee
  thigh: anat([[0.07, 0], [0.078, 0.12], [0.073, 0.4], [0.06, 0.75], [0.05, 0.95], [0.046, 1]], 0.44, (t) => Math.exp(-((t - 0.35) ** 2) / 0.05) * 0.012),
  // calf bulge behind, slim ankle
  shin: anat([[0.047, 0], [0.054, 0.18], [0.05, 0.38], [0.038, 0.7], [0.03, 0.92], [0.028, 1]], 0.43, (t) => -Math.exp(-((t - 0.25) ** 2) / 0.03) * 0.016),
  shoulder: new THREE.SphereGeometry(0.066, 14, 10), palm: new THREE.CapsuleGeometry(0.03, 0.035, 3, 8),
  finger: new THREE.CapsuleGeometry(0.0095, 0.045, 2, 5), thumb: new THREE.CapsuleGeometry(0.011, 0.03, 2, 5),
  head: new THREE.SphereGeometry(0.105, 24, 16), ear: new THREE.SphereGeometry(0.03, 8, 6), nose: new THREE.SphereGeometry(0.02, 8, 6),
  neck: new THREE.CylinderGeometry(0.041, 0.05, 0.13, 14), shoe: new THREE.CapsuleGeometry(0.046, 0.15, 4, 8).rotateX(Math.PI / 2),
  sole: new THREE.BoxGeometry(0.1, 0.02, 0.25), pelvis: new THREE.SphereGeometry(0.15, 14, 10),
};
const _geoCache = new Map<string, THREE.BufferGeometry>();
/** shared geometry cache: identical parts of different characters reuse one GPU buffer */
function cg(key: string, make: () => THREE.BufferGeometry) { let g = _geoCache.get(key); if (!g) { g = make(); _geoCache.set(key, g); } return g; }
function torsoGeo(female: boolean, build: number) { return cg('torso' + female + build, () => torsoGeoRaw(female, build)); }
function torsoGeoRaw(female: boolean, build: number) {
  const pts = female
    ? [[0.15, 0.88], [0.135, 1.0], [0.125, 1.08], [0.155, 1.22], [0.165, 1.3], [0.15, 1.4], [0.125, 1.46], [0.07, 1.51], [0.045, 1.53]]
    : [[0.148, 0.88], [0.145, 1.0], [0.15, 1.1], [0.168, 1.24], [0.176, 1.32], [0.172, 1.4], [0.145, 1.46], [0.08, 1.51], [0.05, 1.53]];
  const g = new THREE.LatheGeometry(pts.map(([r, y]) => new THREE.Vector2(r * build, y)), 28, Math.PI, Math.PI * 2);
  g.scale(1.18, 1, 0.66);
  // anatomy: chest / bust forward, shoulder blades & flat lower back, slight spinal S-curve, waist taper
  const p = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i); let z = p.getZ(i);
    const front = z > 0 ? 1 : 0;
    const chest = Math.exp(-((y - (female ? 1.28 : 1.31)) ** 2) / 0.006);
    const sides = Math.exp(-(x * x) / (female ? 0.006 : 0.02));
    if (front) z += chest * (female ? 0.038 : 0.022) * (female ? Math.exp(-((Math.abs(x) - 0.075) ** 2) / 0.003) : sides);
    else { z -= Math.exp(-((y - 1.33) ** 2) / 0.008) * 0.014 * Math.exp(-((Math.abs(x) - 0.08) ** 2) / 0.004); z += Math.exp(-((y - 1.02) ** 2) / 0.01) * 0.012; }
    const waist = Math.exp(-((y - 1.06) ** 2) / 0.006) * (female ? 0.09 : 0.04);
    p.setXYZ(i, x * (1 - waist), y, z * (1 - waist * 0.5));
  }
  g.computeVertexNormals();
  return g;
}

export class Humanoid {
  root = new THREE.Group();
  body = new THREE.Group();
  head = new THREE.Group();
  neck = new THREE.Group();
  lArm = new THREE.Group(); rArm = new THREE.Group();
  lElbow = new THREE.Group(); rElbow = new THREE.Group();
  lHand = new THREE.Group(); rHand = new THREE.Group();
  lLeg = new THREE.Group(); rLeg = new THREE.Group();
  lKnee = new THREE.Group(); rKnee = new THREE.Group();
  torso!: THREE.Mesh;
  headMesh!: THREE.Mesh;
  skinMat: THREE.Material;
  hand = new THREE.Group();
  phase = Math.random() * 6;
  height: number;
  style: HumanStyle;
  twitch = 0;
  meshes: THREE.Mesh[] = [];
  lArmOverride = false;
  rArmOverride = false;
  private idleT = Math.random() * 10;

  constructor(s: HumanStyle, shadows = false) {
    this.style = s;
    const H = s.height ?? 1.75; this.height = H;
    const sc = H / 1.75; const bw = s.build ?? 1;
    const female = !!s.female;
    const top: Top = s.top ?? 'tshirt';
    const longSleeves = s.sleeves ? s.sleeves === 'long' : top !== 'tshirt';
    this.skinMat = mat({ color: s.skin, rough: 0.62, key: 'skin' + s.skin });
    const skin = this.skinMat;
    const shirtM = mat({ map: clothTexture(s.shirt, top, s.vest), rough: 0.92, key: `top${s.shirt}${top}${s.vest}` });
    const sleeveM = mat({ map: clothTexture(s.shirt, top === 'flannel' || top === 'knit' ? top : 'sleeve'), rough: 0.92, key: `sl${s.shirt}${top}` });
    const pantsM = mat({ map: clothTexture(s.pants, s.bottom ?? 'pants'), rough: 0.95, key: `bt${s.pants}${s.bottom}` });
    const shoeM = mat({ color: s.shoes ?? 0x1c1a18, rough: 0.55, key: 'shoe' + (s.shoes ?? 0) });
    const soleM = mat({ color: s.shoes === 0xdddddd ? 0xf2f2f2 : 0x111111, rough: 0.8, key: 'sole' + s.shoes });
    this.root.add(this.body);
    this.body.scale.set(bw, sc, bw);
    const add = (parent: THREE.Object3D, g: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, name = '') => {
      const me = new THREE.Mesh(g, m); me.position.set(x, y, z); me.castShadow = shadows; me.name = name; parent.add(me); this.meshes.push(me); return me;
    };
    // ----- legs -----
    [this.lLeg, this.rLeg].forEach((leg, i) => {
      const sx = i ? 1 : -1; const knee = i ? this.rKnee : this.lKnee;
      leg.position.set(sx * 0.093, 0.93, 0); this.body.add(leg);
      const th = add(leg, G.thigh, pantsM, 0, -0.22, 0); th.scale.set(female ? 1.05 : 1, 1, 1);
      knee.position.set(0, -0.45, 0); leg.add(knee);
      add(knee, G.shin, pantsM, 0, -0.2, 0);
      const ankle = new THREE.Group(); ankle.position.set(0, -0.43, 0); knee.add(ankle);
      const sh = add(ankle, G.shoe, shoeM, 0, -0.01, 0.045); sh.scale.set(female ? 0.85 : 1, 0.75, female ? 0.92 : 1);
      add(ankle, G.sole, soleM, 0, -0.04, 0.045).scale.set(female ? 0.85 : 1, 1, female ? 0.92 : 1);
    });
    // ----- hips & torso -----
    const pel = add(this.body, G.pelvis, pantsM, 0, 0.93, 0); pel.scale.set(female ? 1.2 : 1.12, 0.62, 0.72);
    // belt + buckle, trouser seams over the shoes, wrist watch
    if (!female && !s.coat) {
      const belt = add(this.body, cg('belt', () => new THREE.TorusGeometry(0.152, 0.018, 6, 22)), mat({ color: 0x1c140e, rough: 0.5, key: 'belt' }), 0, 0.95, 0);
      belt.rotation.x = Math.PI / 2; belt.scale.set(1.16, 0.7, 1);
      add(this.body, cg('buckle', () => new THREE.BoxGeometry(0.045, 0.032, 0.012)), mat({ color: 0xb8a060, metal: 0.9, rough: 0.3, key: 'buckle' }), 0, 0.95, 0.112);
    }
    this.torso = add(this.body, torsoGeo(female, 1), shirtM, 0, 0, 0);
    // trapezius slope neck→shoulders and glutes (no more "stick" silhouette)
    const trap = add(this.body, cg('trap', () => new THREE.SphereGeometry(0.1, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2)), shirtM, 0, 1.455, -0.01); trap.scale.set(female ? 1.6 : 1.9, 0.55, 0.85);
    for (const sx of [-1, 1]) { const gl = add(this.body, cg('glute', () => new THREE.SphereGeometry(0.085, 12, 8)), pantsM, sx * 0.07, 0.86, -0.055); gl.scale.set(1, 1.05, 0.85); }
    if (s.belly) { const b = add(this.body, cg('belly', () => new THREE.SphereGeometry(0.17, 14, 10)), shirtM, 0, 1.08, 0.06); b.scale.set(1.1, 0.95, 0.85); }
    if (s.coat) { const c = add(this.body, new THREE.CylinderGeometry(0.17, 0.205, 0.46, 16, 1, true), shirtM, 0, 0.67, 0); c.scale.set(1.15, 1, 0.74); (c.material as THREE.Material).side = THREE.DoubleSide; }
    // collar
    if (top === 'shirt' || top === 'flannel' || top === 'suit' || top === 'jacket') {
      const col = add(this.body, new THREE.TorusGeometry(0.058, 0.014, 6, 14), shirtM, 0, 1.5, 0.005); col.rotation.x = Math.PI / 2 - 0.25;
    }
    if (top === 'hoodie') { const hd = add(this.body, new THREE.TorusGeometry(0.075, 0.03, 8, 16), shirtM, 0, 1.5, -0.02); hd.rotation.x = Math.PI / 2 - 0.4; }
    // ----- arms -----
    [this.lArm, this.rArm].forEach((arm, i) => {
      const sx = i ? 1 : -1; const elbow = i ? this.rElbow : this.lElbow; const handG = i ? this.rHand : this.lHand;
      add(this.body, G.shoulder, shirtM, sx * 0.19 * (female ? 0.93 : 1), 1.42, 0).scale.set(1, 0.85, 0.9);
      arm.position.set(sx * 0.205 * (female ? 0.93 : 1), 1.42, 0); arm.rotation.z = sx * 0.07; this.body.add(arm);
      add(arm, G.upper, sleeveM, 0, -0.14, 0).scale.setScalar(female ? 0.88 : 1);
      elbow.position.set(0, -0.285, 0); arm.add(elbow);
      add(elbow, G.fore, longSleeves ? sleeveM : skin, 0, -0.12, 0).scale.setScalar(female ? 0.86 : 1);
      if (longSleeves) add(elbow, new THREE.CylinderGeometry(0.036, 0.036, 0.02, 10), skin, 0, -0.24, 0);
      handG.position.set(0, -0.255, 0); elbow.add(handG);
      arm.userData.hand = handG;
      // anatomical hand: wide flat palm, knuckle ridge, 4 two-segment fingers in a relaxed curl, opposable thumb
      const hs2 = female ? 0.86 : 1;
      const palm = add(handG, cg('palm2', () => new THREE.CapsuleGeometry(0.03, 0.04, 4, 10)), skin, 0, -0.05, 0, 'hand'); palm.scale.set(hs2 * 1.12, 1, 0.4);
      const knuck = add(handG, cg('knuck', () => new THREE.CapsuleGeometry(0.009, 0.05, 3, 8).rotateZ(Math.PI / 2)), skin, 0, -0.088, 0.003, 'hand'); knuck.scale.setScalar(hs2);
      const fLen = [0.042, 0.048, 0.046, 0.036];
      for (let f = 0; f < 4; f++) {
        const fx = (-0.021 + f * 0.014) * hs2;
        const base = new THREE.Group(); base.position.set(fx, -0.092, 0.002); base.rotation.set(0.35, 0, (f - 1.5) * 0.06); handG.add(base);
        const p1 = add(base, cg('fseg1', () => new THREE.CapsuleGeometry(0.0085, 0.022, 2, 6)), skin, 0, -fLen[f] * 0.3, 0, 'hand'); p1.scale.set(hs2, fLen[f] / 0.045, hs2);
        const mid = new THREE.Group(); mid.position.set(0, -fLen[f] * 0.62, 0); mid.rotation.x = 0.45; base.add(mid);
        const p2 = add(mid, cg('fseg2', () => new THREE.CapsuleGeometry(0.0075, 0.018, 2, 6)), skin, 0, -fLen[f] * 0.28, 0, 'hand'); p2.scale.set(hs2, fLen[f] / 0.045, hs2);
      }
      const tb = new THREE.Group(); tb.position.set((i ? -1 : 1) * -0.026 * hs2, -0.04, 0.012); tb.rotation.set(0.6, 0, (i ? 1 : -1) * -0.55); handG.add(tb);
      add(tb, cg('thumb1', () => new THREE.CapsuleGeometry(0.0105, 0.022, 2, 6)), skin, 0, -0.018, 0, 'hand').scale.setScalar(hs2);
      const tb2 = new THREE.Group(); tb2.position.set(0, -0.036, 0); tb2.rotation.x = 0.4; tb.add(tb2);
      add(tb2, cg('thumb2', () => new THREE.CapsuleGeometry(0.0095, 0.016, 2, 6)), skin, 0, -0.014, 0, 'hand').scale.setScalar(hs2);
    });
    this.hand.position.set(0, -0.08, 0.035); this.rHand.add(this.hand);
    // ----- neck & head -----
    this.neck.position.set(0, 1.5, 0); this.body.add(this.neck);
    add(this.neck, G.neck, skin, 0, 0.03, -0.005);
    this.head.position.set(0, 0.145, 0.01); this.neck.add(this.head);
    if (s.faceless) {
      this.headMesh = add(this.head, G.head, new THREE.MeshBasicMaterial({ color: 0x000000 }), 0, 0, 0);
    } else if (s.photo && PHOTO_FACE[s.photo]) {
      // photographic face projected onto the front of the head, feathered into the skin
      this.headMesh = add(this.head, headPhoto, skin, 0, 0, 0);
      this.headMesh.scale.set(female ? 0.86 : 0.9, 1.1, 1.0);
      const fmat = new THREE.MeshStandardMaterial({ map: photoFaceTexture(s.photo, skin), transparent: true, roughness: 0.62, polygonOffset: true, polygonOffsetFactor: -1 });
      const face = add(this.head, getFaceShell(), fmat, 0, 0, 0); face.scale.copy(this.headMesh.scale); face.castShadow = false;
      // jaw/cheek volume so the head isn't a perfect ball
      const jaw = add(this.head, cg('jaw', () => new THREE.SphereGeometry(0.075, 14, 10)), skin, 0, -0.06, -0.015); jaw.scale.set(female ? 0.95 : 1.08, 0.72, 0.9);
      for (const sx of [-1, 1]) { const e = add(this.head, G.ear, skin, sx * 0.093, -0.004, -0.005); e.scale.set(0.35, 0.75, 0.55); }
    } else {
      const fm = mat({ map: faceTexture(s), rough: 0.6, key: 'face' + [s.skin, s.female, s.beard, s.age, s.eyes, s.eyeColor, s.hair].join('|') });
      this.headMesh = add(this.head, headPainted, fm, 0, 0, 0);
      this.headMesh.scale.set(female ? 0.86 : 0.9, 1.1, 1.0);
      const jaw = add(this.head, cg('jaw', () => new THREE.SphereGeometry(0.075, 14, 10)), skin, 0, -0.06, -0.01); jaw.scale.set(female ? 0.92 : 1.05, 0.72, 0.9);
      for (const sx of [-1, 1]) { const e = add(this.head, G.ear, skin, sx * 0.093, -0.004, -0.005); e.scale.set(0.35, 0.75, 0.55); }
      if (s.eyes === 'glow') for (const sx of [-1, 1]) add(this.head, new THREE.SphereGeometry(0.012, 6, 4), new THREE.MeshBasicMaterial({ color: 0xfff2d0 }), sx * 0.038, 0.025, 0.095);
    }
    // ----- hair -----
    const hs = s.hairStyle ?? 'short';
    const hairCol = hs === 'grey' ? 0x9a9893 : (s.hair ?? 0x1b1410);
    const hairM = mat({ map: hairTexture(hairCol, hs === 'curly'), rough: 0.85, key: 'hairm' + hairCol + hs });
    const cap = (r: number, thetaLen: number, phiStart = 0, phiLen = Math.PI * 2, thetaStart = 0) => new THREE.SphereGeometry(r, 18, 10, phiStart, phiLen, thetaStart, thetaLen);
    if (hs === 'short' || hs === 'curly' || hs === 'cap') {
      const top2 = add(this.head, cap(hs === 'curly' ? 0.117 : 0.111, Math.PI * 0.42), hairM, 0, 0.012, -0.006); top2.scale.set(0.93, 1.06, 1.03); top2.rotation.x = -0.25;
      add(this.head, cap(0.109, Math.PI * 0.32, Math.PI, Math.PI, Math.PI * 0.32), hairM, 0, 0.0, -0.004).scale.set(0.93, 1.1, 1.03);
    }
    if (hs === 'grey') {
      const back = add(this.head, cap(0.109, Math.PI * 0.35, Math.PI * 0.9, Math.PI * 1.2, Math.PI * 0.28), hairM, 0, 0, -0.004); back.scale.set(0.93, 1.1, 1.03);
      add(this.head, cap(0.108, Math.PI * 0.2), hairM, 0, 0.008, -0.03).scale.set(0.8, 0.6, 0.8);
    }
    if (hs === 'long') {
      add(this.head, cap(0.113, Math.PI * 0.5), hairM, 0, 0.008, -0.005).scale.set(0.9, 1.08, 1.04);
      const back = add(this.head, new THREE.CylinderGeometry(0.1, 0.12, 0.3, 14, 1, true, Math.PI / 2 + 0.3, Math.PI - 0.6), hairM, 0, -0.12, -0.01);
      back.scale.set(1, 1, 1.05); (back.material as THREE.Material).side = THREE.DoubleSide;
    }
    if (hs === 'scarf') {
      add(this.head, cap(0.11, Math.PI * 0.3), hairM, 0, 0.02, 0.01).scale.set(0.88, 1.0, 1.02); // fringe
      const scM = mat({ map: clothTexture(s.scarf ?? 0x2a2a35, 'sleeve'), rough: 0.95, key: 'scarf' + s.scarf });
      const sc1 = add(this.head, cap(0.124, Math.PI * 0.72, Math.PI / 2 + 0.75, Math.PI * 2 - 1.5), scM, 0, 0.012, -0.012); sc1.scale.set(0.95, 1.12, 1.05);
      const drape = add(this.head, new THREE.CylinderGeometry(0.11, 0.16, 0.28, 16, 1, true, Math.PI / 2 + 0.55, Math.PI * 2 - 1.1), scM, 0, -0.14, -0.015);
      drape.scale.set(1, 1, 0.9); (drape.material as THREE.Material).side = THREE.DoubleSide;
    }
    if (hs === 'cap') {
      const cm = mat({ color: s.cap ?? 0x223355, rough: 0.9, key: 'cap' + (s.cap ?? 0) });
      const crown = add(this.head, cap(0.116, Math.PI * 0.44), cm, 0, 0.016, -0.004); crown.scale.set(0.95, 1.0, 1.04);
      const brim = add(this.head, new THREE.CylinderGeometry(0.1, 0.1, 0.012, 16, 1, false, -Math.PI / 2, Math.PI), cm, 0, 0.042, 0.06);
      brim.scale.set(0.95, 1, 0.85); brim.rotation.x = 0.12;
    }
    if (hs === 'hood') {
      const hood = add(this.head, cap(0.142, Math.PI * 0.78, Math.PI / 2 + 0.7, Math.PI * 2 - 1.4), shirtM, 0, 0.005, -0.02);
      hood.scale.set(1, 1.08, 1.06); (hood.material as THREE.Material).side = THREE.DoubleSide;
      if (s.faceless) add(this.head, new THREE.CircleGeometry(0.1, 14), new THREE.MeshBasicMaterial({ color: 0x000000 }), 0, -0.01, 0.12);
    }
    if (s.glasses) {
      const gm = mat({ color: 0x2a1a10, metal: 0.3, rough: 0.4, key: 'glasses' });
      for (const sx of [-1, 1]) { const r = add(this.head, new THREE.TorusGeometry(0.02, 0.0028, 4, 14), gm, sx * 0.037, 0.022, 0.104); r.scale.set(1.15, 0.85, 1); }
      add(this.head, new THREE.BoxGeometry(0.018, 0.004, 0.004), gm, 0, 0.026, 0.108);
      for (const sx of [-1, 1]) add(this.head, new THREE.BoxGeometry(0.004, 0.004, 0.1), gm, sx * 0.083, 0.024, 0.055);
    }
    if (s.hunch) { this.body.rotation.x = s.hunch; this.neck.rotation.x = -s.hunch * 0.6; }
    // relaxed default pose
    this.lElbow.rotation.x = -0.12; this.rElbow.rotation.x = -0.12;
  }

  /** speed in m/s, used to scale walk cycle */
  animate(dt: number, speed: number, opts: { stiff?: boolean; erratic?: number } = {}) {
    const moving = speed > 0.05;
    this.idleT += dt;
    this.phase += dt * (moving ? 2.2 + speed * 2.6 : 0);
    const amp = moving ? Math.min(0.55, 0.18 + speed * 0.25) * (opts.stiff ? 0.4 : 1) : 0;
    const s = Math.sin(this.phase), co = Math.cos(this.phase);
    const k = Math.min(1, dt * 10);
    const lerp = (o: THREE.Object3D, v: number) => { o.rotation.x += (v - o.rotation.x) * k; };
    lerp(this.lLeg, s * amp); lerp(this.rLeg, -s * amp);
    lerp(this.lKnee, moving ? 0.05 + Math.max(0, -co) * amp * 1.7 : 0.02);
    lerp(this.rKnee, moving ? 0.05 + Math.max(0, co) * amp * 1.7 : 0.02);
    if (!this.lArmOverride) { lerp(this.lArm, -s * amp * 0.75); lerp(this.lElbow, -0.15 - Math.max(0, s) * amp * 0.7); }
    if (!this.rArmOverride) { lerp(this.rArm, s * amp * 0.75); lerp(this.rElbow, -0.15 - Math.max(0, -s) * amp * 0.7); }
    if (moving) {
      this.body.position.y = Math.abs(co) * 0.022 - 0.01;
      this.body.rotation.y = s * amp * 0.12;
      this.body.rotation.z = co * amp * 0.03;
    } else {
      // idle: breathing, weight shift, small head motion
      const br = Math.sin(this.idleT * 1.6);
      this.body.position.y = br * 0.002;
      this.torso.scale.set(1 + br * 0.008, 1, 1 + br * 0.012);
      this.body.rotation.z += (Math.sin(this.idleT * 0.45) * 0.014 - this.body.rotation.z) * k;
      this.body.rotation.y += (0 - this.body.rotation.y) * k;
      this.head.rotation.z = Math.sin(this.idleT * 0.3) * 0.03;
      this.head.rotation.x = Math.sin(this.idleT * 0.21 + 1) * 0.04;
    }
    if (opts.erratic) {
      this.twitch -= dt;
      if (this.twitch <= 0) {
        this.twitch = 0.05 + Math.random() * 0.4;
        this.neck.rotation.z = (Math.random() - 0.5) * opts.erratic;
        this.lArm.rotation.z = -0.2 - Math.random() * opts.erratic * 0.6;
        this.rArm.rotation.z = 0.2 + Math.random() * opts.erratic * 0.6;
        this.lElbow.rotation.x = -Math.random() * 1.6; this.rElbow.rotation.x = -Math.random() * 1.6;
      }
    }
  }
}

// ---------------- Customer archetypes ----------------
export interface Archetype { id: string; name: string; style: HumanStyle; pitch: number; speed: number; lines: string[]; answers: Record<string, string> }

export const ARCHETYPES: Archetype[] = [
  {
    id: 'worker', name: 'مرد خسته با لباس کار', pitch: 105, speed: 1.1,
    style: { skin: 0xc29676, shirt: 0x2a3a5a, pants: 0x2b3646, bottom: 'jeans', top: 'shirt', vest: 0xff7a1a, hairStyle: 'short', hair: 0x1a120c, beard: 'stubble', age: 44, build: 1.06, shoes: 0x4a3420, photo: 'man' },
    lines: ['یه قهوه می‌خوام... قوی‌ترینش.', 'شیفت شب سخته، نه؟'],
    answers: { greet: 'شب بخیر... خسته نباشی.', ok: 'خستم. دوازده ساعته سر پام.', where: 'کارگاه. اون‌طرف جاده. شیفت عوض کردیم.' },
  },
  {
    id: 'woman', name: 'زن', pitch: 210, speed: 1.15,
    style: { skin: 0xe4bea0, shirt: 0x5a2230, pants: 0x1d1d26, top: 'jacket', hair: 0x2b1a12, hairStyle: 'scarf', scarf: 0x2e2e38, female: true, coat: true, age: 34, build: 0.92, height: 1.64, eyeColor: '#2a1a0c', shoes: 0x1a1a1a },
    lines: ['فقط یه آب معدنی.', 'اینجا همیشه این‌قدر ساکته؟'],
    answers: { greet: 'مرسی، شب شما هم بخیر.', ok: 'آره... فقط یه کم خوابم میاد.', where: 'خونه‌ی مادرم. حالش خوب نیست.' },
  },
  {
    id: 'trucker', name: 'راننده کامیون', pitch: 90, speed: 0.95,
    style: { skin: 0xb48464, shirt: 0x7a2020, pants: 0x2a3550, top: 'flannel', bottom: 'jeans', hairStyle: 'cap', cap: 0x1d3d1d, hair: 0x2a1a10, beard: 'full', age: 51, build: 1.14, belly: true, height: 1.82, shoes: 0x3a2a1a },
    lines: ['باک رو پر کردم. حساب کن.', 'این جاده شبا بی‌صاحابه.'],
    answers: { greet: 'شب بخیر رفیق.', ok: 'خوبم. فقط چشمام دیگه نمی‌بینه.', where: 'بندر. باید تا صبح برسم.' },
  },
  {
    id: 'youth', name: 'جوان', pitch: 150, speed: 1.3,
    style: { skin: 0xd6ad8c, shirt: 0x2d4a3a, pants: 0x1e2a44, top: 'hoodie', bottom: 'jeans', hairStyle: 'curly', hair: 0x120c08, age: 19, build: 0.95, height: 1.78, shoes: 0xdddddd, photo: 'youth' },
    lines: ['این چیپس تند داری؟', 'وای فای ندارید؟'],
    answers: { greet: 'سلام داداش.', ok: 'آره بابا. حال شما؟', where: 'دور دور. خوابم نمی‌برد.' },
  },
  {
    id: 'oldman', name: 'پیرمرد', pitch: 95, speed: 0.75,
    style: { skin: 0xc8a286, shirt: 0x6a5440, pants: 0x3a3a3a, top: 'knit', hairStyle: 'grey', hair: 0x9a9893, beard: 'mustache', glasses: false, age: 72, hunch: 0.16, height: 1.68, shoes: 0x2a1a10, photo: 'old' },
    lines: ['جوون، روزنامه‌ی امروز رو داری؟', 'قبلاً اینجا یه چاه بود... خیلی قبل.'],
    answers: { greet: 'خدا قوت پسرم.', ok: 'به سن من برسی، همین که بیداری یعنی خوبی.', where: 'خوابم نمی‌بره. هر شب میام این‌جا قدم می‌زنم.' },
  },
  {
    id: 'quick', name: 'رهگذر', pitch: 130, speed: 1.45,
    style: { skin: 0xd0a686, shirt: 0x151517, pants: 0x222224, top: 'jacket', hairStyle: 'short', hair: 0x0e0a08, beard: 'stubble', age: 33, build: 0.98 },
    lines: ['...', 'عجله دارم.'],
    answers: { greet: '...', ok: 'آره.', where: 'جایی نمی‌رم.' },
  },
];

export const STRANGE_LINES = [
  'تو هم شیفت شبی؟ ... قبلی هم بود.',
  'چراغ‌ها رو خاموش نکن. اونا تاریکی رو دوست دارن.',
  'پشت سرت کسی نیست. هنوز.',
  'من قبلاً اینجا کار می‌کردم. خیلی وقت پیش.',
  'تا صبح چند ساعت مونده؟ ... برای تو زیاده.',
  'صدای زیر زمین رو می‌شنوی؟ داره صدات می‌کنه.',
  'اون تلفن ساعت دو... اون که تو رو بیدار کرد... من نبودم.',
  'به اونی که صورت نداره نگاه نکن.',
];
