// Mobile "super resolution" pipeline:
//  1) the 3D scene is rendered into an HDR (half-float) target at an adaptive internal resolution,
//     with hardware MSAA (resolved on-tile on mobile GPUs → cheap)
//  2) one fullscreen pass upscales to the display, applies halo-free contrast-adaptive sharpening,
//     ACES tone mapping, sRGB encoding and ordered dithering (no banding in dark fog).
// Result: near-native sharpness at ~half the shading cost of rendering natively.
import * as THREE from 'three';

const vert = /* glsl */ `
varying vec2 vUv;
void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

const frag = /* glsl */ `
precision highp float;
uniform sampler2D tDiffuse;
uniform vec2 texel;
uniform float sharp;
uniform float exposure;
varying vec2 vUv;

vec3 RRTAndODTFit(vec3 v) { vec3 a = v * (v + 0.0245786) - 0.000090537; vec3 b = v * (0.983729 * v + 0.4329510) + 0.238081; return a / b; }
vec3 aces(vec3 color) {
  const mat3 inM = mat3(vec3(0.59719, 0.07600, 0.02840), vec3(0.35458, 0.90834, 0.13383), vec3(0.04823, 0.01566, 0.83777));
  const mat3 outM = mat3(vec3(1.60475, -0.10208, -0.00327), vec3(-0.53108, 1.10813, -0.07276), vec3(-0.07367, -0.00605, 1.07602));
  color *= exposure / 0.6;
  color = inM * color; color = RRTAndODTFit(color); color = outM * color;
  return clamp(color, 0.0, 1.0);
}
vec3 toSRGB(vec3 c) { return mix(pow(c, vec3(0.41666)) * 1.055 - 0.055, c * 12.92, vec3(lessThanEqual(c, vec3(0.0031308)))); }

void main() {
  vec3 c = texture2D(tDiffuse, vUv).rgb;
  vec3 n = texture2D(tDiffuse, vUv + vec2(0.0, texel.y)).rgb;
  vec3 s = texture2D(tDiffuse, vUv - vec2(0.0, texel.y)).rgb;
  vec3 e = texture2D(tDiffuse, vUv + vec2(texel.x, 0.0)).rgb;
  vec3 w = texture2D(tDiffuse, vUv - vec2(texel.x, 0.0)).rgb;
  // contrast-adaptive sharpening (softer where local contrast is already high), clamped to the
  // neighbourhood range so there are never halos / ringing
  vec3 mn = min(c, min(min(n, s), min(e, w)));
  vec3 mx = max(c, max(max(n, s), max(e, w)));
  vec3 blur = (n + s + e + w) * 0.25;
  float lc = dot(mx - mn, vec3(0.299, 0.587, 0.114)) / (dot(mx, vec3(0.299, 0.587, 0.114)) + 0.05);
  float amt = sharp * (1.6 - clamp(lc, 0.0, 1.0));
  vec3 col = clamp(c + (c - blur) * amt, mn, mx);
  col = toSRGB(aces(max(col, 0.0)));
  // ordered dither (±0.5 LSB)
  float d = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
  gl_FragColor = vec4(col + d / 255.0, 1.0);
}`;

export class PostPipeline {
  rt: THREE.WebGLRenderTarget;
  private quadScene = new THREE.Scene();
  private quadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private mat: THREE.ShaderMaterial;
  private size = new THREE.Vector2();
  /** internal resolution relative to the output drawing buffer (0.35 .. 1) */
  scale = 0.75;
  enabled = true;

  constructor(private r: THREE.WebGLRenderer) {
    const ext = r.extensions;
    // multisampled RGBA16F needs EXT_color_buffer_float on WebGL2; otherwise fall back to RGBA8 (always MSAA-capable)
    const halfOK = r.capabilities.isWebGL2 && ext.has('EXT_color_buffer_float');
    this.rt = new THREE.WebGLRenderTarget(4, 4, {
      type: halfOK ? THREE.HalfFloatType : THREE.UnsignedByteType,
      depthBuffer: true, stencilBuffer: false, generateMipmaps: false,
      minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
    });
    this.mat = new THREE.ShaderMaterial({
      uniforms: { tDiffuse: { value: this.rt.texture }, texel: { value: new THREE.Vector2(1 / 4, 1 / 4) }, sharp: { value: 0.55 }, exposure: { value: 1 } },
      vertexShader: vert, fragmentShader: frag, depthTest: false, depthWrite: false, toneMapped: false,
    });
    const q = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.mat); q.frustumCulled = false; this.quadScene.add(q);
    // when HDR targets are unavailable, three must tone-map nothing: we still do it in the pass
  }

  setSamples(n: number) {
    const max = this.r.capabilities.isWebGL2 ? this.r.capabilities.maxSamples : 0;
    const s = Math.min(n, max);
    if (this.rt.samples !== s) { this.rt.samples = s; this.rt.dispose(); }
  }
  setSharpness(v: number) { this.mat.uniforms.sharp.value = v; }

  private fit() {
    this.r.getDrawingBufferSize(this.size);
    const W = Math.max(2, Math.round(this.size.x * this.scale)), H = Math.max(2, Math.round(this.size.y * this.scale));
    if (this.rt.width !== W || this.rt.height !== H) this.rt.setSize(W, H);
    (this.mat.uniforms.texel.value as THREE.Vector2).set(1 / W, 1 / H);
  }

  render(scene: THREE.Scene, camera: THREE.Camera) {
    if (!this.enabled) { this.r.setRenderTarget(null); this.r.render(scene, camera); return; }
    this.fit();
    this.mat.uniforms.exposure.value = this.r.toneMappingExposure;
    this.r.setRenderTarget(this.rt);
    this.r.render(scene, camera);
    this.r.setRenderTarget(null);
    this.r.render(this.quadScene, this.quadCam);
  }

  /** current internal resolution (for the FPS overlay) */
  info() { return `${this.rt.width}×${this.rt.height}`; }
}
