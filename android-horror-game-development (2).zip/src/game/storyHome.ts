// Home chapters 6 (morning), 7 (the fire) and 10 (the ending) – kept in their own module.
// `s` is the Story instance (accessed loosely to reach its helpers).
import * as THREE from 'three';
import { ui } from './store';
import { audio, type LoopHandle } from './audio';
import { mat, tex } from './textures';
import { docs } from './docs';
import { Humanoid } from './characters';
import { createHouseFire } from './levels/luxury';
import { clearFogBox } from './fog';

/* eslint-disable @typescript-eslint/no-explicit-any */
type S = any;
const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
const fa = (n: number | string) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);
export const FILMS = {
  oldRoad: 'https://videos.pexels.com/video-files/3588881/3588881-hd_1920_1080_18fps.mp4',
  oldCar: 'https://videos.pexels.com/video-files/3588888/3588888-hd_1920_1080_18fps.mp4',
  fire: 'https://videos.pexels.com/video-files/20706788/20706788-hd_1920_1080_25fps.mp4',
  news: 'https://videos.pexels.com/video-files/14367163/14367163-hd_1920_1080_30fps.mp4',
};

// ---------- 6: morning at home with Mina ----------
export function morning(s: S) {
  const g = s.g; const h = g.house!; const k = 'mo_';
  const F = (n: string) => !!s.f[k + n]; const SF = (n: string) => { s.f[k + n] = true; };
  const isT = (id: string) => s.tid() === id;
  g.player.hasFlash = true; h.tall.root.visible = false; h.setBlinds(1); h.items.envelope.visible = false; h.items.keys.visible = false;
  h.lux.lamps.forEach((l: THREE.PointLight) => (l.intensity = 2)); h.lux.chandelier.intensity = 3;
  if (s.taskIndex === 0) { g.player.teleport(V(12.4, 0, 3.4), Math.PI / 2 + 0.3); s.card(`فصل ${fa(s.index)} — صبح`, 'بالاخره... خانه', 4); }
  else g.player.teleport(V(6, 0, 3.5), 0);
  h.door.locked = false; h.door.setOpen(true, true);
  const w = s.spawnWife('stand', s.taskIndex === 0 ? V(9.3, 0, 3.0) : V(7.3, 0, 4.3), -Math.PI / 2);
  const paper = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.02, 0.22), new THREE.MeshStandardMaterial({ color: 0xe8e2d2, roughness: 0.9 }));
  paper.position.set(6.2, 0.44, 2.15); paper.visible = !F('paper'); h.dyn.add(paper);
  const photo = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.01, 0.15), new THREE.MeshStandardMaterial({ color: 0xb89a70, roughness: 0.8 }));
  photo.position.set(7.75, 0.77, 3.45); h.dyn.add(photo);
  s.interact('mo-hug', V(9.3, 1.4, 3.0), () => (isT('mo-meet') ? 'در آغوش گرفتن مینا' : null), () => {
    s.wifeTalk(w, [['مینا', 'آرش! تمام شب بیدار بودم... گوشیت خاموش بود! این بوی دود چیه؟ لباسات سوخته!'], ['آرش', 'یه آتیش‌سوزی بود... پمپ بنزین... بعداً برات تعریف می‌کنم.'], ['مینا', 'بیا تو. یه چای برات دم می‌کنم.']], () => { SF('meet'); w.root.position.set(7.3, 0, 4.3); });
  }, 2.4);
  s.interact('mo-paper', V(6.2, 0.6, 2.15), () => (paper.visible && isT('mo-paper') ? 'خواندن روزنامه‌ی صبح' : null), () => { paper.visible = false; SF('paper'); g.showNote('روزنامه‌ی صبح — ستون حوادث', 'آتش‌سوزی مرموز در جاده‌ی قدیم\n\nساکنان اطراف جاده‌ی قدیم از شعله‌های عظیمی در محل «پمپ بنزین متروکه‌ی پترو ۲۴» خبر داده‌اند. مأموران در محل هیچ ساختمانی نیافتند؛ فقط زمینی سوخته که به گفته‌ی اهالی از سال ۱۳۶۶ همین‌طور مانده است.\n\nدر همان سال، این پمپ در آتش سوخت و کارمند شیفت شب آن، «مسعود راد»، برای همیشه ناپدید شد.'); }, 1.8);
  s.interact('mo-tv', V(8.8, 1.3, 0.7), () => (isT('mo-tv') ? 'روشن کردن تلویزیون' : null), () => {
    h.tv.play(FILMS.news); h.tv.set(true); audio.click(); SF('tv');
    g.after(1, () => g.say('اخبار', '...آتش‌سوزی دیشب در جاده‌ی قدیم. آتش‌نشانان می‌گویند در محل حادثه هیچ پمپ بنزینی وجود ندارد...', 7));
    g.after(8.5, () => g.say('اخبار', '...خانواده‌های چهار نفری که سال‌ها پیش در همان جاده گم شده بودند، خواستار بازگشایی پرونده شدند.', 6));
  }, 2.0);
  s.interact('mo-tea', V(7.6, 0.9, 3.4), () => (isT('mo-tea') ? 'نشستن پشت میز با مینا' : null), () => {
    s.wifeTalk(w, [['مینا', 'چای‌ت سرد شد... آرش، یه چیزی بگم؟ مادرت یه بار تعریف کرد.'], ['مینا', 'پدرت، مسعود... وقتی تو سه ماهه بودی، شبا توی یه پمپ بنزین کار می‌کرد. یه شب رفت و دیگه برنگشت.'], ['مینا', 'اسم اون پمپ... پترو ۲۴ بود.'], ['آرش', '...']], () => SF('tea'));
  }, 2.2);
  s.interact('mo-photo', V(7.75, 0.9, 3.45), () => (isT('mo-photo') ? 'نگاه کردن به عکس قدیمی' : null), () => { SF('photo'); g.showNote('عکس قدیمی از کیف مادرت', 'مردی جوان با لباس فرم سرمه‌ای «پترو ۲۴» کنار جایگاه سوخت ایستاده و لبخند می‌زند.\n\nپشت عکس: «مسعود — شب اول کار — ۱۳۶۶»\n\nلباس فرمی که دیشب پوشیدی… همین لباس بود. روی اتیکتش نوشته بود «م. راد».'); }, 1.8);
  s.interact('mo-sink', V(7.2, 1.0, 5.5), () => (isT('mo-sink') ? 'شستن صورت' : null), async () => { g.player.frozen = true; audio.hum(V(7.2, 1, 5.5), 180, 0.03)?.stop(1.8); await g.sleep(2); g.player.frozen = false; SF('sink'); g.flickerAt(g.player.pos, 0.2); audio.stinger(0.1); s.think('یه لحظه... توی شیشه‌ی کابینت، پشت سرم یه مرد با لباس فرم ایستاده بود.', 4); }, 1.9);
  s.interact('mo-blinds', V(2.2, 1.6, 5.85), () => (isT('mo-blinds') ? 'پایین کشیدن کرکره' : null), () => { g.tween(1.2, (kk: number) => h.setBlinds(1 - kk)); audio.door(V(2.2, 1.6, 6), true); SF('blinds'); }, 1.9);
  s.interact('mo-bed', V(1.6, 0.8, 1.6), () => (isT('mo-sleep') ? 'خوابیدن کنار مینا' : null), () => SF('sleep'), 1.9);
  s.tasks = [
    { id: 'mo-meet', text: () => 'مینا جلوی در منتظر توست', done: () => F('meet') },
    { id: 'mo-paper', text: () => 'روزنامه‌ی صبح روی میز عسلی پذیرایی است', done: () => F('paper') && !ui.get().note },
    { id: 'mo-tv', text: () => 'تلویزیون را روشن کن و اخبار را ببین', done: () => F('tv') },
    { id: 'mo-police', text: () => 'با موبایلت (📱) به پلیس ۱۱۰ زنگ بزن و اتفاقات دیشب را گزارش بده', done: () => !!s.f.mo_police },
    { id: 'mo-tea', text: () => 'پشت میز ناهارخوری کنار مینا بنشین', done: () => F('tea') },
    { id: 'mo-photo', text: () => 'مینا یک عکس قدیمی روی میز گذاشته. نگاهش کن', done: () => F('photo') && !ui.get().note },
    { id: 'mo-sink', text: () => 'صورتت را در سینک آشپزخانه بشور', done: () => F('sink') },
    { id: 'mo-blinds', text: () => 'کرکره‌ی اتاق خواب را پایین بکش', done: () => F('blinds') },
    { id: 'mo-sleep', text: () => 'خیلی خسته‌ای. کنار مینا بخواب', done: () => F('sleep') },
  ];
}

// ---------- 7: the fire ----------
export function homeFire(s: S) {
  const g = s.g; const h = g.house!; const k = 'hf_';
  const F = (n: string) => !!s.f[k + n]; const SF = (n: string) => { s.f[k + n] = true; };
  const isT = (id: string) => s.tid() === id;
  g.player.hasFlash = true; h.tall.root.visible = false; h.setBlinds(0); h.items.envelope.visible = false; h.items.keys.visible = false; h.items.uniform.visible = false;
  h.door.locked = false; h.door.setOpen(false, true);
  if (s.taskIndex === 0) {
    g.player.teleport(V(1.55, 0.75 - 1.62, 1.4), -Math.PI / 2); g.player.pitch = 1.2;
    s.card(`فصل ${fa(s.index)} — آتش`, 'همان شب • ۰۲:۰۰ بامداد', 4);
    g.after(2, async () => { g.player.frozen = true; await g.tween(1.8, (kk: number) => { g.player.pos.set(1.55 + kk * 0.6, -0.87 * (1 - kk), 1.4); g.player.pitch = 1.2 * (1 - kk); }); g.player.frozen = false; });
  } else g.player.teleport(V(3.2, 0, 3), 0);
  const w: Humanoid = s.spawnWife('sleep');
  const fire = createHouseFire(h.dyn);
  let fireOn = false, fireT = 0; let alarm: LoopHandle | null = null; let fireSnd: LoopHandle | null = null;
  const startFire = () => {
    if (fireOn) return; fireOn = true; SF('fire');
    alarm = audio.ring(V(5, 2.6, 3), 'alarm'); fireSnd = audio.fire(V(7.4, 1, 5.2), 0.5);
    clearFogBox(); const fog = g.scene.fog as THREE.FogExp2; fog.color.set(0x2a221c);
    g.onFrame((dt: number) => {
      if (!g.house) { alarm?.stop(0.2); fireSnd?.stop(0.2); return false; }
      fireT += dt; fire.setLevel(Math.min(1, fireT / 140)); fire.update(dt);
      fog.density = 0.02 + fire.level * 0.11 * (g.player.crouching ? 0.55 : 1);
      if (g.player.pos.x > 4.5 && g.player.pos.x < 10 && fire.level > 0.25 && Math.random() < dt * 0.25) { audio.cough(); }
      h.lux.chandelier.intensity = Math.random() < 0.1 ? 0 : 1.5;
      return true;
    });
  };
  if (F('fire')) startFire();
  const ext = new THREE.Group(); ext.position.set(5.0, 0, 5.4); h.dyn.add(ext);
  const extB = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.35, 4, 10), mat({ color: 0xc8141f, rough: 0.35, metal: 0.2, key: 'ext' })); extB.position.y = 0.3; ext.add(extB);
  const extH = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.08, 0.12), mat({ color: 0x222222, key: 'exth' })); extH.position.y = 0.58; ext.add(extH);
  ext.visible = !F('ext');
  const frame = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.24, 0.02), mat({ color: 0x5a3a1a, rough: 0.6, key: 'frame' })); frame.position.set(8.4, 0.95, 0.24); frame.rotation.x = -0.15; frame.visible = !F('photo'); h.dyn.add(frame);
  let watched = 0;
  s.interact('hf-tvoff', V(8.8, 1.3, 0.7), () => (isT('hf-off') ? 'خاموش کردن تلویزیون' : null), () => {
    audio.click(); h.tv.play(FILMS.fire, 0xffd0b0); SF('off'); audio.staticBurst(0.6, 0.2);
    g.after(1.2, () => { s.think('خاموش نمیشه... داره آتیش نشون میده. این بوی دوده! آشپزخونه!', 4); startFire(); });
  }, 2.0);
  s.interact('hf-ext', V(5.0, 0.6, 5.4), () => (ext.visible && isT('hf-ext') ? 'برداشتن کپسول آتش‌نشانی' : null), () => { ext.visible = false; SF('ext'); const c = ext.clone(); c.visible = true; c.scale.setScalar(0.6); c.position.set(0, -0.2, 0); g.setItem('ext', c); }, 1.8);
  s.interact('hf-spray', V(7.4, 1.0, 5.0), () => (isT('hf-spray') && g.item === 'ext' ? 'خاموش کردن آتش با کپسول' : null), async () => {
    g.player.frozen = true; const n = audio.fire(V(7.4, 1, 5), 0.3);
    await g.tween(3, () => { if (Math.random() < 0.3) audio.footstep('wet', 0.1); });
    n?.stop(0.3); g.player.frozen = false; g.setItem(null); SF('spray'); fireT += 25;
    s.think('فایده نداره! آتیش داره بیشتر میشه... مینا!', 3.5);
  }, 2.6);
  s.interact('hf-wakewife', V(0.6, 0.9, 1.4), () => (isT('hf-wife') ? 'بیدار کردن مینا' : null), () => {
    audio.scream(V(0.6, 0.9, 1.4), 0.3);
    s.wifeTalk(w, [['مینا', 'چی شده؟! ... خدای من، دود! آرش، خونه آتیش گرفته!'], ['آرش', 'بلند شو، پشت سرم بیا. خم شو، دود رو نفس نکش!']], () => {
      SF('wife'); w.root.rotation.x = 0; w.lArmOverride = w.rArmOverride = false; w.lArm.rotation.x = 0; w.rArm.rotation.x = 0; w.root.position.set(1.6, 0, 2.9); s.wifeFollow = true;
    });
  }, 2.0);
  s.interact('hf-photo', V(8.4, 1.0, 0.4), () => (frame.visible && isT('hf-photo') ? 'برداشتن قاب عکس پدر' : null), () => { frame.visible = false; SF('photo'); audio.clink(V(8.4, 1, 0.3)); g.toast('قاب عکس پدرت را برداشتی'); }, 1.8);
  s.tasks = [
    { id: 'hf-wake', text: () => 'از پذیرایی صدای تلویزیون می‌آید. برو ببین', done: () => g.player.pos.x > 5.2 },
    { id: 'hf-watch', text: () => 'تلویزیون خودش روشن شده. نگاهش کن', done: () => watched > 4.5, start: () => { h.tv.play(FILMS.oldCar, 0xff9a8a); h.tv.set(true); g.onFrame((dt: number) => { if (!g.house) return false; if (g.isLooking(V(8.8, 1.38, 0.2), 0.9)) watched += dt; if (watched > 4.5) { s.think('این فیلم... از داخل ماشین پدرمه. همون جاده. همون شب.', 4); return false; } return true; }); } },
    { id: 'hf-off', text: () => 'تلویزیون را خاموش کن', done: () => F('off') },
    { id: 'hf-ext', text: () => 'کپسول آتش‌نشانی کنار در اتاق خواب است. برش دار', done: () => F('ext') },
    { id: 'hf-spray', text: () => 'آتش آشپزخانه را با کپسول خاموش کن', done: () => F('spray') },
    { id: 'hf-wife', text: () => 'سریع! مینا را بیدار کن', done: () => F('wife') },
    { id: 'hf-call', text: () => 'با موبایل (📱) به آتش‌نشانی ۱۲۵ زنگ بزن', done: () => !!s.f.hf_called },
    { id: 'hf-out', text: () => 'مینا را از خانه بیرون ببر (خم شو تا دود کمتری نفس بکشی)', done: () => w.root.position.x > 11.2 && g.player.pos.x > 11 },
    {
      id: 'hf-photo', text: () => 'مینا: «عکس پدرت!» برگرد و قاب عکس را از روی میز تلویزیون بیاور', done: () => F('photo'),
      start: () => { s.wifeFollow = false; w.root.position.set(13, 0, 4.5); w.root.rotation.y = -Math.PI / 2; s.wifeTalk(w, [['مینا', 'آرش! عکس پدرت... روی میز تلویزیون! تنها یادگاری که ازش داری...']]); },
    },
    {
      id: 'hf-escape', text: () => 'از خانه بیرون برو!', done: () => F('collapse'),
      start: () => {
        g.onFrame(() => {
          if (!g.house) return false;
          if (g.player.pos.x > 8.6 && Math.abs(g.player.pos.z - 3) < 1.3 && !F('collapse')) {
            SF('collapse'); audio.door(h.door.pos, false, true); audio.knock(h.door.pos, 1, 1.2); g.player.shake = 1.4; h.door.setOpen(false); h.door.locked = true;
            const beam = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, 2.4), mat({ color: 0x1a1008, rough: 1, key: 'charbeam' })); beam.position.set(9.4, 0.6, 3); beam.rotation.x = 0.5; h.dyn.add(beam);
            fireT = Math.max(fireT, 120);
            s.think('در... گیر کرد... نمی‌تونم نفس بکشم...', 3);
            return false;
          }
          return true;
        });
      },
    },
  ];
}
export async function faint(s: S) {
  const g = s.g;
  g.player.frozen = true; ui.set({ cutscene: true });
  for (let i = 0; i < 4; i++) { audio.cough(); await g.sleep(0.5); }
  await g.tween(2.5, (kk: number) => { g.player.pitch = -0.2 - kk * 0.9; g.player.pos.y = -kk * 1.2; g.canvas.style.filter = `blur(${2 + kk * 6}px) brightness(${0.8 - kk * 0.5})`; });
  audio.heartbeat(0.4); await g.sleep(0.8); audio.heartbeat(0.3);
  await g.fadeTo(1, 2);
  g.say('صدای مینا — از دور', 'آرش! آرش! چشماتو باز کن!...', 3.5);
  await g.sleep(3.5);
  g.canvas.style.filter = '';
}

// ---------- 10: the end ----------
export function ending(s: S) {
  const g = s.g; const h = g.house!; const k = 'en_';
  const F = (n: string) => !!s.f[k + n]; const SF = (n: string) => { s.f[k + n] = true; };
  const isT = (id: string) => s.tid() === id;
  g.player.hasFlash = true; h.tall.root.visible = false; h.setBlinds(0); h.items.envelope.visible = false; h.items.keys.visible = false; h.door.locked = true;
  h.lux.lamps.forEach((l: THREE.PointLight) => (l.intensity = 1.5));
  if (s.taskIndex === 0) { g.player.teleport(V(1.55, 0.75 - 1.62, 1.4), -Math.PI / 2); g.player.pitch = 1.1; s.card(`فصل ${fa(s.index)} — راز`, 'سه روز بعد', 4); g.after(2.5, async () => { g.player.frozen = true; await g.tween(1.6, (kk: number) => { g.player.pos.set(1.55 + kk * 0.6, -0.87 * (1 - kk), 1.4); g.player.pitch = 1.1 * (1 - kk); }); g.player.frozen = false; }); }
  else g.player.teleport(V(3.2, 0, 3), 0);
  const w = s.spawnWife('stand', V(2.5, 0, 2.3), Math.PI);
  const scorch = new THREE.MeshBasicMaterial({ map: tex.glow(), color: 0x000000, transparent: true, opacity: 0.85, depthWrite: false });
  for (const [x, z, sz] of [[7.4, 5.0, 3], [8.6, 4.2, 2], [6.4, 4.6, 2.2], [9.2, 2.8, 1.6]]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(sz, sz), scorch); p.rotation.x = -Math.PI / 2; p.position.set(x, 0.09, z); h.dyn.add(p); }
  for (const [x, y] of [[7.4, 2.0], [8.6, 1.6]]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(2, 1.6), scorch); p.position.set(x, y, 5.87); p.rotation.y = Math.PI; h.dyn.add(p); }
  const contract = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.41), new THREE.MeshStandardMaterial({ map: docs.contract(), roughness: 0.85, color: 0xb0a090 }));
  contract.rotation.set(-Math.PI / 2, 0, 0.4); contract.position.set(2.6, 0.585, 0.45); contract.visible = !F('tear'); h.dyn.add(contract);
  const newspaper = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.02, 0.22), new THREE.MeshStandardMaterial({ color: 0xe8e2d2, roughness: 0.9 }));
  newspaper.position.set(7.6, 0.77, 3.3); newspaper.visible = !F('paper'); h.dyn.add(newspaper);
  const father = new Humanoid({ skin: 0xc8a286, shirt: 0x1d3a6a, pants: 0x2a2a30, top: 'shirt', hairStyle: 'grey', hair: 0x9a9893, beard: 'mustache', age: 62, height: 1.74, photo: 'old' }, false);
  father.root.position.set(11.0, 0, 3.0); father.root.rotation.y = -Math.PI / 2; father.root.visible = false; h.dyn.add(father.root);
  s.interact('en-mina', V(2.5, 1.4, 2.3), () => (isT('en-wife') ? 'صحبت با مینا' : isT('en-truth') ? 'همه‌چیز را برای مینا تعریف کن' : null), () => {
    if (isT('en-wife')) s.wifeTalk(w, [['مینا', 'بیدار شدی... خدایا شکرت. سه روز تو کما بودی، آرش.'], ['مینا', 'آتش‌نشان‌ها تو رو جلوی در پیدا کردن. دستت مشت شده بود دور یه کاغذ سوخته... هر کاری کردن ولش نکردی.'], ['مینا', 'تو خواب اسم پدرت رو صدا می‌زدی. کاغذ رو گذاشتم روی میز کنار تخت.']], () => SF('wife'));
    else s.wifeTalk(w, [['آرش', 'مینا... اون پمپ بنزین واقعی بود. پدرم سی سال اونجا شیفت داد، به‌جای من.'], ['آرش', 'قبل از تولدم یه قرارداد امضا کرد. منو... برای شیفت شب.'], ['مینا', '...و حالا؟'], ['آرش', 'حالا تمومش می‌کنم.'], ['مینا', 'هر کاری بکنی، من کنارتم.']], () => SF('truth'));
  }, 2.2);
  s.interact('en-paper', V(7.6, 0.9, 3.3), () => (newspaper.visible && isT('en-paper') ? 'خواندن روزنامه' : null), () => { newspaper.visible = false; SF('paper'); g.showNote('روزنامه — سه روز بعد', `آتش‌سوزی در خیابان یاس: زوج جوان نجات یافتند\n\nآتش‌نشانان مردی ۲۹ ساله را بیهوش جلوی در خانه‌اش پیدا کردند. همسرش سالم است.\n\nدر خبری دیگر: ${s.f.freed ? 'چهار نفر که سال‌ها پیش در جاده‌ی قدیم گم شده بودند — حسین یزدانی، محمد رضایی، سارا کریمی و علی نوروزی — صبح امروز زنده پیدا شدند.' : 'پرونده‌ی گمشدگان جاده‌ی قدیم بار دیگر به جریان افتاد.'}`); }, 1.8);
  s.interact('en-tear', V(2.6, 0.75, 0.45), () => (contract.visible && isT('en-tear') ? 'پاره کردن قرارداد' : null), async () => {
    g.player.frozen = true; audio.staticBurst(0.5, 0.15); await g.sleep(0.4);
    contract.visible = false; SF('tear'); audio.scream(undefined, 0.25); audio.stinger(0.2); g.player.shake = 0.8;
    await g.sleep(1.2); g.player.frozen = false;
    s.think('...تموم شد. انگار یه چیزی از روی سینه‌م برداشته شد.', 4);
    audio.musicBox(undefined, 0.08);
  }, 1.8);
  s.interact('en-blinds', V(2.2, 1.6, 5.85), () => (isT('en-blinds') ? 'بالا کشیدن کرکره' : null), () => { g.tween(1.4, (kk: number) => h.setBlinds(kk)); audio.door(V(2.2, 1.6, 6), true); SF('blinds'); }, 1.9);
  s.interact('en-door', h.door.pos, () => (isT('en-door') ? 'باز کردن در' : null), () => {
    h.door.locked = false; h.door.setOpen(true); audio.bell(h.door.pos); father.root.visible = true; SF('door');
    g.after(1.5, () => { audio.voice(father.root.position.clone().setY(1.6), 95, 2, 0.1); g.say('پدر', '...آرش؟ پسرم؟', 3); });
    g.after(5, () => s.ending('truedawn'));
  }, 2.0);
  s.tasks = [
    { id: 'en-wake', text: () => 'از تخت بلند شو', done: () => g.player.pos.x > 1.95 && g.player.pos.y > -0.05 },
    { id: 'en-wife', text: () => 'مینا کنار تخت ایستاده. با او صحبت کن', done: () => F('wife') },
    { id: 'en-burn', text: () => 'برو آشپزخانه‌ی سوخته را ببین', done: () => g.player.pos.x > 6.4 && g.player.pos.z > 3.8 },
    { id: 'en-paper', text: () => 'روزنامه روی میز ناهارخوری است', done: () => F('paper') && !ui.get().note },
    { id: 'en-call', text: () => 'یک تماس بی‌پاسخ از پلیس داری. با موبایل (📱) به ۱۱۰ زنگ بزن', done: () => !!s.f.en_police },
    { id: 'en-truth', text: () => 'همه‌چیز را برای مینا تعریف کن', done: () => F('truth') },
    { id: 'en-tear', text: () => 'قرارداد سوخته روی میز کنار تخت است. پاره‌اش کن', done: () => F('tear') },
    { id: 'en-blinds', text: () => 'کرکره را بالا بکش. صبح شده', done: () => F('blinds') },
    { id: 'en-door', text: () => 'کسی پشت در است. در را باز کن', done: () => F('door') },
  ];
}
