// Scarier creature models (mobile friendly primitives + procedural flesh/fur/pale-skin textures)
import * as THREE from 'three';
import { Humanoid, type ShiftVariant } from './characters';
import { mat, tex } from './textures';
import { art } from './art';

const fleshM = () => mat({ map: art.flesh(), rough: 0.35, metal: 0.05, key: 'cr-flesh' });
const paleM = () => mat({ map: art.paleSkin(), rough: 0.55, key: 'cr-pale' });
const furM = () => mat({ map: art.fur(), rough: 1, key: 'cr-fur' });
const boneM = () => mat({ color: 0xd8cfb8, rough: 0.45, key: 'cr-bone' });
const black = new THREE.MeshBasicMaterial({ color: 0x000000 });

export function glowEye(parent: THREE.Object3D, x: number, y: number, z: number, color: number, size = 0.022, glow = 0.18) {
  const e = new THREE.Mesh(new THREE.SphereGeometry(size, 8, 6), new THREE.MeshBasicMaterial({ color }));
  e.position.set(x, y, z); parent.add(e);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex.glow(), color, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.9 }));
  sp.scale.setScalar(glow); e.add(sp);
  return e;
}
export function teeth(parent: THREE.Object3D, n: number, width: number, y: number, z: number, len: number, down = true, curve = 0.0) {
  const g = new THREE.ConeGeometry(len * 0.22, len, 4);
  const m = boneM();
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1) - 0.5; const tt = new THREE.Mesh(g, m);
    const l = 0.7 + Math.random() * 0.6;
    tt.scale.set(1, l, 1);
    tt.position.set(t * width, y + (down ? -len * l / 2 : len * l / 2), z - Math.abs(t) * curve);
    tt.rotation.z = down ? Math.PI : 0; tt.rotation.x = (Math.random() - 0.5) * 0.3;
    parent.add(tt);
  }
}
export function claws(arm: THREE.Object3D, n: number, len: number, y = -0.62, color = 0x1a1410) {
  const fm = mat({ color, rough: 0.5, key: 'claw' + color });
  const nail = boneM();
  // humanoids expose a jointed hand group – attach there so claws follow the elbow
  const target: THREE.Object3D = (arm.userData.hand as THREE.Object3D) ?? arm;
  const yy = arm.userData.hand ? -0.06 : y;
  if (arm.userData.hand) target.traverse((o) => { if (o.name === 'hand' && (o as THREE.Mesh).geometry.type === 'CapsuleGeometry' && o.scale.z < 0.5) { /* keep palm */ } else if (o.name === 'hand') o.visible = false; });
  for (let i = 0; i < n; i++) {
    const a = (i / Math.max(1, n - 1) - 0.5) * 0.9;
    const f = new THREE.Group(); f.position.set(Math.sin(a) * 0.04, yy, 0.02); f.rotation.z = a * 0.6; f.rotation.x = 0.25; target.add(f);
    const seg = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.011, len, 5), fm); seg.position.y = -len / 2; f.add(seg);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.009, 0.06, 4), nail); tip.position.y = -len - 0.025; tip.rotation.x = Math.PI; f.add(tip);
  }
}
function ribs(parent: THREE.Object3D, y: number, z: number, r: number, n = 5, m: THREE.Material = boneM()) {
  for (let i = 0; i < n; i++) {
    const rib = new THREE.Mesh(new THREE.TorusGeometry(r * (1 - i * 0.06), 0.014, 4, 12, Math.PI * 1.1), m);
    rib.position.set(0, y - i * 0.07, z); rib.rotation.set(Math.PI / 2, 0, -Math.PI * 0.05 - Math.PI * 0.5); rib.rotateZ(-Math.PI * 0.05);
    parent.add(rib);
  }
}
function spikes(parent: THREE.Object3D, y0: number, y1: number, z: number, n: number, len = 0.12) {
  const m = boneM();
  for (let i = 0; i < n; i++) { const s = new THREE.Mesh(new THREE.ConeGeometry(0.025, len * (0.6 + Math.random() * 0.8), 4), m); s.position.set(0, y0 + (y1 - y0) * (i / (n - 1)), z); s.rotation.x = -1.2; parent.add(s); }
}

// ================= Bipedal dog =================
export function buildDog(shadows = false) {
  const root = new THREE.Group();
  const fur = furM(), flesh = fleshM();
  const parts: Record<string, THREE.Object3D> = {};
  const m = (g: THREE.BufferGeometry, mm: THREE.Material, p: THREE.Object3D, x: number, y: number, z: number) => { const o = new THREE.Mesh(g, mm); o.position.set(x, y, z); o.castShadow = shadows; p.add(o); return o; };
  const body = new THREE.Group(); root.add(body); parts.body = body;
  // emaciated torso + exposed ribcage
  const torso = m(new THREE.CapsuleGeometry(0.18, 0.7, 4, 10), fur, body, 0, 1.55, 0.05); torso.rotation.x = 0.4; torso.scale.set(1, 1, 0.8);
  const belly = m(new THREE.SphereGeometry(0.16, 10, 8), flesh, body, 0, 1.38, 0.12); belly.scale.set(1, 1.3, 0.7);
  ribs(body, 1.7, 0.17, 0.2, 6);
  m(new THREE.SphereGeometry(0.28, 10, 8), fur, body, 0, 1.88, 0.12).scale.set(1.25, 0.75, 0.95); // shoulder hump
  spikes(body, 1.3, 2.05, -0.12, 7, 0.14);
  ['l', 'r'].forEach((s, i) => {
    const sx = i ? 1 : -1;
    const hip = new THREE.Group(); hip.position.set(sx * 0.15, 1.12, 0); body.add(hip); parts[s + 'Leg'] = hip;
    const th = m(new THREE.CapsuleGeometry(0.09, 0.45, 3, 8), fur, hip, 0, -0.22, 0.12); th.rotation.x = -0.6;
    const shin = m(new THREE.CapsuleGeometry(0.05, 0.5, 3, 6), fur, hip, 0, -0.66, 0.08); shin.rotation.x = 0.6;
    const foot = m(new THREE.CapsuleGeometry(0.04, 0.2, 3, 6), fur, hip, 0, -1.02, 0.14); foot.rotation.x = 1.4;
    for (let k = -1; k <= 1; k++) { const c = m(new THREE.ConeGeometry(0.014, 0.08, 4), boneM(), hip, k * 0.03, -1.07, 0.3); c.rotation.x = Math.PI / 2; }
    const sh = new THREE.Group(); sh.position.set(sx * 0.33, 1.85, 0.22); body.add(sh); parts[s + 'Arm'] = sh;
    m(new THREE.CapsuleGeometry(0.055, 0.5, 3, 6), fur, sh, 0, -0.3, 0);
    const fore = m(new THREE.CapsuleGeometry(0.04, 0.5, 3, 6), fur, sh, 0, -0.85, 0.05); fore.rotation.x = -0.1;
    claws(sh, 4, 0.16, -1.15, 0x221a14);
  });
  // long neck + elongated canine skull
  const neck = new THREE.Group(); neck.position.set(0, 2.0, 0.34); body.add(neck); parts.neck = neck;
  const nk = m(new THREE.CapsuleGeometry(0.07, 0.22, 3, 8), fur, neck, 0, -0.04, -0.05); nk.rotation.x = 0.9;
  const skull = m(new THREE.SphereGeometry(0.15, 12, 10), fur, neck, 0, 0.06, 0.08); skull.scale.set(0.85, 0.8, 1.15);
  const snout = m(new THREE.CylinderGeometry(0.045, 0.085, 0.36, 7), fur, neck, 0, 0.02, 0.34); snout.rotation.x = Math.PI / 2 + 0.08;
  m(new THREE.SphereGeometry(0.035, 6, 5), black, neck, 0, 0.04, 0.53);
  const gum = m(new THREE.BoxGeometry(0.1, 0.02, 0.32), flesh, neck, 0, -0.03, 0.34); gum.rotation.x = 0.08;
  teeth(neck, 9, 0.08, -0.035, 0.47, 0.05, true, 0.25);
  const jaw = new THREE.Group(); jaw.position.set(0, -0.06, 0.2); neck.add(jaw); parts.jaw = jaw;
  m(new THREE.BoxGeometry(0.085, 0.035, 0.3), fur, jaw, 0, -0.02, 0.13);
  m(new THREE.BoxGeometry(0.07, 0.01, 0.28), flesh, jaw, 0, 0.0, 0.13);
  teeth(jaw, 8, 0.07, 0.0, 0.24, 0.045, false, 0.2);
  const tongue = m(new THREE.CapsuleGeometry(0.02, 0.18, 3, 6), mat({ color: 0x6a1820, rough: 0.3, key: 'tongue' }), jaw, 0.02, -0.05, 0.28); tongue.rotation.x = 1.9;
  [-1, 1].forEach((sd) => {
    const ear = m(new THREE.ConeGeometry(0.05, 0.22, 4), fur, neck, sd * 0.1, 0.22, 0.0); ear.rotation.set(-0.4, 0, -sd * 0.35); ear.scale.z = 0.4;
    glowEye(neck, sd * 0.075, 0.1, 0.19, 0xffc84a, 0.022, 0.16);
  });
  return { root, parts };
}

// ================= Tall Man =================
export function buildTallMan(shadows = false) {
  const h = new Humanoid({ skin: 0xd8d4cc, shirt: 0x0c0c0e, pants: 0x0a0a0c, shoes: 0x050505, hairStyle: 'bald', height: 3.1, build: 0.56, eyes: 'none', top: 'suit', sleeves: 'long' }, shadows);
  h.lArm.scale.y = 1.55; h.rArm.scale.y = 1.55;
  const porcelain = mat({ map: art.paleSkin(), color: 0xf0ece4, rough: 0.25, key: 'porcelain' });
  h.headMesh.material = porcelain; h.headMesh.scale.set(0.78, 1.3, 0.9);
  h.meshes.forEach((me) => { if (me.material === h.skinMat && me.name !== 'hand') me.material = porcelain; });
  // hollow eye sockets
  [-1, 1].forEach((s) => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), black); e.position.set(s * 0.042, 0.03, 0.085); e.scale.set(1, 1.5, 0.6); h.head.add(e); glowEye(h.head, s * 0.042, 0.02, 0.1, 0xffffff, 0.006, 0.05); });
  // ear-to-ear grin
  const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 6), black); mouth.position.set(0, -0.075, 0.08); mouth.scale.set(1.5, 0.35, 0.5); h.head.add(mouth);
  teeth(h.head, 12, 0.15, -0.065, 0.1, 0.022, true, 0.03);
  teeth(h.head, 12, 0.14, -0.09, 0.1, 0.018, false, 0.03);
  // cracks
  const crack = mat({ color: 0x1a1a1a, key: 'crack' });
  for (let i = 0; i < 3; i++) { const c = new THREE.Mesh(new THREE.BoxGeometry(0.004, 0.08, 0.004), crack); c.position.set(-0.03 + i * 0.03, 0.08, 0.1); c.rotation.z = (Math.random() - 0.5) * 1.2; h.head.add(c); }
  // collar + tie

  claws(h.lArm, 5, 0.26, -0.62, 0xd8d4cc); claws(h.rArm, 5, 0.26, -0.62, 0xd8d4cc);
  h.neck.rotation.z = 0.28;
  return h;
}

// ================= Faceless =================
export function buildFaceless(shadows = false) {
  const h = new Humanoid({ skin: 0xc8a888, shirt: 0x2d2d33, pants: 0x1d1d22, hairStyle: 'hood', faceless: true, build: 0.95, height: 1.85 }, shadows);
  h.lArm.scale.y = 1.3; h.rArm.scale.y = 1.3;
  claws(h.lArm, 5, 0.18, -0.62, 0xb8b0a0); claws(h.rArm, 5, 0.18, -0.62, 0xb8b0a0);
  [-1, 1].forEach((s) => glowEye(h.head, s * 0.04, 0.0, 0.13, 0xd8e8ff, 0.005, 0.045));
  h.body.rotation.x = 0.08;
  return h;
}

// ================= Watcher (behind glass) =================
export function buildWatcher(shadows = false) {
  const h = new Humanoid({ skin: 0xbfc3c4, shirt: 0x8a8f90, pants: 0x4f5253, hairStyle: 'bald', eyes: 'none', build: 0.72, height: 1.95 }, shadows);
  const pale = paleM();
  h.meshes.forEach((me) => { if (me.material === h.skinMat) me.material = pale; });
  h.headMesh.material = pale; h.headMesh.scale.set(0.85, 1.25, 0.95);
  h.torso.material = pale;
  ribs(h.body, 1.38, 0.1, 0.17, 5);
  [-1, 1].forEach((s) => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 6), black); e.position.set(s * 0.04, 0.03, 0.09); e.scale.set(1, 1.4, 0.5); h.head.add(e); glowEye(h.head, s * 0.04, 0.03, 0.105, 0xfff0c0, 0.01, 0.08); });
  const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), black); mouth.position.set(0, -0.1, 0.075); mouth.scale.set(0.7, 1.9, 0.5); h.head.add(mouth);
  claws(h.lArm, 5, 0.2, -0.62, 0xbfc3c4); claws(h.rArm, 5, 0.2, -0.62, 0xbfc3c4);
  h.lArm.rotation.x = -2.5; h.rArm.rotation.x = -2.5; h.lArm.rotation.z = -0.3; h.rArm.rotation.z = 0.3; h.lArmOverride = true; h.rArmOverride = true;
  return h;
}

// ================= Shapeshifter mutation =================
export function transformHuman(h: Humanoid, v: ShiftVariant) {
  const flesh = fleshM(); const pale = paleM();
  h.meshes.forEach((m) => { if (m.material === h.skinMat) m.material = pale; });
  h.headMesh.material = pale;
  h.torso.material = flesh;
  ribs(h.body, 1.38, 0.11, 0.18, 5);
  spikes(h.body, 0.95, 1.5, -0.14, 6, 0.14);
  claws(h.lArm, 4, 0.22); claws(h.rArm, 4, 0.22);
  // a second, thinner pair of arms bursting from the ribs (not for the crawler)
  if (v !== 'crawler') {
    for (const s of [-1, 1]) {
      const sh = new THREE.Group(); sh.position.set(s * 0.15, 1.18, 0.06); sh.rotation.set(-0.9, 0, s * 0.5); h.body.add(sh);
      const up = new THREE.Mesh(new THREE.CapsuleGeometry(0.022, 0.32, 3, 6), pale); up.position.y = -0.18; sh.add(up);
      const el = new THREE.Group(); el.position.y = -0.36; el.rotation.x = -1.1; sh.add(el);
      const fo = new THREE.Mesh(new THREE.CapsuleGeometry(0.018, 0.34, 3, 6), pale); fo.position.y = -0.18; el.add(fo);
      const hand = new THREE.Group(); hand.position.y = -0.37; el.add(hand);
      claws(hand, 4, 0.14, 0, 0x2a1a14);
      const wound = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6), flesh); wound.position.set(s * 0.15, 1.18, 0.09); wound.scale.set(1, 1.4, 0.5); h.body.add(wound);
    }
  }
  const eye = (x: number, y: number, z: number) => glowEye(h.head, x, y, z, 0xff2a10, 0.02, 0.12);
  if (v === 'stretch') {
    h.lArm.scale.y = 2.2; h.rArm.scale.y = 2.2;
    h.neck.position.y = 1.72; h.neck.scale.y = 2.4; h.head.scale.y = 0.42;
    h.neck.rotation.z = 1.3; h.body.scale.y *= 1.3;
    h.head.rotation.z = Math.PI; // upside down
    eye(-0.04, 0.03, 0.11); eye(0.04, 0.03, 0.11); eye(0, 0.08, 0.1);
    const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 6), black); mouth.position.set(0, -0.06, 0.09); mouth.scale.set(1.4, 0.6, 0.5); h.head.add(mouth);
    teeth(h.head, 10, 0.1, -0.05, 0.11, 0.02, true, 0.02);
  } else if (v === 'maw') {
    h.headMesh.scale.set(1.5, 1.9, 1.5);
    // vertical split mouth with teeth rings
    const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 10), new THREE.MeshBasicMaterial({ color: 0x140000 }));
    mouth.position.set(0, -0.04, 0.12); mouth.scale.set(0.9, 1.9, 0.6); h.head.add(mouth);
    for (let i = 0; i < 16; i++) {
      const t = new THREE.Mesh(new THREE.ConeGeometry(0.012, 0.07, 4), boneM());
      const a = (i / 16) * Math.PI * 2; t.position.set(Math.cos(a) * 0.085, -0.04 + Math.sin(a) * 0.17, 0.16); t.rotation.z = a + Math.PI / 2; h.head.add(t);
    }
    const tongue = new THREE.Mesh(new THREE.CapsuleGeometry(0.02, 0.3, 3, 6), flesh); tongue.position.set(0, -0.3, 0.16); h.head.add(tongue);
    eye(-0.09, 0.14, 0.11); eye(0.09, 0.14, 0.11); eye(0.06, 0.2, 0.08);
    h.lArm.scale.y = 1.5; h.rArm.scale.y = 1.5;
  } else {
    h.body.rotation.x = 1.25; h.body.position.z = -0.4;
    h.lArm.rotation.x = -1.3; h.rArm.rotation.x = -1.3; h.lArmOverride = true; h.rArmOverride = true;
    h.lArm.scale.y = 1.7; h.rArm.scale.y = 1.7;
    h.neck.rotation.x = -1.6; h.head.rotation.z = Math.PI;
    eye(-0.04, 0.03, 0.115); eye(0.04, 0.03, 0.115);
    const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 6), black); mouth.position.set(0, -0.07, 0.09); mouth.scale.set(1.2, 1.2, 0.5); h.head.add(mouth);
    teeth(h.head, 8, 0.08, -0.04, 0.11, 0.025, true, 0.02);
  }
}
