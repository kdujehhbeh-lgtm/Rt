// Story / mission system: 5 chapters, tasks, scripted sequences, notes, phone calls and multiple endings
import * as THREE from 'three';
import { ui, unlockEnding, clearSave, getEndings } from './store';
import { audio, type LoopHandle } from './audio';
import type { Game } from './game';
import type { Door } from './world';
import type { Customer } from './npc';
import { DogMonster, FacelessMonster, ShifterMonster, TallMonster } from './monsters';
import { Humanoid } from './characters';
import { buildFaceless } from './creatures';
import { makeHotdog } from './props';
import type { DriveMode } from './levels/drive';
import { tex, mat } from './textures';
import { CHAPTERS, LAST_CHAPTER, type ChapterDef, type Setup, type Theme } from './chapters';
import { writeSave } from './store';
import { ARCHETYPES } from './characters';
import { transformHuman } from './creatures';
import { torchStand, flareMesh, keyModel, type Torch } from './props';
import { art } from './art';
import { docs } from './docs';
import { withPhoto } from './posters';
import { registerLight } from './lightpool';
import * as home from './storyHome';
import { jerryCan } from './storeRevamp';
void art; void withPhoto; void keyModel; void mat; void docs;

interface TaskDef { id: string; text: () => string; done: () => boolean; start?: () => void }

const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
const yawTo = (from: THREE.Vector3, to: THREE.Vector3) => Math.atan2(-(to.x - from.x), -(to.z - from.z));
const FA = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
const fa = (n: number | string) => String(n).replace(/\d/g, (d) => FA[+d]);

export const ITEM_NAMES: Record<string, string> = { soda: 'جعبه نوشابه', mop: 'تی', trash: 'کیسه زباله', order: 'سفارش مشتری', fuel: 'گالن بنزین', bottle: 'بطری (پرتاب)', donutbox: 'جعبه دونات', sausage: 'بسته سوسیس', hotdog: 'هات‌داگ', wrench: 'آچار', chips: 'کارتن چیپس و پفک', flare: 'مشعل', coffee: 'قهوه', 'nh-key': 'کلید زنگ‌زده', wallet: 'کیف پول', tube: 'لامپ مهتابی', jerry: 'گالن بنزین (پر)', jerryEmpty: 'گالن خالی' };

export const NOTES: Record<number, { title: string; body: string }> = {
  1: {
    title: 'قوانین شیفت شب — دست‌نویس، نیمه‌پاره',
    body: '۱. چراغ‌ها همیشه روشن بمانند. همیشه.\n\n۲. با بعضی از مشتری‌ها ... [پاره شده] ... فقط حساب کن.\n\n۳. اگر کسی پشت شیشه ایستاده بود، در را ... [لکه‌ی قهوه]\n\n۴. به ... خیره نشو. [ناخوانا]\n\n۵. اگر تلفن بعد از ساعت ۴ زنگ زد ... [بقیه‌اش کنده شده]\n\n۶. هر اتفاقی افتاد، تا صبح دوام بیار.',
  },
  2: {
    title: 'یادداشت کارمند قبلی — م. رضایی',
    body: 'شب نهم.\n\nدیگه مطمئنم. اونا از زیر دفتر مدیر میان. هر بار که پمپ‌ها شب کار می‌کنن، یه چیزی اون پایین بیدار می‌شه. صدای نفسش از لوله‌ها میاد.\n\nمدیر می‌گه خیالاتی شدم. ولی خودش هیچ‌وقت شب نمیاد.\n\nاون مرد بلند... هر شب کنار جاده‌ست. فکر کنم اونم یه زمانی اینجا کار می‌کرد.\n\nاگه اینو پیدا کردی، از کسی که صورت نداره سؤال نپرس.',
  },
  3: {
    title: 'دفترچه‌ی مدیر — ۱۳۶۶',
    body: 'پمپ رو روی یه چاه قدیمی ساختیم. وقتی مخزن اصلی رو کار گذاشتیم، چیزی اون پایین بود. زنده بود.\n\nیه معامله کردیم. اون پمپ رو پر از مشتری نگه می‌داره، فروش هیچ‌وقت کم نمی‌شه... و در عوض، هر چند وقت یه بار، یه کارمند شیفت شب.\n\nاونایی که می‌بینی — مشتری‌های عجیب، سگ، مرد بلند — همه‌شون کارمندای قبلی‌ان. یا کسایی که زیادی سؤال پرسیدن.\n\nآگهی استخدام رو خودش می‌نویسه. تلفن ساعت دو هم خودشه.\n\nاگه داری اینو می‌خونی، اون تو رو انتخاب کرده. قلبش زیر همین اتاقه. آتیش تنها چیزیه که ازش می‌ترسه.',
  },
  5: {
    title: 'نامه‌ی استخدام — پمپ بنزین پترو ۲۴',
    body: 'کارمند گرامی،\n\nبا سلام. به خانواده‌ی پترو ۲۴ خوش آمدید. شما از میان «تعداد زیادی» متقاضی انتخاب شده‌اید.\n\n• ساعت شروع شیفت: ۳ بامداد\n• لباس فرم در کمد شما قرار داده شده است.\n• کلید فروشگاه زیر پادری ورودی است.\n\nلطفاً به خاطر داشته باشید:\nترک محل کار پیش از طلوع آفتاب، فسخ قرارداد محسوب می‌شود.\n\nبا احترام،\nمدیریت\n\n(پشت نامه، با مداد و خطی لرزان:)\n«ما نمی‌دونستیم. هیچ‌کدوممون نمی‌دونستیم. اسم‌هامون رو فراموش نکن.»',
  },
  4: {
    title: 'برگه‌ای زیر برف‌پاک‌کن ماشینت',
    body: 'گمشده\n\nکارمند جدید شیفت شب — پمپ بنزین پترو ۲۴\n\nعکسی ندارد. جای صورت، یک لکه‌ی سیاه.\n\nآخرین بار دیده شده: امشب، ساعت ۳ بامداد\n\nپشت برگه با خطی لرزان نوشته شده:\n«من هم ماشینم رو همین‌جا پارک کرده بودم. هیچ‌وقت سوارش نشدم.\nاگه می‌خوای بری، قبل از طلوع برو. و هرگز به آینه‌ی عقب نگاه نکن.»',
  },
};

const ENDINGS: Record<string, { title: string; text: string }> = {
  truedawn: { title: 'پایان: صبح', text: 'در را باز کردی. هوای صبح بوی باران می‌داد، نه بنزین و دود.\n\nروی پله‌ی جلوی در، مردی شصت‌ساله ایستاده بود. لباس فرم کهنه‌ی پترو ۲۴ تنش بود و برای اولین بار بعد از سی سال، صورت داشت؛ صورتی که از عکس قدیمی مادرت می‌شناختی.\n\n«آرش؟ ... چقدر بزرگ شدی.»\n\nمینا دستت را گرفت. پدرت جلو آمد و هر سه، بی‌حرف، در آستانه‌ی خانه‌ای نیمه‌سوخته ایستادید.\n\nپمپ بنزین پترو ۲۴ از فراموشی تغذیه می‌کرد؛ از آدم‌هایی که فکر می‌کرد کسی دنبالشان نمی‌گردد. پدرت سی سال به‌جای تو شب را تحمل کرد. تو فقط یک شب دوام آوردی… اما همان یک شب کافی بود تا قرارداد را با دست خودت پاره کنی.\n\nآن شب، و هیچ شب دیگری، تلفن ساعت دو زنگ نزد.\n\n— پایان —' },
  awake: { title: 'پایان: بیداری', text: 'در را باز کردی و نور صبح صورتت را گرم کرد.\n\nقرارداد پاره شده بود و پدرت آزاد شد. اما آن چهار نفر هنوز نامی نداشتند. هنوز جایی میان دود منتظر بودند.\n\nحالا راز را می‌دانی: پمپ از فراموشی تغذیه می‌کرد. از آدم‌هایی که کسی دنبالشان نمی‌گشت.\n\nشاید یک روز برگردی و نامشان را برایشان پس بیاوری.\n\n— اتمام —' },
  manager: { title: 'پایان: مدیر جدید', text: 'خودکار را برداشتی و جای «جانشین» را امضا کردی.\n\nپدرت آرام بلند شد. صورتش برگشت و از در بیرون رفت، به سمت صبحی که سی سال ندیده بود.\n\nتو پشت میز ماندی. ساعت دو شد و تلفن را برداشتی. شماره‌ای ناشناس را گرفتی.\n\n«سلام... برای شیفت شب پمپ بنزین پترو ۲۴ تماس می‌گیرم. کار آسونیه. حقوقش هم خوبه.»' },
  release: { title: 'پایان: رهایی', text: 'وقتی آخرین کارت نام را کنار قلب گذاشتی، صدای نفس‌ها قطع شد. فقط چهار زمزمه ماند: «ممنون.»\n\nشعله‌ها بالا رفتند و در آینه‌ی ماشین، چهار سایه را دیدی که از میان دود بیرون می‌آمدند. این بار به سمت تو نمی‌آمدند؛ به سمت طلوع می‌رفتند.\n\nسه روز بعد، رادیو گفت: «چهار نفر که سال‌ها گمشده بودند، صبح زود کنار جاده‌ی قدیم پیدا شدند. هیچ‌کدام چیزی به یاد ندارند… جز یک اسم: پترو ۲۴.»\n\nپوسترهای روی تیرهای چراغ برق، یکی‌یکی کنده شدند.\n\nپمپ بنزین آن کسانی را انتخاب می‌کرد که فکر می‌کرد هیچ‌کس دنبالشان نمی‌گردد. تو دنبالشان گشتی. نامشان را به یاد آوردی. و همین، زنجیرشان را شکست.' },
  fire: { title: 'پایان: آتش', text: 'شعله‌ها از دریچه بیرون زدند و صدای جیغی از زیر زمین بلند شد که هرگز فراموشش نمی‌کنی.\n\nپمپ بنزین در آینه‌ی ماشین می‌سوخت. سایه‌ها در میان دود ایستاده بودند و تماشایت می‌کردند. نرفتند. نمی‌توانستند بروند.\n\nآن هیولا مُرد، اما زندانی‌هایش هنوز اسمی نداشتند. هیچ‌کس نامشان را برایشان پس نیاورده بود.\n\nهر سال، همان شب، کنار خرابه‌ی پمپ چهار نفر می‌ایستند و منتظرند.\n\n(کارت‌های نام کارمندان گمشده… هنوز جایی در پمپ هستند.)' },
  dawn: { title: 'پایان: سپیده‌دم', text: 'تا وقتی به شهر رسیدی، آسمان روشن شده بود. زنده ماندی.\n\nهیچ‌وقت برنگشتی. حقوقت را هم نگرفتی.\n\nیک هفته بعد، روی همان تیر چراغ برق کنار خانه‌ات، آگهی تازه‌ای چسبانده بودند: «استخدام فوری — کارمند شیفت شب.»\n\nو هر شب، ساعت دو بامداد، تلفنت زنگ می‌خورد. تو فرار کردی، اما پمپ هنوز گرسنه است. یک نفر دیگر جواب خواهد داد.' },
  passenger: { title: 'پایان: مسافر', text: 'جاده خالی بود. نفس راحتی کشیدی.\n\nبعد، در آینه‌ی عقب، چیزی را دیدی که صورت نداشت.\n\n«تو زیادی سؤال پرسیدی.»' },
  eternal: { title: 'پایان: شیفت ابدی', text: 'خودکار روی کاغذ لغزید. جوهرش قرمز بود.\n\nصبح که کارمند جدید آمد، یک مشتری ساکت کنار قفسه‌ها ایستاده بود. لباس فرم پمپ بنزین را پوشیده بود.\n\nصورت نداشت.' },
};

export class Story {
  chapter = 1;
  taskIndex = 0;
  tasks: TaskDef[] = [];
  allowRandomCustomers = false;
  phoneBusy = false;
  doorPrompt?: (d: Door) => string | null | undefined;
  doorAction?: (d: Door) => boolean;
  served = 0;
  clockStart = 120; clockSpan = 60; clockT = 0;
  phoneRing: LoopHandle | null = null;
  phoneMode: 'random' | 'script' | null = null;
  private noteCb: (() => void) | null = null;
  private cctvFigure: Humanoid | null = null;
  private seq: (() => Customer)[] = [];
  private ended = false;
  private advancing = false;
  private shifter: Customer | null = null;
  private fireActive = false;
  constructor(private g: Game) {}

  get f() { return this.g.save.flags; }
  get st() { return this.g.station!; }

  clockText() {
    const m = this.clockStart + Math.min(this.clockSpan - 1, Math.floor(this.clockT / 12));
    return fa(`${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`);
  }

  index = 1;
  setupKey: Setup = 'home1';
  def: ChapterDef = CHAPTERS[1];
  start(index: number, task: number) {
    const C = CHAPTERS[index] ?? CHAPTERS[1];
    this.index = index; this.def = C; this.setupKey = C.setup;
    const ch = C.act;
    this.chapter = ch; this.taskIndex = task; this.ended = false; this.advancing = false;
    this.torches = []; this.statues = []; this.shRing?.stop(0.1); this.shRing = null;
    this.served = 0; this.clockT = task * 60; this.seq = []; this.shifter = null; this.fireActive = false;
    this.phoneRing = null; this.phoneMode = null; this.phoneBusy = false; this.noteCb = null; this.cctvFigure = null;
    this.fireFull = false; this.escaping = false; this.drivingDone = false; this.lookedBack = false; this.backLockFn = null; this.lockingBack = false; this.blindsUp = false; this.tvNoise = null;
    this.doorPrompt = undefined; this.doorAction = undefined; this.allowRandomCustomers = false;
    this.g.director.reset(false);
    ui.set({ cutscene: false, skippable: false, fade: 0, title: false });
    switch (C.setup) {
      case 'home1': this.setupCh1(); break;
      case 'homeDay': this.setupMorning(); break;
      case 'homeFire': this.setupHomeFire(); break;
      case 'finale': this.setupEnding(); break;
      default:
        if (C.setup === 'shift' || C.setup === 'nmStation' || C.setup === 'nmBasement') { this.f.storeOpen = true; this.f.power = true; this.f.powerOut = false; }
        this.setupStationCommon();
        if (C.setup === 'ch2') this.setupCh2(); else if (C.setup === 'ch3') this.setupCh3(); else if (C.setup === 'ch4') this.setupCh4();
        else if (C.setup === 'ch5') this.setupCh5(); else if (C.setup === 'shift') this.setupShift(C);
        else if (C.setup === 'nmStation') this.setupNightmareStation(); else this.setupNightmareBasement();
    }
    if (C.clock) this.clockStart = C.clock;
    if (C.nightmare) this.nightmareVoices();
    this.restoreItem();
    this.beginTask();
    this.g.checkpoint();
  }

  private beginTask() {
    const t = this.tasks[this.taskIndex];
    if (!t) return;
    t.start?.();
    this.g.setObjective(t.text());
  }

  update(dt: number) {
    this.clockT += dt;
    this.tickExtras(dt);
    const t = this.tasks[this.taskIndex];
    if (!t || this.ended || this.advancing) return;
    const txt = t.text();
    if (ui.get().objective !== txt) ui.set({ objective: txt });
    if (t.done()) {
      this.advancing = true;
      audio.click();
      this.g.after(0.8, () => {
        this.advancing = false;
        this.taskIndex++;
        if (this.taskIndex >= this.tasks.length) { this.g.setObjective(null); this.chapterEnd(); }
        else { this.g.checkpoint(); this.beginTask(); }
      });
    }
    if (this.fireActive) this.updateFire(dt);
  }

  // ======================= helpers =======================
  private pick(id: string, src: THREE.Object3D, _scale = 0.6) {
    // animated, size-normalised pickup (see Game.pickUp / Player.setHeld)
    this.g.pickUp(id, src);
  }
  private restoreItem() {
    const it = this.g.save.item; if (!it || !this.g.station) { if (it && this.chapter === 1) this.g.setItem(null); return; }
    const src = this.st.items[it]; if (src) this.pick(it, src, it === 'mop' ? 0.5 : 0.6); else this.g.setItem(null);
  }
  private interact(id: string, pos: THREE.Vector3, prompt: () => string | null, action: () => void, range = 1.9, priority?: number) {
    // mission-specific interactions always beat generic ones at the same spot (e.g. coffee machine)
    const pr = priority ?? (/^(sh|nh|ns|nb|fi|hd)-/.test(id) ? 1 : 0);
    this.g.addInteract({ id, pos, prompt, action, range, priority: pr });
  }

  /** animated brew at the COFFEE machine: cup appears under the brew head, fills, steams, then goes to the hand */
  private brewing = false;
  async brewCoffee(): Promise<boolean> {
    const g = this.g; const st = g.station; if (!st || this.brewing) return false;
    this.brewing = true; g.player.frozen = true;
    const cupG = new THREE.Group(); cupG.position.set(13.33, 1.0, 2.55); st.dyn.add(cupG);
    const shell = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.032, 0.1, 14, 1, true), new THREE.MeshStandardMaterial({ color: 0xf4efe6, roughness: 0.6, side: THREE.DoubleSide })); shell.position.y = 0.05; cupG.add(shell);
    const bottom = new THREE.Mesh(new THREE.CircleGeometry(0.032, 14), shell.material); bottom.rotation.x = -Math.PI / 2; bottom.position.y = 0.002; cupG.add(bottom);
    const liquid = new THREE.Mesh(new THREE.CylinderGeometry(0.037, 0.033, 1, 14), new THREE.MeshStandardMaterial({ color: 0x2a1206, roughness: 0.15 })); liquid.scale.y = 0.001; cupG.add(liquid);
    const stream = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.16, 6), liquid.material); stream.position.y = 0.2; stream.visible = false; cupG.add(stream);
    const steamM = new THREE.SpriteMaterial({ map: tex.glow(), color: 0xdddddd, transparent: true, opacity: 0, depthWrite: false });
    const steam = [0, 1, 2].map(() => { const s = new THREE.Sprite(steamM); s.scale.setScalar(0.07); cupG.add(s); return s; });
    audio.click(); audio.beep(cupG.position);
    const hum = audio.hum(cupG.position.clone(), 95, 0.05);
    g.toast('☕ در حال دم کردن قهوه...', 3);
    await g.tween(3.2, (k) => {
      stream.visible = k > 0.1 && k < 0.92;
      const fill = Math.min(1, Math.max(0, (k - 0.12) / 0.8)) * 0.085;
      liquid.scale.y = Math.max(0.001, fill); liquid.position.y = fill / 2 + 0.003;
      steamM.opacity = Math.min(0.5, k * 0.6);
      steam.forEach((s, i) => { const t = (k * 3 + i / 3) % 1; s.position.set(Math.sin(t * 6 + i) * 0.01, 0.1 + t * 0.15, 0); s.scale.setScalar(0.05 + t * 0.08); });
    });
    hum?.stop(0.3); audio.clink(cupG.position);
    st.dyn.remove(cupG);
    g.player.frozen = false; this.brewing = false;
    return true;
  }
  private card(title: string, sub: string, dur = 3.5) { ui.set({ chapterCard: { title, sub } }); this.g.after(dur, () => ui.set({ chapterCard: null })); }
  private think(t: string, d = 3) { this.g.say(undefined, t, d); }

  private powerAll(on: boolean, flick = false) {
    const L = this.st.lights;
    ['sales', 'storage', 'staff', 'corridor', 'toilet', 'canopy', 'sign'].forEach((n) => { L[n]?.set(on); if (on && flick) L[n]?.flicker(0.8 + Math.random() * 0.8); });
  }

  // ======================= CHAPTER 1 – home =======================
  private setupCh1() {
    const g = this.g; const h = g.house!;
    this.clockStart = 120; this.clockSpan = 30;
    g.player.hasFlash = !!this.f.h_phone;
    if (this.f.h_phone) h.items.phone.visible = false;
    if (this.f.h_keys) h.items.keys.visible = false;
    let alarm: LoopHandle | null = null;
    if (!this.f.h_phone) alarm = audio.ring(h.a.phone, 'alarm');
    this.interact('phone', h.a.phone, () => (this.f.h_phone ? null : 'برداشتن تلفن'), () => {
      this.f.h_phone = true; h.items.phone.visible = false; alarm?.stop(); audio.click();
      g.player.hasFlash = true;
      g.showMessage('شیفت شب پمپ بنزین از ساعت ۳ شروع می‌شود.', 5).then(() => g.toast('چراغ‌قوه‌ی گوشی: دکمه 🔦', 3.5));
    });
    this.interact('keys', h.a.keys, () => (this.f.h_keys ? null : 'برداشتن کلید ماشین'), () => { this.f.h_keys = true; h.items.keys.visible = false; audio.clink(); this.think('کلیدها... بریم.'); });
    this.interact('hdoor', h.door.pos, () => {
      if (this.tid() === 'lockdoor' && g.player.pos.x > 10.1) return h.door.open ? 'بستن و قفل کردن در خانه' : 'قفل کردن در خانه';
      if (this.f.h_locked) return 'قفل است';
      return h.door.open ? 'بستن در' : 'باز کردن در';
    }, async () => {
      if (this.tid() === 'lockdoor' && g.player.pos.x > 10.1) {
        h.door.setOpen(false); await g.sleep(0.6); audio.clink(h.door.pos); h.door.locked = true; this.f.h_locked = true;
        g.after(1.2, () => { audio.knock(h.door.pos, 3, 0.5, 0.35); this.think('...از داخل خونه کسی در زد؟ خونه که خالیه.', 3.5); });
        return;
      }
      if (this.f.h_locked) return;
      h.door.toggle();
    }, 2);
    this.interact('car', h.a.car, () => (this.tid() === 'car' ? 'سوار شدن' : this.f.h_keys ? null : 'کلید ماشین لازم است'), () => { if (this.tid() === 'car') this.f.h_car = true; }, 2.4);
    if (this.f.h_window) h.setBlinds(1);
    if (this.f.h_uniform) h.items.uniform.visible = false;
    h.items.envelope.visible = false; // pushed under the door during the 'letter' task
    if (this.f.h_locked) h.door.locked = true;
    // TV switches itself on
    // Mina asleep on her side of the bed
    const wife = this.spawnWife('sleep');
    this.interact('wife1', V(0.6, 0.9, 1.4), () => (this.tid() === 'wife' ? 'بیدار کردن مینا' : null), () => {
      this.wifeTalk(wife, [
        ['مینا', '...آرش؟ ساعت دو شبه... کجا داری میری؟'],
        ['آرش', 'از پمپ بنزین زنگ زدن. گفتن شیفت شب از امشب شروع میشه. حقوقش خوبه، مینا.'],
        ['مینا', 'این وقت شب؟ ... یه حس بدی دارم. اون جاده‌ی قدیمی همیشه تاریکه.'],
        ['مینا', 'گوشیت رو روشن نگه دار. هر وقت ترسیدی بهم زنگ بزن، باشه؟'],
      ], () => { this.f.h_wife = true; });
    }, 2.0);
    this.interact('tv', V(8.8, 1.3, 0.7), () => (this.tid() === 'tv' && h.tv.on ? 'خاموش کردن تلویزیون' : null), () => {
      h.tv.set(false); this.tvNoise?.stop(0.1); this.tvNoise = null; audio.click(); this.f.h_tv = true;
      g.after(2, () => { h.tv.set(true); audio.staticBurst(0.4, 0.15); g.after(0.35, () => { h.tv.set(false); this.think('...دوباره روشن شد؟ نه. خیالاتی شدم.', 3); }); });
    }, 2.0);
    // uniform & letter
    this.interact('uniform', V(3.55, 1.25, 3.2), () => (this.tid() === 'uniform' ? 'پوشیدن لباس فرم پترو ۲۴' : null), async () => {
      await g.fadeTo(1, 0.4); h.items.uniform.visible = false; audio.footstep('wood', 0.2); await g.sleep(0.6); await g.fadeTo(0, 0.5);
      this.f.h_uniform = true; g.toast('روی اتیکت لباس اسم یکی دیگه نوشته شده: «م. رضایی»', 4.5);
    }, 1.9);
    this.interact('letter', V(9.45, 0.4, 3.1), () => (this.tid() === 'letter' && h.items.envelope.visible ? 'برداشتن نامه‌ی زیر در' : null), () => {
      h.items.envelope.visible = false; this.f.h_letter = true; audio.clink(); this.readNote(5);
    }, 1.8);
    // figure across the street disappears once you step outside and look away
    g.onFrame(() => {
      if (h.tall.root.visible && g.player.pos.x > 10.4 && !g.isLooking(h.tall.root.position.clone().setY(2), 0.8)) h.tall.root.visible = false;
      return true;
    });
    // bedroom ceiling light (light switch mission)
    const bulb = new THREE.PointLight(0xffe2b0, 0, 7, 2); bulb.position.set(2.2, 2.6, 3); registerLight(bulb); g.scene.add(bulb);
    this.interact('switch', V(4.38, 1.3, 3.9), () => (this.tid() === 'light' ? 'زدن کلید برق' : null), async () => {
      audio.click(); bulb.intensity = 6;
      for (let i = 0; i < 8; i++) { await g.sleep(0.06 + Math.random() * 0.12); bulb.intensity = Math.random() < 0.5 ? 0 : 6; }
      bulb.intensity = 0; audio.glass(bulb.position, 0.35); this.f.h_light = true;
      this.think('لامپ سوخت... عالیه. با چراغ‌قوه‌ی گوشی کار راه می‌افته.', 3.5);
    }, 1.8);
    // window: someone very tall stands in the yard
    this.interact('window', V(2.2, 1.6, 5.85), () => (this.tid() === 'window' && !this.f.h_window && !this.blindsUp ? 'بالا کشیدن کرکره' : null), () => {
      this.blindsUp = true;
      audio.door(V(2.2, 1.6, 6), true);
      g.tween(1.4, (k) => h.setBlinds(k * k * (3 - 2 * k)));
      h.tall.root.position.set(7, 0, 15); h.tall.root.rotation.y = Math.PI + 0.4; h.tall.root.visible = true;
      audio.door(V(2.2, 1.6, 6), true);
      g.onFrame(() => {
        if (this.f.h_window) return false;
        if (g.isLooking(V(7, 2.6, 15), 0.96)) {
          this.f.h_window = true; audio.stinger(0.2);
          this.think('...اون کیه توی حیاط؟ ... چقدر بلنده...', 3.5);
          g.after(2.5, () => { g.flickerAt(g.player.pos, 0.3); h.tall.root.visible = false; audio.staticBurst(0.3, 0.06); g.after(1.5, () => this.think('رفت؟ ... حتماً خیالاتی شدم.', 3)); });
          return false;
        }
        return true;
      });
    }, 1.9);
    this.interact('water', V(7.2, 1.0, 5.5), () => (this.tid() === 'water' ? 'نوشیدن یک لیوان آب' : null), async () => {
      g.player.frozen = true; audio.hum(V(7.2, 1, 5.5), 180, 0.03)?.stop(1.6); await g.sleep(1.8); audio.clink(V(7.2, 1, 5.5));
      g.player.frozen = false; this.f.h_water = true; this.think('آب طعم آهن می‌ده... بی‌خیال. دیرم شده.', 3);
    }, 1.9);
    this.tasks = [
      { id: 'phone', text: () => 'تلفن را از کنار تخت بردار', done: () => !!this.f.h_phone, start: () => { if (this.taskIndex === 0) this.houseIntro(); } },
      { id: 'light', text: () => 'چراغ اتاق را روشن کن (کلید کنار در اتاق)', done: () => !!this.f.h_light },
      { id: 'window', text: () => 'صدایی از حیاط آمد. از پنجره‌ی اتاق خواب بیرون را نگاه کن', done: () => !!this.f.h_window },
      {
        id: 'tv', text: () => 'تلویزیون پذیرایی خودش روشن شد! خاموشش کن', done: () => !!this.f.h_tv,
        start: () => { h.tv.play(Story.FILMS.oldRoad, 0xd8d0c0); h.tv.set(true); this.tvNoise = audio.buzz(V(8.8, 1.3, 0.4), 0.03); audio.staticBurst(0.8, 0.2); g.after(1.5, () => g.say('تلویزیون', '...فیلم قدیمی سیاه و سفید: جاده‌ای در شب... یک پمپ بنزین...', 4)); g.after(5.5, () => audio.whisper(V(8.8, 1.3, 0.5), 0.15, 2)); },
      },
      { id: 'wife', text: () => 'مینا هنوز خواب است. آرام بیدارش کن و بگو کجا می‌روی', done: () => !!this.f.h_wife },
      { id: 'uniform', text: () => 'لباس فرم پمپ بنزین را از کمد اتاق خواب بپوش', done: () => !!this.f.h_uniform },
      { id: 'letter', text: () => 'یک نامه از زیر در ورودی به داخل هل داده شده. برش دار', done: () => !!this.f.h_letter && !ui.get().note, start: () => { audio.knock(h.door.pos, 2, 0.4, 0.5); h.items.envelope.visible = true; } },
      { id: 'keys', text: () => 'کلید ماشین را از روی میز ناهارخوری بردار', done: () => !!this.f.h_keys },
      { id: 'lockdoor', text: () => 'از خانه بیرون برو و در را از بیرون قفل کن', done: () => !!this.f.h_locked },
      { id: 'car', text: () => 'سوار ماشین شو', done: () => !!this.f.h_car },
    ];
    if (this.taskIndex > 0) { g.player.teleport(V(2.2, 0, 1.6), -Math.PI / 2); }
  }

  private async houseIntro() {
    const g = this.g; const p = g.player;
    ui.set({ fade: 1, cutscene: true });
    p.frozen = true;
    p.teleport(V(1.55, 0.75 - 1.62, 1.4), -Math.PI / 2); p.pitch = 1.3;
    await g.sleep(1.2);
    this.card('۰۲:۰۰ بامداد', 'یک شب معمولی…', 3.2);
    await g.sleep(3.6);
    // blinking awake
    await g.fadeTo(0.55, 0.6); await g.fadeTo(1, 0.3); await g.fadeTo(0.3, 0.8); await g.fadeTo(0.8, 0.25); await g.fadeTo(0, 1.2);
    this.think('...این وقت شب؟', 2.5);
    await g.sleep(1.2);
    const from = p.pos.clone(); const to = V(2.0, 0, 1.4); const pf = p.pitch;
    await g.tween(2.6, (k) => { const e = k * k * (3 - 2 * k); p.pos.lerpVectors(from, to, e); p.pitch = pf * (1 - e) - 0.25 * Math.sin(e * Math.PI); p.yaw = -Math.PI / 2 + Math.sin(e * Math.PI) * 0.3 + (-0.9) * e; });
    p.frozen = false;
    ui.set({ cutscene: false });
  }

  private async driveSequence() {
    const g = this.g;
    await g.fadeTo(1, 1.2);
    await g.startDrive('arrive', (id) => this.onDriveEvent(id));
    await g.fadeTo(0, 1.5);
    g.toast('🕹️ جوی‌استیک: فرمان، گاز و ترمز • دید: سمت راست صفحه', 6);
  }
  private onDriveEvent(id: string) {
    const g = this.g;
    switch (id) {
      case 'radio':
        audio.staticBurst(0.6, 0.12);
        g.say('رادیو', '...و همچنان هیچ ردی از کارمند شیفت شب پمپ بنزین جاده‌ی قدیم پیدا نشده. پلیس از رانندگان می‌خواهد شب‌ها...', 7);
        g.after(7.5, () => audio.staticBurst(0.9, 0.15));
        break;
      case 'thought': this.think('آگهی گفته بود «کار آسون، حقوق خوب»... ساعت دو شب زنگ زدن که امشب شروع کنم.', 5); break;
      case 'tall': audio.stinger(0.12); this.think('...اون کی بود کنار جاده؟ چقدر... بلند بود.', 3.5); break;
      case 'hit':
        audio.knock(undefined, 1, 1.2); audio.scream(undefined, 0.5); audio.glass(undefined, 0.4);
        g.after(1.2, () => this.think('به چی زدم؟! ... این دست‌ها روی شیشه از کجا اومدن؟', 4));
        break;
      case 'dogpass': audio.growl(undefined, 0.4); this.think('اون... سگ بود؟ روی دو پا راه می‌رفت؟!', 3.5); break;
      case 'stall':
        audio.staticBurst(1.2, 0.18); audio.whisper(undefined, 0.2, 2.5);
        this.think('نه نه نه... روشن شو! ... یه نفر پشت سرمه؟ آینه رو نگاه کن...', 4);
        break;
      case 'title': ui.set({ title: true }); g.after(5.5, () => ui.set({ title: false })); break;
      case 'arrive': this.finishDrive(); break;
    }
  }
  private escaping = false;
  private lookedBack = false;
  private async escape() {
    const g = this.g;
    if (this.ended || this.escaping) return;
    if (!this.f.note3) { this.think('هنوز نه... باید بفهمم این پمپ چه رازی داره. دفتر مدیر...', 3.5); return; }
    this.escaping = true;
    const mode: DriveMode = this.fireFull ? 'fire' : g.save.violations >= 3 ? 'passenger' : 'dawn';
    this.endId = this.fireFull ? (this.f.freed ? 'release' : 'fire') : mode;
    g.player.frozen = true; ui.set({ cutscene: true, objective: null });
    audio.door(undefined, false);
    await g.fadeTo(1, 1);
    await g.startDrive(mode, (id) => this.onEscapeEvent(id, mode));
    await g.fadeTo(0, 1.2);
    g.setObjective(mode === 'fire' ? 'از آتش دور شو' : 'فقط برون. پشت سرت را نگاه نکن.');
  }
  private onEscapeEvent(id: string, mode: DriveMode) {
    const g = this.g;
    if (id === 'start') this.think(mode === 'fire' ? 'تو آینه... پمپ داره می‌سوزه. اون سایه‌ها... دارن نگاه می‌کنن.' : mode === 'dawn' ? 'آسمون داره روشن می‌شه... تموم شد. تموم شد؟' : 'فقط برون. فقط برون.', 4.5);
    if (id === 'passenger') { audio.breath(undefined, 0.2, false, 1.6); g.after(1.6, () => { audio.voice(undefined, 70, 2, 0.1, true); g.say('؟', 'تو زیادی سؤال پرسیدی.', 3.5); }); g.after(6, () => { if (this.g.drive) this.g.drive.passenger.root.visible = false; }); }
    if (id === 'lookback' && !this.ended && !this.lookedBack) { this.lookedBack = true; audio.scream(undefined, 0.8); ui.set({ jumpscare: 1 }); g.after(0.9, () => { ui.set({ jumpscare: 0 }); if (this.g.drive) this.g.drive.passenger.root.visible = false; }); }
    if (id === 'end') {
      // the heart burned → the story continues: morning, home, sleep… and the other side
      this.goChapter(6); return; // single linear story: always home at dawn
      this.ending(this.endId || mode);
    }
    if (id === 'start' && this.endId === 'release') g.after(5, () => this.think('چهار نفر... کنار جاده... دارن به سمت طلوع می‌رن.', 4.5));
  }
  private endId = '';
  private drivingDone = false;
  finishDrive() {
    if (this.drivingDone) return; this.drivingDone = true;
    const g = this.g;
    ui.set({ skippable: false, title: false });
    g.fadeTo(1, 0.8).then(() => { this.g.save.flags = {}; g.loadChapter(2, 0); ui.set({ fade: 0 }); });
  }
  skip() { if (this.g.level === 'drive') this.finishDrive(); }

  // ======================= STATION COMMON =======================
  private setupStationCommon() {
    const g = this.g; const st = this.st; const a = st.a;
    this.drivingDone = false;
    // restore world state from flags
    st.doors.front.locked = !this.f.storeOpen;
    st.doors.office.locked = !this.f.hasKey;
    const powered = this.f.power && !this.f.powerOut;
    this.powerAll(!!powered);
    st.lights.office.set(this.chapter >= 5);
    st.lights.basement.set(true);
    st.messy.forEach((m, i) => (m.visible = !this.f['arr' + i]));
    st.items.soda.visible = !this.f.fridge && this.chapter === 2;
    st.items.spill.visible = this.chapter === 3 && !this.f.spill;
    st.items.mop.visible = !(this.chapter === 3 && this.f.spill);
    st.items.trash.visible = this.chapter === 3 && !this.f.trash;
    st.items.order.visible = this.chapter === 3 && !this.f.delivered;
    st.items.fuel.visible = !this.f.fuel;
    st.items.key.visible = !this.f.hasKey;
    st.items.lighter.visible = !this.g.save.hasLighter;
    st.items.note2.visible = this.chapter >= 3;
    st.items.bottle.visible = this.chapter >= 3;
    st.items.order.visible = false; // replaced by the hot-dog job
    // horror escalation: posters multiply, age and bleed as the night goes on
    st.setHorror(this.chapter - 2);
    st.items.wetSign.visible = this.chapter === 3 && !this.f.spill;
    st.items.flyer.visible = this.chapter >= 3 && !this.f.flyer;
    const rollerOn = this.chapter >= 3 || !!this.f.rollerOn;
    st.roller.setOn(rollerOn); st.roller.setCount(rollerOn ? 7 : 0); st.roller.cook = rollerOn ? 1 : 0;
    st.donuts.setFilled(true); // the display case is always stocked; the mission adds a fresh box on top
    // carry-able food items created by the story
    const donutBox = new THREE.Group();
    const dbm = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.1, 0.32), new THREE.MeshStandardMaterial({ color: 0xf48fb1, roughness: 0.7 }));
    donutBox.add(dbm);
    for (let i = 0; i < 6; i++) { const d = new THREE.Mesh(new THREE.TorusGeometry(0.04, 0.02, 6, 12).rotateX(Math.PI / 2), new THREE.MeshStandardMaterial({ color: [0xd99a4e, 0x5a2e1a, 0xf48fb1][i % 3], roughness: 0.6 })); d.position.set(-0.14 + (i % 3) * 0.14, 0.07, i < 3 ? -0.07 : 0.07); donutBox.add(d); }
    donutBox.position.set(-5.2, 0.86, -8.0); donutBox.visible = this.chapter === 2 && !this.f.donuts; st.dyn.add(donutBox); st.items.donutbox = donutBox;
    const sausage = new THREE.Group();
    sausage.add(new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.05, 0.18), new THREE.MeshStandardMaterial({ color: 0xc8302a, roughness: 0.4 })));
    for (let i = 0; i < 4; i++) { const s = new THREE.Mesh(new THREE.CapsuleGeometry(0.018, 0.16, 3, 6).rotateZ(Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xd88a7a, roughness: 0.4 })); s.position.set(0, 0.035, -0.06 + i * 0.04); sausage.add(s); }
    sausage.position.set(-3.2, 0.53, -9); sausage.visible = this.chapter === 2 && !this.f.rollerOn; st.dyn.add(sausage); st.items.sausage = sausage;

    this.interact('donutbox', V(-5.2, 1.0, -8.0), () => (donutBox.visible && !g.item && this.chapter === 2 ? 'برداشتن جعبه دونات' : null), () => this.pick('donutbox', donutBox, 0.8), 1.9);
    this.interact('donutcase', st.a.donuts, () => (g.item === 'donutbox' ? 'چیدن دونات‌های تازه روی ویترین' : null), async () => {
      g.setItem(null); g.player.frozen = true;
      for (let i = 0; i < 4; i++) { audio.clink(st.a.donuts); await g.sleep(0.35); }
      donutBox.position.set(7.3, 1.69, 0.85); donutBox.rotation.set(0, 0.1, 0); donutBox.scale.setScalar(1); donutBox.visible = true; st.dyn.add(donutBox);
      this.f.donuts = true; g.player.frozen = false;
    }, 2.2);
    this.interact('sausage', V(-3.2, 0.7, -9), () => (sausage.visible && !g.item && this.chapter === 2 ? 'برداشتن بسته سوسیس' : null), () => this.pick('sausage', sausage, 0.8), 1.9);
    this.interact('roller', st.a.roller, () => {
      if (g.item === 'sausage') return 'چیدن سوسیس‌ها و روشن کردن دستگاه';
      if (this.chapter === 3 && this.tid() === 'deliver' && !g.item && !this.f.delivered) return 'درست کردن هات‌داگ';
      return null;
    }, async () => {
      if (g.item === 'sausage') {
        g.setItem(null); g.player.frozen = true;
        for (let i = 1; i <= 7; i++) { st.roller.setCount(i); audio.clink(st.a.roller); await g.sleep(0.22); }
        st.roller.cook = 0; st.roller.setOn(true); audio.click(); this.f.rollerOn = true; g.player.frozen = false;
        return;
      }
      g.player.frozen = true; audio.clink(st.a.roller); await g.sleep(0.6); audio.clink(st.a.roller); await g.sleep(0.5); g.player.frozen = false;
      g.setItem('hotdog', makeHotdog()); g.toast('هات‌داگ آماده شد 🌭');
    }, 2.2);
    // chips restock (chapter 2)
    st.items.restock.visible = !(this.chapter === 2 && !this.f.restock);
    st.items.chipsCarton.visible = this.chapter === 2 && !this.f.restock && !!this.f.restockStarted;
    this.interact('carton', st.items.chipsCarton.position.clone().setY(0.6), () => (st.items.chipsCarton.visible && !g.item ? 'برداشتن کارتن چیپس و پفک' : null), () => this.pick('chips', st.items.chipsCarton, 0.5), 1.9);
    this.interact('restock', st.a.restock, () => (g.item === 'chips' ? 'چیدن چیپس و پفک در قفسه' : null), async () => {
      g.setItem(null); g.player.frozen = true;
      for (let i = 0; i < 6; i++) { audio.clink(st.a.restock); await g.sleep(0.25); }
      st.items.restock.visible = true; this.f.restock = true; g.player.frozen = false;
    }, 2.2);
    this.interact('flyer', st.a.flyer, () => (st.items.flyer.visible ? 'برگه‌ای زیر برف‌پاک‌کن ماشینت گیر کرده' : null), () => {
      st.items.flyer.visible = false; this.f.flyer = true; this.readNote(4); audio.stinger(0.12);
    }, 2.4);

    // doors with special logic
    this.doorPrompt = (d) => {
      if (d.name === 'back' && this.tid() === 'barricade' && !this.f.backLocked && this.backLockFn) return 'قفل کردن و سد کردن در پشتی';
      if (d.name === 'front' && d.locked && !this.f.storeOpen) return 'باز کردن قفل در فروشگاه';
      if (d.name === 'office' && d.locked && this.f.hasKey) return 'باز کردن قفل دفتر مدیر';
      return undefined;
    };
    this.doorAction = (d) => {
      if (d.name === 'back' && this.tid() === 'barricade' && !this.f.backLocked && this.backLockFn) { this.backLockFn(); return true; }
      if (d.name === 'front' && d.locked && !this.f.storeOpen) { d.locked = false; this.f.storeOpen = true; audio.clink(d.pos); d.setOpen(true); audio.bell(d.pos); return true; }
      if (d.name === 'office' && d.locked && this.f.hasKey) { d.locked = false; audio.clink(d.pos); d.setOpen(true); return true; }
      if (d.name === 'front' && !d.open) {
        const w = g.monsters.get('watcher');
        if (w && w.state === 'observe') { /* opening while something waits outside is noted by the watcher itself */ }
        audio.bell(d.pos);
      }
      return false;
    };
    // register / checkout
    this.interact('register', a.register.clone().setY(1.2), () => {
      const c = g.npcs.waiting();
      if (!c) return null;
      if (g.player.pos.z > 0.5) return 'برای حساب کردن پشت صندوق برو';
      return `حساب کردن (${c.name})`;
    }, () => { const c = g.npcs.waiting(); if (c && g.player.pos.z <= 0.5) this.checkout(c); }, 2.4);
    // CCTV
    this.interact('cctv', a.cctv, () => 'بررسی دوربین‌های مداربسته', () => g.openCCTV(), 2.0);
    // coffee
    this.interact('coffee', a.coffee, () => (this.tid() === 'sh-coffee' || this.brewing ? null : 'نوشیدن یک قهوه'), async () => {
      if (!(await this.brewCoffee())) return;
      g.player.stamina = 1; g.toast('قهوه‌ی تلخ و داغ. انرژی‌ات برگشت.');
    }, 2.0);
    // notes
    this.interact('note1', st.items.note1.position, () => 'خواندن اعلامیه', () => this.readNote(1), 1.8);
    this.interact('note2', st.items.note2.position.clone().setY(1.0), () => (st.items.note2.visible ? 'خواندن یادداشت' : null), () => this.readNote(2), 1.8);
    // lighter (optional, chapter 4+)
    this.interact('lighter', st.items.lighter.position, () => (this.chapter >= 4 && !g.save.hasLighter ? 'برداشتن فندک' : null), () => { g.save.hasLighter = true; st.items.lighter.visible = false; audio.clink(); g.toast('فندک برداشته شد'); }, 1.6);
    // bottle (throwable)
    this.interact('bottle', st.items.bottle.position, () => (st.items.bottle.visible && !g.item ? 'برداشتن بطری' : null), () => {
      this.pick('bottle', st.items.bottle, 1); g.toast('دکمه «استفاده» برای پرتاب و ایجاد صدا');
      g.after(40, () => { if (this.g.station) st.items.bottle.visible = true; });
    }, 1.6);
    // phone (random / scripted)
    this.interact('phone', a.phone, () => (this.phoneRing ? 'جواب دادن تلفن' : null), () => this.answerPhone(), 1.8);
    // player car (escape in chapter 5)
    this.interact('pcar', a.playerCar, () => (this.setupKey === 'ch5' ? 'فرار با ماشین' : null), () => this.escape(), 2.4);
    // flares on the tools wall (usable torch)
    const flareList = (st.items as unknown as Record<string, THREE.Object3D[]>).flareList ?? [];
    this.interact('flare', a.flares, () => (!g.item && flareList.some((f) => f.visible) ? 'برداشتن مشعل اضطراری' : null), () => {
      const f = flareList.find((x) => x.visible); if (!f) return;
      this.pick('flare', f, 1.2); g.toast('دکمه «استفاده» برای روشن کردن مشعل');
    }, 1.8);
  }

  private readNote(n: number) {
    const N = NOTES[n];
    if (!this.g.save.notes.includes(n)) this.g.save.notes.push(n);
    this.f['note' + n] = true;
    this.g.showNote(N.title, N.body);
  }
  onNoteClosed() { const cb = this.noteCb; this.noteCb = null; cb?.(); }

  private checkout(c: Customer) {
    const g = this.g;
    const opts = [
      { id: 'pay', text: '💳 حساب کردن' },
      { id: 'greet', text: '«شب بخیر، خوش اومدید.»' },
      { id: 'ok', text: '«حالتون خوبه؟»' },
      { id: 'where', text: '«این وقت شب کجا می‌رید؟»' },
    ];
    c.talking = true;
    const intro = c.role === 'faceless' ? '...' : c.anomalous ? '...' : 'سلام.';
    g.openDialogue(c.name, intro, opts, (id) => {
      if (c.role === 'shifter') { g.closeDialogue(); this.triggerShift(c); return; }
      const r = c.respond(id);
      if (r.text) c.speak(r.text, c.anomalous);
      if (id === 'pay') audio.beep(this.st.a.register);
      if (r.end || c.removed) {
        g.closeDialogue(); c.talking = false;
        if (id === 'pay' && !c.removed) { this.served++; c.onServed?.(); this.g.after(1.2, () => c.leave()); }
      } else {
        const used = new Set([id]);
        g.updateDialogue(r.text || '...', opts.filter((o) => !used.has(o.id) || o.id === 'pay'));
      }
    });
  }

  // ---------------- phone ----------------
  randomPhone() {
    if (this.phoneRing) return;
    this.phoneMode = 'random'; this.phoneBusy = true;
    this.phoneRing = audio.ring(this.st.a.phone, 'phone');
    this.g.after(16, () => { if (this.phoneMode === 'random') { this.phoneRing?.stop(); this.phoneRing = null; this.phoneMode = null; this.phoneBusy = false; } });
  }
  private async answerPhone() {
    const g = this.g;
    this.phoneRing?.stop(); this.phoneRing = null;
    const pm = g.station?.phoneModel;
    if (pm) { pm.ringing = false; pm.lift(true); g.after(7, () => { if (this.g.station === g.station) pm.lift(false); }); }
    const mode = this.phoneMode; this.phoneMode = null;
    audio.click();
    if (mode === 'random') {
      this.phoneBusy = false;
      if (this.chapter >= 4) g.violation('phone');
      const lines = this.chapter >= 4 ? ['...پشت سرت رو نگاه نکن.', '...چرا جواب دادی؟', '...ما تقریباً اونجاییم.'] : ['...', '(صدای نفس کشیدن)', '...الو؟ ... الو؟'];
      audio.breath(undefined, 0.12, true, 1.2);
      g.say('صدای پشت خط', lines[Math.floor(Math.random() * lines.length)], 3.5);
      if (this.chapter >= 4) { await g.sleep(2); g.flickerAt(g.player.pos, 1.5); audio.whisper(g.player.pos.clone().setY(1.6), 0.2, 2); }
      return;
    }
    if (mode === 'script') {
      g.player.frozen = true;
      const lines = ['...تو هنوز اونجایی؟', '...خوبه. خیلی خوبه. بیشتر از قبلی‌ها دووم آوردی.', '...دفتر من رو باز نکن. کلیدش روی میز همین اتاقه.', '...و هرگز... هرگز... پایین نرو.'];
      for (const l of lines) { audio.voice(undefined, 85, 2, 0.06, true); g.say('مدیر؟', l, 3.6); await g.sleep(3.8); }
      audio.voice(undefined, 60, 1.5, 0.08, true);
      g.player.frozen = false;
      this.f.phoneAnswered = true; this.phoneBusy = false;
    }
  }

  // ---------------- CCTV hooks ----------------
  onCCTV(i: number) {
    const g = this.g;
    if (this.chapter === 3 && this.taskIndex === 0 && i === 2 && this.cctvFigure) {
      g.after(1.0, () => { if (g.cctvIndex === 2) { audio.stinger(0.15); this.f.cctvSeen = true; } });
    }
    // random CCTV ghost in later chapters
    if (this.chapter >= 4 && Math.random() < 0.25 && !this.cctvFigure) {
      const fig = buildFaceless(false); const spots = [V(-6, 0, -0.6), V(5.5, 0, 2.1), V(-9, 0, -9), V(0, 0, 15)];
      fig.root.position.copy(spots[i % spots.length]); fig.root.rotation.y = Math.random() * 6;
      g.scene.add(fig.root); fig.root.traverse((c) => c.layers.set(2));
      this.cctvFigure = fig;
      g.after(8, () => { if (this.cctvFigure === fig) { g.scene.remove(fig.root); this.cctvFigure = null; } });
    }
  }
  onCCTVClosed() {
    const g = this.g;
    if (this.chapter === 3 && this.f.cctvSeen && !this.f.cctvChecked) {
      this.f.cctvChecked = true;
      if (this.cctvFigure) { g.scene.remove(this.cctvFigure.root); this.cctvFigure = null; }
      this.think('یه نفر توی انبار بود...؟', 3);
      g.after(2, () => audio.knock(V(-9, 1.4, -9), 3, 0.5, 0.5));
    }
  }
  onViolation(_r: string) {
    // the world quietly notices
    this.g.after(1 + Math.random() * 3, () => { audio.whisper(this.g.player.pos.clone().add(V(0, 1.6, 0)), 0.06, 1); });
  }

  // ======================= CHAPTER 2 – first shift =======================
  private setupCh2() {
    const g = this.g; const st = this.st; const a = st.a;
    this.clockStart = 180; this.clockSpan = 40;
    if (this.taskIndex === 0) {
      g.player.teleport(a.spawnPlayer, yawTo(a.spawnPlayer, V(0, 0, 4)));
      this.card('فصل ۲ — اولین شیفت', '۰۳:۰۰ بامداد • پمپ بنزین پترو ۲۴');
      g.after(4.5, () => this.think('هیچ‌کس اینجا نیست... کلید رو بهم داده بودن.', 3.5));
    } else g.player.teleport(a.cashier, Math.PI);
    if (!this.f.power) { st.lights.canopy.set(false); st.lights.sign.set(false); }
    // breaker
    this.interact('breaker', a.breaker, () => (!this.f.power ? 'روشن کردن کلید اصلی برق' : null), async () => {
      this.f.power = true; audio.door(a.breaker, false, true);
      const L = st.lights; const order = ['staff', 'corridor', 'toilet', 'storage', 'sales', 'canopy', 'sign'];
      for (const n of order) { L[n]?.set(true); L[n]?.flicker(0.6 + Math.random() * 0.6); audio.click(); await g.sleep(0.35); }
      this.think('خیلی بهتر شد.', 2);
    }, 1.8);
    // messy items
    st.messy.forEach((m, i) => this.interact('messy' + i, m.position.clone().setY(0.6), () => (m.visible && this.f.power ? 'مرتب کردن اجناس' : null), () => { m.visible = false; this.f['arr' + i] = true; audio.clink(m.position); }, 2.0));
    // soda + fridge
    this.interact('soda', st.items.soda.position.clone().setY(0.6), () => (st.items.soda.visible && !g.item && this.f.power ? 'برداشتن جعبه نوشابه' : null), () => this.pick('soda', st.items.soda), 1.8);
    this.interact('fridge', a.fridge, () => (g.item === 'soda' ? 'پر کردن یخچال' : null), async () => {
      g.setItem(null); g.player.frozen = true;
      for (let i = 0; i < 5; i++) { audio.clink(a.fridge); await g.sleep(0.3); }
      g.player.frozen = false; this.f.fridge = true;
    }, 2.2);
    // pumps
    [1, 2].forEach((n) => this.interact('pump' + n, a['pump' + n], () => (this.tid() === 'pumps' && !this.f['pump' + n] ? `بررسی جایگاه ${fa(n)}` : null), () => {
      this.f['pump' + n] = true; audio.beep(a['pump' + n]);
      g.toast(`جایگاه ${fa(n)}: فشار نرمال • نازل سالم`);
      if (n === 2) g.after(2, () => audio.bark(V(-20, 1.5, -28), 0.4));
    }, 2.2));
    this.tasks = [
      { id: 'open', text: () => 'در ورودی فروشگاه را باز کن', done: () => !!this.f.storeOpen },
      { id: 'power', text: () => 'برق را از تابلو برق «اتاق کارکنان» روشن کن', done: () => !!this.f.power, start: () => this.g.after(3, () => this.think('چقدر تاریکه... تابلو برق باید ته راهرو باشه.', 3.5)) },
      { id: 'arrange', text: () => `اجناس افتاده را مرتب کن (${fa([0, 1, 2].filter((i) => this.f['arr' + i]).length)}/۳)`, done: () => [0, 1, 2].every((i) => this.f['arr' + i]), start: () => this.g.director.reset(true, 60) },
      { id: 'fridge', text: () => (g.item === 'soda' ? 'یخچال نوشابه را پر کن' : 'یک جعبه نوشابه از «انبار» بیاور'), done: () => !!this.f.fridge },
      { id: 'donuts', text: () => (g.item === 'donutbox' ? 'دونات‌های تازه را روی ویترین دونات (پیشخوان) بچین' : 'دونات‌های تازه رسیده. جعبه دونات را از قفسه‌ی «انبار» بیاور'), done: () => !!this.f.donuts },
      {
        id: 'hotdog', text: () => (this.f.rollerOn ? `صبر کن تا سوسیس‌ها گرم شوند (${fa(Math.round(Math.min(1, st.roller.cook / 0.4) * 100))}٪)` : g.item === 'sausage' ? 'سوسیس‌ها را روی دستگاه هات‌داگ بچین' : 'بسته سوسیس را از «انبار» بیاور و دستگاه هات‌داگ را راه بینداز'),
        done: () => !!this.f.rollerOn && st.roller.cook >= 0.4,
      },
      {
        id: 'customers', text: () => `به مشتری‌ها رسیدگی کن (${fa(this.served)}/۳)`, done: () => this.served >= 3,
        start: () => {
          const arch = ['worker', 'woman', 'youth', 'trucker', 'oldman'];
          let k = 0;
          const next = () => { if (this.served >= 3 || !this.g.station) return; const c = g.npcs.spawn({ arch: arch[k++ % arch.length] }); c.onServed = () => g.after(8 + Math.random() * 6, next); this.watchUnserved(c, next); };
          g.after(3, next);
          g.after(10, () => g.npcs.spawn({ arch: 'quick', quirk: 'quick' }));
        },
      },
      {
        id: 'restock', text: () => (g.item === 'chips' ? 'قفسه‌ی انتهای راهروی ۲ (چیپس و پفک) را پر کن' : 'قفسه‌ی چیپس و پفک خالی شده. کارتن چیپس را از «انبار» بیاور'), done: () => !!this.f.restock,
        start: () => { this.f.restockStarted = true; st.items.restock.visible = false; st.items.chipsCarton.visible = g.item !== 'chips'; },
      },
      { id: 'pumps', text: () => `جایگاه‌های سوخت را بررسی کن (${fa([1, 2].filter((n) => this.f['pump' + n]).length)}/۲)`, done: () => !!this.f.pump1 && !!this.f.pump2, start: () => { this.allowRandomCustomers = true; } },
      { id: 'note1', text: () => 'تابلوی اعلانات «اتاق کارکنان» را بخوان', done: () => !!this.f.note1 && !ui.get().note },
    ];
  }

  private tid() { return this.tasks[this.taskIndex]?.id; }
  private backLockFn: (() => void) | null = null;
  private blindsUp = false;
  private tvNoise: LoopHandle | null = null;
  private lockingBack = false;

  /** a customer drives up to pump 1; while fueling, the driver silently disappears and the car leaves by itself */
  private customerCar() {
    const g = this.g; const st = this.st; const cc = st.custCar; const drv = st.driver;
    this.f.carParked = false; this.f.fueling = false;
    cc.group.visible = true; drv.root.visible = true; cc.setLights(true);
    const snd = audio.engine(0.28, cc.group.position);
    this.driveCar([V(-70, 0, 31), V(-25, 0, 30.6), V(-9, 0, 25.5), V(-2.6, 0, 20), V(-2.6, 0, 15)], 11, snd, () => {
      st.custBox.enabled = true; cc.setLights(false); snd?.stop(1.2); this.f.carParked = true;
      audio.door(cc.group.position.clone().setY(1), false);
      audio.voice(cc.group.position.clone().setY(1.3), 110, 1.8, 0.12);
      g.say('راننده', 'پرش کن لطفاً... معمولی. عجله دارم.', 3.5);
    });
    const capPos = V(-3.5, 1.0, 16.5);
    this.interact('fuelcap', capPos, () => (this.f.carParked && !this.f.fueled && !this.f.fueling ? 'برداشتن نازل و سوخت‌گیری' : null), async () => {
      this.f.fueling = true; g.player.frozen = true;
      // take the green (91) nozzle from the dispenser facing the car and put it in the filler neck
      const disp = st.pumps[1]; const nz = disp.nozzles.find((n) => n.side === 1)!;
      cc.group.updateMatrixWorld(true);
      const cap = cc.fuelCap.getWorldPosition(new THREE.Vector3());
      const out = cap.clone().add(new THREE.Vector3(-0.32, 0.12, 0)); // in front of the filler, nozzle tilted in
      const into = cap.clone().add(new THREE.Vector3(0.5, -0.35, 0));
      disp.group.updateMatrixWorld(true);
      const homeW = disp.group.localToWorld(nz.home.clone());
      audio.clink(homeW);
      await g.tween(0.9, (k) => { const e = k * k * (3 - 2 * k); disp.moveNozzle(nz, homeW.clone().lerp(out, e).add(new THREE.Vector3(0, Math.sin(e * Math.PI) * 0.25, 0)), into); });
      audio.clink(cap); audio.beep(cap);
      const hum = audio.hum(cap, 70, 0.08);
      await g.tween(6, (k) => {
        disp.setDisplay(1, k * 38.4, 0);
        ui.set({ toast: `⛽ سوخت‌گیری... ${fa((k * 38.4).toFixed(1))} لیتر` });
        if (k > 0.55 && drv.root.visible) { drv.root.visible = false; st.lights.canopy.flicker(1.4); audio.staticBurst(0.4, 0.06); }
      });
      hum?.stop(0.3); ui.set({ toast: null }); audio.click();
      await g.tween(0.8, (k) => { const e = k * k * (3 - 2 * k); disp.moveNozzle(nz, out.clone().lerp(homeW, e), into.clone().lerp(homeW.clone().add(new THREE.Vector3(-1, -1.1, 0)), e)); });
      disp.moveNozzle(nz, null); audio.clink(homeW);
      g.player.frozen = false; this.f.fueling = false; this.f.fueled = true;
      this.think('تموم شد... راننده؟ ... ماشین خالیه. کسی پشت فرمون نیست.', 4);
      await g.sleep(4.5);
      if (!this.g.station) return;
      cc.setLights(true); st.custBox.enabled = false;
      const snd2 = audio.engine(0.32, cc.group.position);
      audio.whisper(cc.group.position.clone().setY(1.3), 0.15, 2);
      this.driveCar([V(-2.6, 0, 15), V(-2.6, 0, 22), V(3, 0, 27.5), V(20, 0, 30.2), V(95, 0, 30.2)], 10, snd2, () => { cc.group.visible = false; snd2?.stop(0.4); });
    }, 2.3);
  }
  private driveCar(path: THREE.Vector3[], speed: number, snd: LoopHandle | null, done: () => void) {
    const grp = this.st.custCar.group; const wheels = this.st.custCar.wheels;
    let i = 0; grp.position.copy(path[0]);
    grp.rotation.y = Math.atan2(path[1].x - path[0].x, path[1].z - path[0].z);
    this.g.onFrame((dt) => {
      const tgt = path[i + 1]; if (!tgt) { done(); return false; }
      const d = tgt.clone().sub(grp.position); d.y = 0; const len = d.length();
      if (len < 0.3) { i++; return true; }
      const last = i === path.length - 2;
      const sp = last ? Math.max(1.5, Math.min(speed, len * 1.4)) : speed;
      d.normalize(); grp.position.addScaledVector(d, Math.min(len, sp * dt));
      let df = Math.atan2(d.x, d.z) - grp.rotation.y; df = Math.atan2(Math.sin(df), Math.cos(df)); grp.rotation.y += df * Math.min(1, dt * 3.5);
      wheels.forEach((w) => (w.rotation.z -= (sp * dt) / 0.33));
      snd?.setPos?.(grp.position);
      return true;
    });
  }

  private watchUnserved(c: Customer, next: () => void) {
    this.g.onFrame(() => { if (c.removed) { if (!c.served) this.g.after(4, next); return false; } return true; });
  }

  // ======================= CHAPTER 3 – strange customers =======================
  private setupCh3() {
    const g = this.g; const st = this.st; const a = st.a;
    this.clockStart = 220; this.clockSpan = 40;
    g.player.teleport(a.cashier, Math.PI);
    if (this.taskIndex === 0) this.card('فصل ۳ — مشتری‌های عجیب', '۰۳:۴۰ بامداد');
    // mop & spill
    this.interact('mop', V(-2.4, 0.9, -5.6), () => (this.tid() === 'spill' && !g.item && st.items.mop.visible ? 'برداشتن تی' : null), () => this.pick('mop', st.items.mop, 0.5), 1.8);
    this.interact('spill', V(-11.6, 0.4, 2.0), () => (st.items.spill.visible ? (g.item === 'mop' ? 'تمیز کردن زمین' : 'زمین کثیف است (تی لازم است)') : null), async () => {
      if (g.item !== 'mop') return;
      g.player.frozen = true;
      const s = st.items.spill;
      await g.tween(2.2, (k) => { s.scale.setScalar(Math.max(0.01, 1 - k)); if (Math.random() < 0.1) audio.footstep('wet', 0.2, s.position); });
      s.visible = false; g.setItem(null); g.player.frozen = false; this.f.spill = true;
    }, 2.4);
    // trash
    this.interact('trash', st.items.trash.position.clone().setY(0.6), () => (this.tid() === 'trash' && st.items.trash.visible && !g.item ? 'برداشتن کیسه زباله' : null), () => this.pick('trash', st.items.trash, 0.5), 1.8);
    // new fluorescent tube (staff room counter) + storage ceiling fixture
    const tubeMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 1.2, 8).rotateZ(Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xf4f4f0, roughness: 0.3, emissive: 0x222222 }));
    tubeMesh.position.set(11.2, 0.83, -11.5); tubeMesh.visible = !this.f.tube; st.dyn.add(tubeMesh);
    if (this.f.tube) st.lights.storage.unstable = 0;
    this.interact('tubepick', V(11.2, 1.0, -11.4), () => (tubeMesh.visible && !g.item && this.tid() === 'tube' ? 'برداشتن لامپ مهتابی' : null), () => this.pick('tube', tubeMesh, 0.5), 1.8);
    this.interact('tubefix', V(-8, 2.0, -8.5), () => (g.item === 'tube' ? 'تعویض لامپ سقف' : null), async () => {
      g.setItem(null); g.player.frozen = true; st.lights.storage.set(false); audio.click();
      await g.sleep(1.2); audio.clink(V(-8, 2.9, -8.5)); await g.sleep(0.8);
      // something stood right behind you in the dark
      audio.breath(g.player.pos.clone().setY(1.6), 0.18, false, 1.2);
      await g.sleep(1.2);
      st.lights.storage.unstable = 0; st.lights.storage.set(true); st.lights.storage.flicker(0.6); audio.click();
      g.player.frozen = false; this.f.tube = true;
      this.think('...صدای نفس بود؟ پشت سرم؟', 3);
    }, 2.6);
    // inventory points on the three storage racks
    [V(-13.0, 1.2, -8.5), V(-8, 1.2, -11.0), V(-6.5, 1.2, -7.4)].forEach((p, i) => this.interact('inv' + i, p, () => (this.tid() === 'inventory' && !this.f['inv' + i] ? 'شمارش اجناس قفسه' : null), async () => {
      g.player.frozen = true; for (let k = 0; k < 3; k++) { audio.clink(p); await g.sleep(0.4); } g.player.frozen = false;
      this.f['inv' + i] = true;
      const n = [0, 1, 2].filter((j) => this.f['inv' + j]).length;
      if (n === 1) g.toast('۲۴ جعبه نوشابه • ۱۲ کارتن چیپس • ... یک کارت نام پاره؟');
      if (n === 2) { audio.knock(V(-4, 1, -11), 3, 0.6, 0.4); this.think('اون صدا از پشت جعبه‌ها بود...', 3); }
      if (n === 3) { g.flicker('storage', 1.5); audio.whisper(g.player.pos.clone().setY(1.6), 0.18, 2); }
    }, 1.9));
    this.interact('dumpster', a.dumpster, () => (g.item === 'trash' ? 'انداختن زباله در سطل' : null), async () => {
      g.setItem(null); audio.door(a.dumpster, false, true); this.f.trash = true;
      const dog = g.monsters.ensure('dog', () => new DogMonster(g));
      dog.observeAt(V(2, 0, -27)); dog.t = 12;
      await g.sleep(2.5);
      this.think('اون کیه... ته زمین وایساده؟', 3);
      await g.sleep(4); audio.bark(dog.pos.clone().setY(1.6), 0.5);
    }, 2.2);
    // order delivery


    this.tasks = [
      {
        id: 'cctv', text: () => 'دوربین‌های امنیتی را در «اتاق کارکنان» بررسی کن', done: () => !!this.f.cctvChecked,
        start: () => {
          const fig = new Humanoid({ skin: 0xc49a7c, shirt: 0x50565c, pants: 0x34404c, vest: 0xff7a1a, hairStyle: 'cap', cap: 0x444444 }, false);
          fig.root.position.set(-10.5, 0, -8.6); fig.root.rotation.y = Math.PI * 0.85; fig.neck.rotation.x = 0.5;
          g.scene.add(fig.root); fig.root.traverse((c) => c.layers.set(2));
          this.cctvFigure = fig;
        },
      },
      { id: 'spill', text: () => (g.item === 'mop' ? 'زمین کنار یخچال‌ها را تمیز کن' : 'کف کنار یخچال‌ها کثیف شده. تی را از «انبار» بیاور'), done: () => !!this.f.spill, start: () => this.g.director.reset(true, 50) },
      {
        id: 'tube', text: () => (g.item === 'tube' ? 'لامپ مهتابی سقف «انبار» را عوض کن' : 'چراغ انبار مدام چشمک می‌زند. لامپ نو را از «اتاق کارکنان» بردار'), done: () => !!this.f.tube,
        start: () => { st.lights.storage.unstable = 0.35; tubeMesh.visible = true; },
      },
      {
        id: 'fuelcar', text: () => (this.f.fueling ? 'در حال سوخت‌گیری...' : this.f.carParked ? 'باک ماشین مشتری را در «جایگاه ۱» پر کن' : 'یک ماشین به سمت جایگاه‌ها می‌آید...'), done: () => !!this.f.fueled,
        start: () => this.customerCar(),
      },
      {
        id: 'strange', text: () => `به مشتری‌ها رسیدگی کن (${fa(this.served)}/۳)`, done: () => this.served >= 3,
        start: () => {
          this.seq = [
            () => g.npcs.spawn({ arch: 'oldman', quirk: 'stare' }),
            () => g.npcs.spawn({ arch: 'quick', quirk: 'quick', anomalous: true }),
            () => g.npcs.spawn({ role: 'faceless', quirk: 'line' }),
            () => g.npcs.spawn({ arch: 'youth', quirk: 'freeze' }),
            () => g.npcs.spawn({ arch: 'woman', quirk: 'reflection', anomalous: true }),
            () => g.npcs.spawn({ arch: 'worker', quirk: 'turn' }),
            () => g.npcs.spawn({ arch: 'trucker', quirk: 'leave', anomalous: true }),
          ];
          const next = () => {
            if (this.served >= 3 || !this.g.station) return;
            const mk = this.seq.shift() ?? (() => g.npcs.spawn({ quirk: Math.random() < 0.5 ? 'stare' : null }));
            const c = mk();
            g.onFrame(() => { if (c.removed) { g.after(5 + Math.random() * 5, next); return false; } return true; });
          };
          g.after(4, next);
        },
      },
      {
        id: 'restroom', text: () => 'یک مشتری گفت از سرویس بهداشتی صدای گریه می‌آید. بررسی کن', done: () => !!this.f.restroom,
        start: () => {
          let inT = 0;
          const sob = () => { if (this.f.restroom || !this.g.station) return; audio.whisper(V(6.9, 1.2, -7.6), 0.12, 2.5); g.after(6 + Math.random() * 3, sob); };
          g.after(2, sob);
          g.onFrame((dt) => {
            if (!this.g.station || this.f.restroom) return false;
            if (g.regionOf(g.player.pos) === 'toilet') inT += dt; else inT = 0;
            if (inT > 1.2) {
              this.f.restroom = true;
              st.lights.toilet.flicker(2.5); audio.knock(V(6.9, 1.2, -7.6), 4, 0.8, 0.18);
              const sc = st.decals[st.decals.length - 1]; sc.visible = true;
              g.after(1.4, () => { audio.stinger(0.25); this.think('«پشت سرت»... روی آینه... کی اینو نوشته؟!', 3.5); });
              g.after(3.5, () => { g.scheduleBehind(); });
              return false;
            }
            return true;
          });
        },
      },
      { id: 'trash', text: () => (g.item === 'trash' ? 'کیسه زباله را به سطل «پشت ساختمان» ببر' : 'کیسه زباله‌ی کنار صندوق را بردار'), done: () => !!this.f.trash, start: () => { this.allowRandomCustomers = true; } },
      {
        id: 'deliver', text: () => (g.item === 'hotdog' ? 'هات‌داگ را به راننده کامیون در «جایگاه ۲» تحویل بده' : 'راننده کامیون هات‌داگ سفارش داده. با دستگاه روی پیشخوان یکی درست کن'), done: () => !!this.f.delivered,
        start: () => {
          const c = g.npcs.spawn({ arch: 'trucker', role: 'waiting', at: V(6.6, 0, 13.0), yaw: Math.PI });
          c.faceYaw = Math.PI;
            this.interact('trucker', V(6.6, 1.5, 13), () => (!this.f.delivered && g.item === 'hotdog' ? 'تحویل هات‌داگ' : null), async () => {
            g.setItem(null); this.f.delivered = true;
            c.speak('دستت درد نکنه رفیق.');
            await g.sleep(3);
            c.speak('اون یارو اون‌ور جاده... از کی اونجا وایساده؟');
            const t = g.monsters.ensure('tall', () => new TallMonster(g));
            t.appear(V(-8, 0, 43), false, 30);
            await g.sleep(4);
            c.speak('من دیگه می‌رم. تو هم اگه جای من بودی می‌رفتی.');
            await g.sleep(2.5);
            c.state = 'exit'; c.goTo(V(30, 0, 24));
          }, 2.4);
        },
      },
      {
        id: 'inventory', text: () => `موجودی قفسه‌های «انبار» را شمارش کن (${fa([0, 1, 2].filter((i) => this.f['inv' + i]).length)}/۳)`, done: () => [0, 1, 2].every((i) => this.f['inv' + i]),
      },
      {
        id: 'note2', text: () => 'صدای عجیبی از «انبار» می‌آید. بررسی کن', done: () => !!this.f.note2 && !ui.get().note,
        start: () => {
          const knock = () => { if (this.f.note2 || !this.g.station) return; audio.knock(V(-4, 1, -11), 3, 0.55, 0.4); g.after(9 + Math.random() * 5, knock); };
          g.after(3, knock);
        },
      },
    ];
  }

  // ======================= CHAPTER 4 – they come =======================
  private setupCh4() {
    const g = this.g; const st = this.st; const a = st.a;
    this.clockStart = 260; this.clockSpan = 40;
    if (this.taskIndex <= 1) g.player.teleport(a.cashier, Math.PI); else g.player.teleport(V(-6, 0, -8), Math.PI);
    if (this.taskIndex === 0) this.card('فصل ۴ — آن‌ها می‌آیند', '۰۴:۲۰ بامداد • باران');
    if (this.f.powerOut && !this.f.generator) this.powerAll(false);
    // fuel can
    this.interact('fuel', st.items.fuel.position.clone().setY(0.5), () => (this.tid() === 'fuel' && st.items.fuel.visible && !g.item ? 'برداشتن گالن بنزین' : null), () => { this.pick('fuel', st.items.fuel, 0.6); this.f.fuel = true; }, 1.8);
    // generator
    let pulls = 0;
    this.interact('wrench', st.a.wrench, () => (this.tid() === 'wrench' && !g.item && st.items.wrench.visible ? 'برداشتن آچار' : null), () => this.pick('wrench', st.items.wrench, 1.2), 1.8);
    this.interact('gen', a.generator, () => {
      if (!['genfuel', 'wrench', 'generator'].includes(this.tid() ?? '')) return null;
      if (!this.f.genFuel) return g.item === 'fuel' ? 'ریختن بنزین در ژنراتور' : 'ژنراتور بنزین ندارد';
      if (!this.f.genFixed) return g.item === 'wrench' ? 'سفت کردن پیچ‌های ژنراتور با آچار' : 'پیچ‌های ژنراتور شل است (آچار لازم)';
      return 'کشیدن هندل ژنراتور';
    }, async () => {
      if (this.f.genFuel && !this.f.genFixed) {
        if (g.item !== 'wrench') return;
        g.player.frozen = true;
        for (let i = 0; i < 6; i++) { audio.clink(a.generator); await g.sleep(0.35); }
        g.player.frozen = false; g.setItem(null); this.f.genFixed = true; g.emitNoise(a.generator, 12);
        return;
      }
      if (!this.f.genFuel) {
        if (g.item !== 'fuel') return;
        g.player.frozen = true; await g.tween(2, () => { if (Math.random() < 0.08) audio.footstep('wet', 0.15, a.generator); });
        g.player.frozen = false; g.setItem(null); this.f.genFuel = true; return;
      }
      pulls++;
      g.emitNoise(a.generator, 26);
      audio.generatorPull(a.generator, pulls >= 3);
      if (pulls >= 3) {
        this.f.generator = true;
        this.ambienceGen();
        // only the outside circuit comes back – the store breakers tripped
        for (const n of ['back', 'canopy', 'sign']) { st.lights[n]?.set(true); st.lights[n]?.flicker(0.7); await g.sleep(0.25); }
        this.think('بیرون روشن شد... ولی داخل هنوز تاریکه. فیوزها پریدن.', 3.5);
      } else g.toast(pulls === 1 ? 'روشن نشد...' : 'یک بار دیگر...');
    }, 2.2);
    // breaker reset
    this.interact('breaker4', a.breaker, () => (this.tid() === 'breaker' ? 'بالا زدن فیوزهای اصلی' : null), async () => {
      audio.door(a.breaker, false, true); this.f.powerOut = false; this.f.breakerReset = true;
      for (const n of ['staff', 'corridor', 'toilet', 'storage', 'sales']) { st.lights[n]?.set(true); st.lights[n]?.flicker(0.8); audio.click(); await g.sleep(0.3); }
    }, 1.8);
    // back door barricade
    this.backLockFn = async () => {
      if (this.f.backLocked || this.lockingBack) return;
      this.lockingBack = true;
      const d = st.doors.back;
      // the door must be shut first – push the player clear of the doorway so it can close
      if (Math.abs(g.player.pos.z - -12) < 0.7 && Math.abs(g.player.pos.x - -10) < 0.9) g.player.pos.z = -11.1;
      d.broken = false; d.bangHits = 0; d.autoClose = false; d.setOpen(false); d.angle = 0; d.target = 0;
      g.player.frozen = true;
      await g.sleep(0.4); audio.clink(d.pos); await g.sleep(0.6); audio.door(d.pos, false, true);
      d.locked = true; this.f.backLocked = true; g.player.frozen = false; this.lockingBack = false;
      // visible barricade: a heavy shelf pushed against the door
      const bar = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.9, 0.45), new THREE.MeshStandardMaterial({ color: 0x4a5560, metalness: 0.5, roughness: 0.5 }));
      bar.position.set(-10, 0.95, -11.6); st.dyn.add(bar); g.col!.addCentered(-10, -11.6, 1.4, 0.45, { maxY: 1.9 });
      g.toast('🔒 در پشتی قفل و سد شد');
      g.after(2, () => { audio.knock(d.pos, 3, 1, 0.5); g.player.shake = 0.5; this.think('یه چیزی داره به در می‌کوبه...', 3); });
      g.after(5, () => { audio.growl(d.pos.clone().add(V(0, 0, -1.5)), 0.6); audio.knock(d.pos, 5, 1.1, 0.3); });
    };
    // key
    this.interact('key', st.items.key.position, () => (this.tid() === 'key' && st.items.key.visible ? 'برداشتن کلید دفتر مدیر' : null), () => { this.f.hasKey = true; st.items.key.visible = false; st.doors.office.locked = false; audio.clink(); }, 1.6);
    if (this.f.generator) this.ambienceGen();
    if (this.f.generator && !this.f.breakerReset) for (const n of ['back', 'canopy', 'sign']) st.lights[n]?.set(true);
    if (this.f.backLocked) {
      st.doors.back.locked = true; st.doors.back.setOpen(false, true);
      const bar = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.9, 0.45), new THREE.MeshStandardMaterial({ color: 0x4a5560, metalness: 0.5, roughness: 0.5 }));
      bar.position.set(-10, 0.95, -11.6); st.dyn.add(bar); st.col.addCentered(-10, -11.6, 1.4, 0.45, { maxY: 1.9 });
    }

    this.tasks = [
      {
        id: 'shifter', text: () => (this.shifter && this.shifter.removed ? 'فرار کن! یک جای امن پیدا کن و مخفی شو' : 'به مشتری رسیدگی کن'), done: () => !!this.f.shifterGone,
        start: () => {
          g.after(5, () => {
            const c = g.npcs.spawn({ arch: ['worker', 'woman', 'oldman', 'youth'][Math.floor(Math.random() * 4)], role: 'shifter' });
            this.shifter = c;
            let t = 0;
            g.onFrame((dt) => {
              if (c.removed) return false;
              if (c.inStore()) t += dt;
              const near = c.pos.distanceTo(g.player.pos) < 9;
              if ((t > 14 && near && c.holding) || t > 40) { this.triggerShift(c); return false; }
              return true;
            });
          });
          // completion watcher
          g.onFrame(() => {
            const sm = g.monsters.get<ShifterMonster>('shifter');
            if (sm && sm.state === 'gone' && !g.player.hide) { this.f.shifterGone = true; return false; }
            if (sm && sm.state === 'gone' && g.player.hide) { this.f.shifterGone = true; return false; }
            return true;
          });
        },
      },
      {
        id: 'fuel', text: () => 'برق رفته! گالن بنزین را از «انبار» بردار', done: () => !!this.f.fuel,
        start: () => {
          if (!this.f.powerOut) {
            this.f.powerOut = true;
            this.powerAll(false); st.lights.back.flicker(1); audio.door(V(0, 3, 0), false, true);
            g.after(1.5, () => this.think('برق کل پمپ رفت... ژنراتور پشت ساختمانه.', 3.5));
          }
          st.doors.front.locked = false;
          this.g.director.reset(true, 40);
        },
      },
      { id: 'genfuel', text: () => 'گالن را به ژنراتور «پشت ساختمان» ببر و بنزین بریز', done: () => !!this.f.genFuel },
      {
        id: 'wrench', text: () => (g.item === 'wrench' ? 'پیچ‌های شل ژنراتور را با آچار سفت کن' : 'ژنراتور خراب است. یک آچار از دیوار «ابزار و لوازم خودرو» فروشگاه بیاور'), done: () => !!this.f.genFixed,
        start: () => {
          const dog = g.monsters.ensure('dog', () => new DogMonster(g));
          dog.aggressive = true;
          g.after(6, () => { if (!dog.chasing) dog.observeAt(V(-24, 0, -24)); dog.t = 18; });
        },
      },
      { id: 'generator', text: () => 'هندل ژنراتور را بکش تا روشن شود (صدا زیاد است!)', done: () => !!this.f.generator },
      { id: 'breaker', text: () => 'فیوزهای اصلی را در تابلو برق «اتاق کارکنان» بالا بزن', done: () => !!this.f.breakerReset },
      {
        id: 'cctv4', text: () => 'دوربین‌ها را چک کن. چیزی پشت ساختمان حرکت می‌کرد', done: () => !!this.f.cctv4,
        start: () => {
          const dog = g.monsters.get<DogMonster>('dog'); if (dog && !dog.chasing) dog.vanish();
          const fig = new THREE.Group(); // cctv-only silhouette of the dog at the back door
          const s = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 1.6, 4, 8), new THREE.MeshBasicMaterial({ color: 0x050505 })); s.position.set(-10, 1.1, -13.5); fig.add(s);
          const e1 = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 4), new THREE.MeshBasicMaterial({ color: 0xffffff })); e1.position.set(-10.06, 2.0, -13.3); fig.add(e1);
          const e2 = e1.clone(); e2.position.x = -9.94; fig.add(e2);
          g.scene.add(fig); fig.traverse((o) => o.layers.set(2));
          g.onFrame(() => {
            if (!this.g.station) return false;
            if (g.cctvIndex === 4 && !this.f.cctv4seen) { this.f.cctv4seen = true; audio.stinger(0.2); g.after(1.2, () => audio.knock(st.doors.back.pos, 3, 0.9, 0.35)); }
            if (this.f.cctv4seen && g.cctvIndex < 0) { this.f.cctv4 = true; g.scene.remove(fig); this.think('اون پشت در عقبیه... باید درو ببندم!', 3); return false; }
            return true;
          });
        },
      },
      { id: 'barricade', text: () => 'سریع! در پشتی «انبار» را قفل کن', done: () => !!this.f.backLocked },
      {
        id: 'phone', text: () => 'تلفن «اتاق کارکنان» زنگ می‌زند', done: () => !!this.f.phoneAnswered,
        start: () => {
          const d = g.monsters.get<DogMonster>('dog'); if (d && d.chasing) { /* keep chasing */ } else if (d) d.vanish();
          g.after(3, () => { this.phoneRing?.stop(); this.phoneMode = 'script'; this.phoneBusy = true; this.phoneRing = audio.ring(st.a.phone, 'phone'); });
        },
      },
      { id: 'key', text: () => 'کلید دفتر مدیر را از روی میز «اتاق کارکنان» بردار', done: () => !!this.f.hasKey },
    ];
  }
  private ambienceGen() { if (!this.g.ambience.gen) this.g.ambience.gen = audio.hum(this.st.a.generator, 35, 0.12); }

  triggerShift(c: Customer) {
    const g = this.g; const st = this.st;
    if (c.removed || (c as any)._shifting) return;
    (c as any)._shifting = true;
    c.state = 'idle'; c.faceYaw = null;
    st.lights.sales.flicker(2.6); audio.staticBurst(0.8, 0.08);
    g.after(2.4, () => {
      st.lights.sales.set(false); audio.door(V(0, 3, 0), false, true);
      g.after(0.7, () => {
        st.lights.sales.set(true); st.lights.sales.unstable = 0.04;
        c.removed = true;
        const sm = new ShifterMonster(g, c.h, c.pos.clone(), c.yaw);
        g.monsters.add(sm);
        st.doors.front.setOpen(false); st.doors.front.locked = true;
      });
    });
  }

  // ======================= CHAPTER 5 – the secret =======================
  private setupCh5() {
    const g = this.g; const st = this.st; const a = st.a;
    this.clockStart = 300; this.clockSpan = 60;
    if (this.taskIndex >= 6 && this.f.basement) g.player.teleport(a.basementSpawn, 0);
    else g.player.teleport(V(6, 0, -10), Math.PI / 2);
    if (this.taskIndex === 0) this.card('فصل ۵ — راز پمپ', '۰۵:۰۰ بامداد');
    st.doors.office.locked = false;
    this.interact('note3', st.items.note3.position.clone().setY(1.0), () => 'خواندن دفترچه‌ی مدیر', () => {
      const first = !this.f.note3;
      this.readNote(3);
      if (first) this.noteCb = () => this.startHunt();
    }, 1.8);
    this.interact('hatch', a.hatch, () => (this.f.note3 ? 'باز کردن دریچه و پایین رفتن' : 'دریچه‌ای فلزی در کف...'), async () => {
      if (!this.f.note3) { this.think('قفل نیست... ولی اول باید بفهمم اینجا چه خبره.', 3); return; }
      await g.fadeTo(1, 0.6); audio.door(a.hatch, true, true);
      g.player.teleport(a.basementSpawn, Math.PI * 0.75);
      this.f.basement = true;
      await g.fadeTo(0, 0.8);
      if (!this.g.ambience.heart) this.g.ambience.heart = audio.drone(0.1);
      audio.whisper(V(12.5, -4.5, -10), 0.25, 3);
    }, 2.0);
    this.interact('ladder', a.ladder, () => 'بالا رفتن از نردبان', async () => {
      await g.fadeTo(1, 0.5); g.player.teleport(a.officeSpawn, Math.PI / 2);
      // never let a hunter camp right above the hatch (was an unfair instant death)
      g.monsters.list.forEach((m) => { if (m.root.visible && m.pos.distanceTo(a.officeSpawn) < 9) { m.place(V(-8, 0, -0.6)); m.path = []; } });
      await g.fadeTo(0, 0.6);
      if (!this.f.tallHunt) { this.f.tallHunt = true; const t = g.monsters.ensure('tall', () => new TallMonster(g)); t.appear(V(0, 0, -11.4), true); }
      const d = g.monsters.ensure('dog', () => new DogMonster(g)); d.aggressive = true; if (!d.chasing) { d.place(V(-25, 0, 10)); d.show(true); d.setState('cutoff'); }
    }, 1.8);
    // ---- name tags of the four missing employees (the faces on the posters) ----
    const NAMES = ['محمد رضایی', 'سارا کریمی', 'علی نوروزی', 'حسین یزدانی'];
    const tagPos = [V(4.3, 1.05, -11.26), V(6.9, 0.03, -7.3), V(-3.2, 0.52, -9), V(-5.6, 0.03, -15.8)];
    const tagWhere = ['کمدهای اتاق کارکنان', 'سرویس بهداشتی', 'جعبه‌های انبار', 'کنار سطل زباله‌ی پشت ساختمان'];
    const tagCount = () => [0, 1, 2, 3].filter((i) => this.f['tag' + i]).length;
    NAMES.forEach((name, i) => {
      const cv = document.createElement('canvas'); cv.width = 256; cv.height = 128; const c = cv.getContext('2d')!;
      c.fillStyle = '#f2f2ee'; c.fillRect(0, 0, 256, 128); c.fillStyle = '#0d3a6a'; c.fillRect(0, 0, 256, 36);
      c.fillStyle = '#fff'; c.font = '900 22px Arial'; c.textAlign = 'center'; c.fillText('PETRO 24', 128, 26);
      c.fillStyle = '#111'; c.font = '900 30px Vazirmatn, Tahoma'; c.direction = 'rtl'; c.fillText(name, 128, 78);
      c.font = 'bold 16px Vazirmatn, Tahoma'; c.fillStyle = '#a00'; c.fillText('کارمند شیفت شب', 128, 110);
      c.fillStyle = 'rgba(90,0,0,0.6)'; c.beginPath(); c.arc(40 + i * 50, 90, 14, 0, Math.PI * 2); c.fill();
      const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace;
      const tag = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.06, 0.006), new THREE.MeshStandardMaterial({ map: t, roughness: 0.4, emissive: 0xffffff, emissiveMap: t, emissiveIntensity: 0.12 }));
      tag.position.copy(tagPos[i]); if (tagPos[i].y < 0.1) tag.rotation.x = -Math.PI / 2; else if (i === 0) tag.rotation.y = 0; else tag.rotation.x = -Math.PI / 2;
      tag.visible = !this.f['tag' + i]; st.dyn.add(tag);
      this.interact('tag' + i, tagPos[i].clone().setY(Math.max(0.5, tagPos[i].y)), () => (tag.visible && this.f.note3 ? 'برداشتن کارت نام' : null), () => {
        tag.visible = false; this.f['tag' + i] = true; audio.clink(tagPos[i]);
        audio.whisper(tagPos[i].clone().setY(1.5), 0.14, 1.8);
        g.say(undefined, `«${name}»... صدای ضعیفی اسم را تکرار می‌کند.`, 3.5);
        if (tagCount() === 4) g.after(3.6, () => this.think('هر چهار نفر... همون صورت‌های روی پوسترها. اونا هنوز اینجان.', 4));
      }, 1.8);
    });
    // ---- jerry can (empty) near the generator, fill at pump 2 ----
    const jerry = jerryCan(0xb81414); jerry.rotation.y = 0.4;
    jerry.position.set(8.9, 0, -15.2); jerry.visible = !this.f.jerryTaken; st.dyn.add(jerry);
    st.items.jerry = jerry; st.items.jerryEmpty = jerry;
    this.interact('jerry', V(8.9, 0.6, -15.2), () => (jerry.visible && !g.item && this.f.note3 ? 'برداشتن گالن خالی' : null), () => { this.f.jerryTaken = true; this.pick('jerryEmpty', jerry, 0.7); }, 1.8);
    this.interact('fill', a.pump2, () => (g.item === 'jerryEmpty' ? (this.f.estop ? 'پمپ‌ها قطع شده‌اند!' : 'پر کردن گالن با بنزین') : null), async () => {
      if (this.f.estop) return;
      const disp = st.pumps[2]; const nz = disp.nozzles.find((n) => n.side === -1)!;
      g.player.frozen = true;
      const front = g.camera.position.clone().add(g.player.forward().multiplyScalar(0.55)).add(V(0, -0.55, 0));
      disp.moveNozzle(nz, front, front.clone().add(V(0, -1, 0)).add(g.player.forward().multiplyScalar(0.3)));
      audio.clink(front); const hum = audio.hum(front, 70, 0.08);
      await g.tween(4, (k) => { disp.setDisplay(-1, k * 20, 0); });
      hum?.stop(0.3); disp.moveNozzle(nz, null); audio.clink(front);
      g.player.frozen = false; this.f.jerryFull = true;
      g.setItem('jerry', (() => { const c = jerry.clone(); c.visible = true; c.scale.setScalar(0.7); return c; })());
      // the heart notices you are stealing its fuel
      g.flicker('canopy', 1.5); audio.growl(V(0, -4, -8), 0.5);
    }, 2.4);
    // ---- emergency stop on the canopy pillar: the pumps feed the heart ----
    const estop = new THREE.Group(); estop.position.set(-9, 1.4, 11.77); st.dyn.add(estop);
    const ebox = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.3, 0.08), new THREE.MeshStandardMaterial({ color: 0xf2c400, roughness: 0.5 })); estop.add(ebox);
    const ebtn = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.05, 16).rotateX(Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xd0141e, roughness: 0.3, emissive: 0x400000 })); ebtn.position.set(0, 0.02, -0.06); estop.add(ebtn);
    const elab = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 0.06), new THREE.MeshBasicMaterial({ map: (() => { const cv = document.createElement('canvas'); cv.width = 256; cv.height = 64; const c = cv.getContext('2d')!; c.fillStyle = '#f2c400'; c.fillRect(0, 0, 256, 64); c.fillStyle = '#111'; c.font = '900 26px Vazirmatn, Tahoma'; c.textAlign = 'center'; c.direction = 'rtl'; c.fillText('قطع اضطراری', 128, 42); const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t; })() }));
    elab.position.set(0, -0.11, -0.042); elab.rotation.y = Math.PI; estop.add(elab);
    const applyEstop = () => {
      st.lights.canopy.set(false); st.pumps.forEach((p) => { p.setDisplay(-1, 0); p.setDisplay(1, 0); });
      (st.heart.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.15;
      ebtn.position.z = -0.035;
    };
    if (this.f.estop) applyEstop();
    this.interact('estop', V(-9, 1.4, 11.6), () => (!this.f.estop && this.f.note3 ? 'زدن کلید قطع اضطراری پمپ‌ها' : null), () => {
      this.f.estop = true; audio.door(V(-9, 1.4, 11.7), false, true); applyEstop();
      audio.scream(V(0, -4, -8), 0.5); g.player.shake = 0.7;
      g.after(1.5, () => this.think('صدای جیغ از زیر زمین... قلب داره ضعیف می‌شه!', 3.5));
      const t = g.monsters.ensure('tall', () => new TallMonster(g)); t.appear(V(-14, 0, 22), true);
    }, 1.8);
    // ---- heart: free the names / burn ----
    this.interact('heart', V(12.5, -4.4, -8.2), () => {
      if (this.fireActive) return null;
      if (tagCount() === 4 && !this.f.freed) return 'گذاشتن کارت‌های نام کنار قلب';
      if (!g.save.hasLighter) return tagCount() < 4 && !this.f.freed ? 'یک قلب زنده... (چیزی کم است)' : 'به آتش نیاز داری...';
      return g.item === 'jerry' ? 'ریختن بنزین و آتش زدن قلب' : 'آتش زدن قلب (بدون بنزین؟)';
    }, () => {
      if (tagCount() === 4 && !this.f.freed) { this.freeSouls(NAMES); return; }
      if (g.save.hasLighter) this.burn();
    }, 2.6);
    this.interact('contract', st.items.contract.position, () => 'خواندن قرارداد', () => {
      g.openDialogue('قرارداد استخدام دائم — شیفت شب',
        'امضاکننده می‌پذیرد که از امشب تا ابد، شیفت شب پمپ بنزین را بر عهده بگیرد. در عوض، هرگز گرسنه، خسته یا تنها نخواهد بود.\n\nکارکنان دائم: حسین یزدانی (۱۳۷۲) • محمد رضایی (۱۳۹۸) • سارا کریمی (۱۴۰۰) • علی نوروزی (۱۴۰۱)\n\nو خط آخر، از قبل تایپ شده: «کارمند جدید شیفت شب — امشب»',
        [{ id: 'sign', text: '✍️ امضا کن' }, { id: 'no', text: '📄 قرارداد را پاره کن' }], (id) => {
          g.closeDialogue();
          if (id === 'sign') { audio.scream(undefined, 0.4); g.player.shake = 0.8; this.think('دستم... خودش داشت می‌نوشت! نه. نه!', 3); }
          this.f.contract = true; audio.staticBurst(0.4, 0.1); audio.scream(V(12.5, -4.5, -10), 0.4);
          this.think('اسم‌هاشون اینجاست... اونا هنوز به این قرارداد بسته‌ان.', 4);
        });
    }, 1.8);
    if (this.f.freed) (st.heart.material as THREE.MeshStandardMaterial).color.set(0x3a0a0a);
    this.tasks = [
      { id: 'office', text: () => 'دفتر مدیر را بگرد و دفترچه‌اش را بخوان', done: () => !!this.f.note3 && !ui.get().note, start: () => this.g.director.reset(true, 60) },
      {
        id: 'tags', text: () => { const n = tagCount(); const next = [0, 1, 2, 3].find((i) => !this.f['tag' + i]); return `کارت نام ۴ کارمند گمشده را پیدا کن (${fa(n)}/۴)${next !== undefined ? ' — ' + tagWhere[next] + '؟' : ''}`; },
        done: () => tagCount() === 4, start: () => { if (this.f.note3 && !g.monsters.get('faceless')) this.startHunt(); },
      },
      { id: 'jerry', text: () => (g.item === 'jerryEmpty' ? 'گالن را در «جایگاه ۲» با بنزین پر کن' : 'یک گالن خالی کنار ژنراتور «پشت ساختمان» است. برش دار'), done: () => !!this.f.jerryFull },
      { id: 'lighter', text: () => 'فندک را از روی میز «اتاق کارکنان» بردار', done: () => !!g.save.hasLighter },
      { id: 'estop', text: () => 'پمپ‌ها به قلب غذا می‌دهند. کلید «قطع اضطراری» روی ستون جایگاه را بزن', done: () => !!this.f.estop },
      { id: 'basement', text: () => 'دریچه‌ی کف دفتر مدیر را باز کن و پایین برو', done: () => !!this.f.basement },
      { id: 'contract', text: () => 'قرارداد روی میز زیرزمین را بخوان', done: () => !!this.f.contract },
      { id: 'free', text: () => (tagCount() < 4 ? `هنوز همه‌ی کارت‌های نام را نداری (${fa(tagCount())}/۴)` : 'کارت‌های نام را کنار قلب بگذار تا آزاد شوند'), done: () => !!this.f.freed },
      { id: 'burn', text: () => (g.item === 'jerry' ? 'بنزین را روی قلب بریز و با فندک آتشش بزن' : 'برای سوزاندن کامل قلب به گالن بنزین پر نیاز داری'), done: () => !!this.f.burned },
      { id: 'escape', text: () => 'آتش پخش می‌شود! قبل از طلوع به ماشینت برس و فرار کن', done: () => false },
    ];
  }

  private freeSouls(names: string[]) {
    const g = this.g; const st = this.st;
    this.f.freed = true; g.player.frozen = true;
    (st.heart.material as THREE.MeshStandardMaterial).color.set(0x3a0a0a);
    const sm = new THREE.SpriteMaterial({ map: tex.glow(), color: 0xcfe6ff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
    names.forEach((n, i) => {
      const s = new THREE.Sprite(sm); s.scale.setScalar(0.9); s.position.set(11 + i, -5.2, -7.2 + (i % 2) * 0.6); st.fireGroup.add(s);
      g.after(0.6 + i * 1.6, () => { audio.whisper(s.position.clone(), 0.12, 1.4); g.say(n, 'ممنون...', 1.6); });
      g.tween(7 + i * 1.6, (k) => { s.position.y = -5.2 + k * 6; s.material.opacity = 1 - k; });
    });
    g.after(7.5, () => { g.player.frozen = false; this.think('آزاد شدن... حالا فقط اون چیز مونده.', 3.5); });
  }

  private startHunt() {
    const g = this.g;
    g.flicker('office', 2); audio.stinger(0.3);
    const fm = g.monsters.ensure('faceless', () => new FacelessMonster(g));
    fm.appear(V(-6, 0, -0.6), 0, true);
    g.after(2, () => this.think('یه چیزی توی فروشگاه داره حرکت می‌کنه...', 3));
  }

  private burn() {
    const g = this.g; const st = this.st;
    const full = g.item === 'jerry' && !!this.f.estop;
    const why = g.item !== 'jerry' ? 'بنزین کافی نبود...' : 'پمپ‌ها هنوز بهش غذا می‌دن!';
    if (g.item === 'jerry') g.setItem(null);
    this.fireActive = true; this.f.burned = true;
    audio.scream(V(12.5, -4.5, -10), 0.9);
    g.player.shake = 1;
    const fireL = new THREE.PointLight(0xff6a20, 30, 14, 2); fireL.position.set(12.5, -4, -8.5); registerLight(fireL); st.fireGroup.add(fireL);
    this.g.ambience.fire = audio.fire(V(12.5, -4.5, -10), 0.6);
    const flames: THREE.Sprite[] = [];
    const fm = new THREE.SpriteMaterial({ map: tex.glow(), color: 0xff8030, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.8 });
    for (let i = 0; i < 26; i++) { const s = new THREE.Sprite(fm); s.position.set(12.5 + (Math.random() - 0.5) * 3, -5 + Math.random() * 3, -10 + (Math.random() - 0.5) * 3); s.scale.setScalar(0.5 + Math.random()); st.fireGroup.add(s); flames.push(s); }
    (st.fireGroup as any).userData.flames = flames;
    (st.fireGroup as any).userData.light = fireL;
    if (full) {
      g.toast('آتش گرفت!', 2);
      // the creatures are released
      g.monsters.list.forEach((m) => { if (m.state !== 'gone') m.vanish(); });
      this.fireFull = true;
    } else {
      this.think(`نه... ${why} داره دوباره نفس می‌کشه!`, 3.5);
      g.monsters.list.forEach((m) => { if (m instanceof TallMonster) m.appear(V(0, 0, -8.5), true); });
      const d = g.monsters.ensure('dog', () => new DogMonster(g)); d.aggressive = true; d.place(V(-25, 0, 10)); d.show(true); d.setState('cutoff');
      g.after(6, () => { fireL.intensity = 4; flames.forEach((f) => (f.visible = Math.random() < 0.3)); });
    }
    g.director.reset(false);
  }
  private fireFull = false;
  private updateFire(_dt: number) {
    const fg = this.st.fireGroup;
    const flames: THREE.Sprite[] = fg.userData.flames || [];
    flames.forEach((s) => { s.position.y += 0.02; if (s.position.y > -3) s.position.y = -5; s.material.rotation += 0.02; });
    const l = fg.userData.light as THREE.PointLight | undefined;
    if (l && this.fireFull) l.intensity = 25 + Math.random() * 15;
    if (this.fireFull && Math.random() < 0.02) this.g.flicker(this.g.regionOf(this.g.player.pos), 0.5);
  }


  async ending(id: string) {
    if (this.ended) return; this.ended = true;
    const g = this.g;
    g.player.frozen = true; ui.set({ cutscene: true, prompt: null });
    if (id === 'passenger') { audio.engine(0.12); }
    if (id === 'fire') audio.scream(undefined, 0.4);
    await g.fadeTo(1, 2.5);
    unlockEnding(id);
    clearSave();
    const e = ENDINGS[id];
    const stats = `خطاها: ${fa(g.save.violations)}   •   مرگ‌ها: ${fa(g.save.deaths)}   •   یادداشت‌ها: ${fa(g.save.notes.length)}/۵   •   پایان‌های کشف‌شده: ${fa(getEndings().length)}/۸`;
    audio.stopAll();
    if (id === 'passenger' || id === 'eternal') audio.stinger(0.4);
    ui.set({ screen: 'ending', ending: { id, title: e.title, text: e.text, stats }, cutscene: false, fade: 0, objective: null });
    g.running = false;
  }

  // ======================= chapter transitions =======================
  // =====================================================================
  // ======================= 25-CHAPTER CAMPAIGN ========================
  // =====================================================================
  private torches: Torch[] = [];
  private statues: Humanoid[] = [];
  private tickExtras(dt: number) {
    this.torches.forEach((t) => t.update(dt));
    const pl = this.g.player.pos;
    for (const s of this.statues) {
      if (!s.root.parent) continue;
      const want = Math.atan2(pl.x - s.root.position.x, pl.z - s.root.position.z) - s.root.rotation.y;
      const d = Math.atan2(Math.sin(want), Math.cos(want));
      s.neck.rotation.y += (Math.max(-1.4, Math.min(1.4, d)) - s.neck.rotation.y) * Math.min(1, dt * 0.6);
      if (Math.random() < dt * 0.4) { s.neck.rotation.z = (Math.random() - 0.5) * 0.9; s.lArm.rotation.z = -0.3 - Math.random(); }
    }
    if (this.g.station) this.g.station.phoneModel.ringing = !!this.phoneRing || !!this.shRing;
  }
  private spawnStatue(pos: THREE.Vector3, yaw = 0) {
    const arch = ARCHETYPES[Math.floor(Math.random() * ARCHETYPES.length)];
    const h = new Humanoid(arch.style, false);
    transformHuman(h, (['stretch', 'maw', 'crawler'] as const)[Math.floor(Math.random() * 3)]);
    h.root.position.copy(pos); h.root.rotation.y = yaw; this.g.scene.add(h.root);
    this.statues.push(h); return h;
  }
  private addTorch(parent: THREE.Object3D, p: THREE.Vector3, wall = true, id = 'torch' + this.torches.length, gate: () => boolean = () => true) {
    const t = torchStand(parent, p.x, p.y, p.z, wall); this.torches.push(t);
    this.interact(id, p.clone(), () => (!t.lit && gate() ? (this.g.flareT > 0 || this.g.save.hasLighter ? 'روشن کردن مشعل' : 'مشعل خاموش است (به آتش نیاز داری)') : null), () => {
      if (this.g.flareT <= 0 && !this.g.save.hasLighter) return;
      t.setLit(true); audio.fire(p.clone(), 0.12); audio.click();
    }, 2.0);
    return t;
  }
  private givePickup(id: string, mesh: THREE.Object3D, parent: THREE.Object3D, pos: THREE.Vector3, prompt: string, gate: () => boolean, onPick?: () => void, scale = 1) {
    mesh.position.copy(pos); parent.add(mesh);
    this.interact(id, pos.clone().setY(Math.max(0.5, pos.y)), () => (mesh.visible && !this.g.item && gate() ? prompt : null), () => { void scale; this.g.pickUp(id, mesh, onPick); }, 1.9);
    return mesh;
  }
  private shRing: LoopHandle | null = null;

  // ---------- father's diary (one page per extra night) ----------
  static DIARY = [
    'شب اول، ۱۳۶۶. مسعود راد هستم. همسرم باردار است و این کار حقوق خوبی دارد. مدیر گفت فقط شب‌ها بیایم.',
    'مشتری‌ها ساکت‌اند. یکی‌شان صورت نداشت. حساب کردم و رفت. دستم هنوز می‌لرزد.',
    'از زیر دفتر صدای نفس می‌آید. مدیر می‌گوید لوله‌هاست. لوله‌ها نفس نمی‌کشند.',
    'برق رفت. در تاریکی کسی اسمم را صدا زد. صدای خودم بود.',
    'مرد بلند کنار جاده ایستاده بود. وقتی پلک زدم، یک قدم نزدیک‌تر بود.',
    'سگ‌ها روی دو پا راه می‌روند. یکی‌شان لباس فرم پمپ را پوشیده بود.',
    'در آینه‌ی دستشویی، انعکاسم دیرتر از من پلک زد.',
    'مدیر قراردادی آورد. گفت بدهی‌ام بخشیده می‌شود، فقط باید «اولین فرزندم» را برای شیفت شب ثبت کنم. خندیدم. امضا کردم.',
    'ماشینی بدون راننده پشت جایگاه روشن شد. چراغ‌هایش به پنجره‌ی خانه‌ی ما خیره بود.',
    'ساعت چهار تلفن زنگ زد. صدای گریه‌ی یک نوزاد بود. پسرم هنوز به دنیا نیامده.',
    'مه آن‌قدر غلیظ بود که خانه را گم کردم. فهمیدم: پمپ نمی‌گذارد بروم.',
    'پسرم به دنیا آمد. اسمش را آرش گذاشتیم. همان شب، اسمش روی برنامه‌ی شیفت نوشته شد.',
    'شب‌ها طولانی‌تر می‌شوند. ساعت روی دیوار دیگر جلو نمی‌رود.',
    'تصمیمم را گرفتم. جای او می‌مانم. شاید قرارداد با یک «راد» راضی شود.',
    'آرش، اگر این را می‌خوانی، یعنی صدایت کرده‌اند. ساعت دو. همیشه ساعت دو. قرارداد را پیدا کن. نگذار تمام شود.',
  ];

  // ---------- extra nights (chapters 5..19) built from a mission pool ----------
  private setupShift(C: ChapterDef) {
    const g = this.g; const st = this.st; const a = st.a; const k = `s${this.index}_`;
    const F = (n: string) => !!this.f[k + n]; const SF = (n: string, v = true) => { this.f[k + n] = v; };
    this.clockStart = 180; this.clockSpan = C.theme === 'long' ? 1 : 120;
    if (this.taskIndex === 0) { g.player.teleport(a.spawnPlayer, yawTo(a.spawnPlayer, V(0, 0, 4))); this.card(`فصل ${fa(this.index)} — ${C.title}`, C.sub, 4); }
    else g.player.teleport(a.cashier, Math.PI);
    this.allowRandomCustomers = true;
    this.g.director.reset(true, 35); this.g.director.intensity = 1 + (this.index - 5) * 0.05;
    st.items.spill.visible = false; st.items.wetSign.visible = false; st.items.trash.visible = false; st.items.soda.visible = false;
    st.items.restock.visible = true; st.items.chipsCarton.visible = false; st.lights.storage.unstable = 0;
    st.roller.setOn(true); st.roller.setCount(7); st.roller.cook = 1;
    const theme = C.theme!;
    if (theme === 'rain' || theme === 'countdown') g.setRain(true);
    if (theme === 'fog' && g.scene.fog) (g.scene.fog as THREE.FogExp2).density = 0.065;
    if (theme === 'blackout') st.lights.sales.unstable = 0.08;
    if (theme === 'ghostcar') g.after(25, () => g.director.trigger('carStart'));
    if (theme === 'shelves') { const drop = () => { if (this.g.station !== st) return; g.director.trigger('bottleFall'); g.after(40 + Math.random() * 30, drop); }; g.after(30, drop); }
    if (theme === 'dogs') { const d = g.monsters.ensure('dog', () => new DogMonster(g)); d.aggressive = true; g.after(25, () => { if (!d.chasing) d.observeAt(V(-24, 0, -24)); }); }
    if (theme === 'basement') { const kn = () => { if (this.g.station !== st) return; audio.knock(V(11, -2, -7), 3, 0.5, 0.6); g.after(25 + Math.random() * 20, kn); }; g.after(15, kn); }

    const T = (id: string, text: () => string, done: () => boolean, start?: () => void): TaskDef => ({ id, text, done, start });
    const isT = (id: string) => this.tid() === id;
    const cup = () => { const c = new THREE.Group(); const b = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.032, 0.1, 12), new THREE.MeshStandardMaterial({ color: 0xf4efe6, roughness: 0.6 })); c.add(b); const l = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.042, 0.012, 12), new THREE.MeshStandardMaterial({ color: 0x3a2010 })); l.position.y = 0.055; c.add(l); return c; };
    const P: Record<string, () => TaskDef> = {
      serve: () => {
        let base = 0;
        return T('sh-serve', () => `به مشتری‌ها رسیدگی کن (${fa(Math.max(0, this.served - base))}/۳)`, () => this.served - base >= 3, () => {
          base = this.served;
          const next = () => {
            if (this.served - base >= 3 || this.g.station !== st) return;
            const strange = theme === 'faceless' ? Math.random() < 0.5 : Math.random() < 0.3;
            const c = g.npcs.spawn(strange ? (Math.random() < 0.4 ? { role: 'faceless', quirk: 'line' } : { quirk: (['stare', 'freeze', 'turn', 'reflection'] as const)[Math.floor(Math.random() * 4)], anomalous: true }) : {});
            c.onServed = () => g.after(6 + Math.random() * 5, next); this.watchUnserved(c, next);
          };
          g.after(3, next);
        });
      },
      restock: () => T('sh-restock', () => (g.item === 'chips' ? 'قفسه‌ی چیپس و پفک (انتهای راهروی ۲) را پر کن' : 'کارتن چیپس و پفک را از «انبار» بیاور'), () => F('rs') && st.items.restock.visible, () => { SF('rs'); st.items.restock.visible = false; st.items.chipsCarton.visible = g.item !== 'chips'; }),
      fridge: () => {
        this.interact('sh-soda', st.items.soda.position.clone().setY(0.6), () => (isT('sh-fridge') && st.items.soda.visible && !g.item ? 'برداشتن جعبه نوشابه' : null), () => this.pick('soda', st.items.soda), 1.8);
        this.interact('sh-fill', a.fridge, () => (isT('sh-fridge') && g.item === 'soda' ? 'پر کردن یخچال نوشابه' : null), async () => { g.setItem(null); g.player.frozen = true; for (let i = 0; i < 5; i++) { audio.clink(a.fridge); await g.sleep(0.3); } g.player.frozen = false; SF('fridge'); }, 2.2);
        return T('sh-fridge', () => (g.item === 'soda' ? 'یخچال نوشابه را پر کن' : 'جعبه نوشابه را از «انبار» بیاور'), () => F('fridge'), () => { st.items.soda.visible = g.item !== 'soda'; });
      },
      spill: () => {
        this.interact('sh-mop', V(-2.4, 0.9, -5.6), () => (isT('sh-spill') && !g.item && st.items.mop.visible ? 'برداشتن تی' : null), () => this.pick('mop', st.items.mop, 0.5), 1.8);
        this.interact('sh-clean', V(-11.6, 0.4, 2.0), () => (isT('sh-spill') && st.items.spill.visible ? (g.item === 'mop' ? 'تمیز کردن زمین' : 'زمین کثیف است (تی لازم است)') : null), async () => {
          if (g.item !== 'mop') return; g.player.frozen = true; const s = st.items.spill;
          await g.tween(2, (kk) => s.scale.setScalar(Math.max(0.01, 1 - kk))); s.visible = false; st.items.wetSign.visible = true; g.setItem(null); g.player.frozen = false; SF('spill');
          st.items.mop.visible = true;
        }, 2.4);
        return T('sh-spill', () => (g.item === 'mop' ? 'زمین کنار یخچال‌ها را تمیز کن' : 'یک چیز تیره و چسبناک کف فروشگاه ریخته. تی را از «انبار» بیاور'), () => F('spill'), () => { const s = st.items.spill as THREE.Mesh; s.visible = true; s.scale.set(1, 0.7, 1); (s.material as THREE.MeshStandardMaterial).color.set(this.index > 10 ? 0x3a0606 : 0x3a2a10); });
      },
      trash: () => {
        this.interact('sh-bag', st.items.trash.position.clone().setY(0.5), () => (isT('sh-trash') && st.items.trash.visible && !g.item ? 'برداشتن کیسه زباله' : null), () => this.pick('trash', st.items.trash, 0.55), 1.8);
        this.interact('sh-dump', a.dumpster, () => (isT('sh-trash') && g.item === 'trash' ? 'انداختن زباله در سطل' : null), () => { g.setItem(null); audio.door(a.dumpster, false, true); SF('trash'); g.after(2, () => audio.bark(V(0, 1.5, -27), 0.45)); }, 2.2);
        return T('sh-trash', () => (g.item === 'trash' ? 'کیسه زباله را به سطل «پشت ساختمان» ببر' : 'کیسه زباله‌ی کنار صندوق را بردار'), () => F('trash'), () => { st.items.trash.visible = g.item !== 'trash'; });
      },
      pumps: () => {
        [1, 2].forEach((n) => this.interact('sh-pump' + n, a['pump' + n], () => (isT('sh-pumps') && !F('p' + n) ? `بررسی جایگاه ${fa(n)}` : null), () => { SF('p' + n); audio.beep(a['pump' + n]); g.toast(`جایگاه ${fa(n)}: نازل‌ها سالم • کارت‌خوان فعال`); }, 2.2));
        return T('sh-pumps', () => `جایگاه‌های سوخت را بررسی کن (${fa([1, 2].filter((n) => F('p' + n)).length)}/۲)`, () => F('p1') && F('p2'));
      },
      cctv: () => {
        const seen = new Set<number>();
        return T('sh-cctv', () => `همه‌ی دوربین‌ها را چک کن (${fa(seen.size)}/۵)`, () => seen.size >= 5, () => {
          g.onFrame(() => { if (this.g.station !== st || seen.size >= 5) return false; if (g.cctvIndex >= 0) { if (!seen.has(g.cctvIndex)) { seen.add(g.cctvIndex); if (seen.size === 4 && this.index > 8) { audio.stinger(0.15); g.cctvGlitch = true; g.updateCCTVUI(); g.after(2, () => { g.cctvGlitch = false; }); } } } return true; });
        });
      },
      coffee: () => {
        const c = cup(); c.visible = false; st.dyn.add(c);
        this.interact('sh-brew', a.coffee, () => (isT('sh-coffee') && !this.brewing && !g.item ? 'دم کردن قهوه با دستگاه COFFEE' : null), async () => {
          if (!(await this.brewCoffee())) return;
          SF('cup'); g.setItem('coffee', cup()); g.toast('قهوه آماده شد ☕ حالا روی پیشخوان بگذار');
        }, 2.2);
        this.interact('sh-serveCup', a.register.clone().setY(1.2), () => (isT('sh-coffee') && g.item === 'coffee' ? 'گذاشتن قهوه روی پیشخوان' : null), () => { g.setItem(null); c.position.set(4.9, 1.1, 0.75); c.visible = true; SF('coffee'); audio.clink(c.position); }, 2.2);
        return T('sh-coffee', () => (g.item === 'coffee' ? 'قهوه را روی پیشخوان صندوق بگذار' : 'یک قهوه با دستگاه COFFEE دم کن'), () => F('coffee'));
      },
      hotdog: () => {
        this.interact('sh-hd', a.roller, () => (isT('sh-hotdog') && !g.item ? 'درست کردن هات‌داگ' : null), async () => { g.player.frozen = true; audio.clink(a.roller); await g.sleep(1); g.player.frozen = false; g.setItem('hotdog', makeHotdog()); }, 2.2);
        let cust: Customer | null = null;
        this.interact('sh-hdgive', V(5.5, 1.5, 2.0), () => (isT('sh-hotdog') && g.item === 'hotdog' && cust && !cust.removed ? 'دادن هات‌داگ به مشتری' : null), () => { g.setItem(null); SF('hotdog'); cust?.speak('مرسی... گرمه. خوبه.'); g.after(2.5, () => cust?.leave()); }, 2.4);
        return T('sh-hotdog', () => (g.item === 'hotdog' ? 'هات‌داگ را به مشتری جلوی صندوق بده' : 'مشتری یک هات‌داگ می‌خواهد. با دستگاه روی پیشخوان درست کن'), () => F('hotdog'), () => { cust = g.npcs.spawn({ arch: 'trucker', role: 'waiting', at: V(5.5, 0, 2.2), yaw: Math.PI }); cust.faceYaw = Math.PI; });
      },
      fuelcar: () => T('sh-fuel', () => (this.f.fueling ? 'در حال سوخت‌گیری...' : this.f.carParked ? 'باک ماشین مشتری را در «جایگاه ۱» پر کن' : 'یک ماشین به جایگاه‌ها نزدیک می‌شود...'), () => !!this.f.fueled, () => { this.f.fueled = false; this.customerCar(); }),
      inventory: () => {
        [V(-13.0, 1.2, -8.5), V(-8, 1.2, -11.0), V(-6.5, 1.2, -7.4)].forEach((p, i) => this.interact('sh-inv' + i, p, () => (isT('sh-inv') && !F('inv' + i) ? 'شمارش اجناس قفسه' : null), async () => { g.player.frozen = true; for (let j = 0; j < 3; j++) { audio.clink(p); await g.sleep(0.35); } g.player.frozen = false; SF('inv' + i); if (i === 2) audio.whisper(g.player.pos.clone().setY(1.6), 0.14, 1.6); }, 1.9));
        return T('sh-inv', () => `موجودی قفسه‌های «انبار» را بشمار (${fa([0, 1, 2].filter((i) => F('inv' + i)).length)}/۳)`, () => [0, 1, 2].every((i) => F('inv' + i)));
      },
      breaker: () => {
        this.interact('sh-brk', a.breaker, () => (isT('sh-breaker') ? 'بالا زدن فیوزها' : null), async () => { audio.door(a.breaker, false, true); this.f.powerOut = false; for (const n of ['staff', 'corridor', 'toilet', 'storage', 'sales', 'canopy', 'sign']) { st.lights[n]?.set(true); st.lights[n]?.flicker(0.6); await g.sleep(0.2); } SF('brk'); }, 1.8);
        return T('sh-breaker', () => 'برق رفت! در تاریکی خودت را به تابلو برق «اتاق کارکنان» برسان', () => F('brk'), () => { this.f.powerOut = true; this.powerAll(false); audio.door(V(0, 3, 0), false, true); g.after(2, () => audio.whisper(g.player.pos.clone().setY(1.6), 0.2, 2)); });
      },
      phone: () => {
        this.interact('sh-ph', a.phone, () => (isT('sh-phone') && this.shRing ? 'جواب دادن تلفن' : null), async () => {
          this.shRing?.stop(); this.shRing = null; st.phoneModel.lift(true); audio.click();
          const lines = ['...بیشتر از قبلی‌ها دووم آوردی.', '...پدرت هم همین‌جا می‌ایستاد. پشت همین صندوق.', '...هنوز یادت نیومده؟ ساعت دو.', '...ما منتظریم.'];
          audio.voice(undefined, 80, 2, 0.07, true); g.say('صدای پشت خط', lines[this.index % lines.length], 4);
          await g.sleep(4.5); st.phoneModel.lift(false); SF('phone');
        }, 1.9);
        return T('sh-phone', () => 'تلفن «اتاق کارکنان» زنگ می‌زند', () => F('phone'), () => { this.shRing = audio.ring(a.phone, 'phone'); });
      },
      lock: () => {
        this.interact('sh-lock', st.doors.back.pos, () => (isT('sh-lock') && !F('lock') ? 'بستن و قفل کردن در پشتی' : null), async () => {
          const d = st.doors.back; if (Math.abs(g.player.pos.z + 12) < 0.7) g.player.pos.z = -11.1;
          d.broken = false; d.setOpen(false); d.angle = 0; d.target = 0; await g.sleep(0.5); audio.clink(d.pos); d.locked = true; SF('lock');
          g.after(2, () => audio.knock(d.pos, 4, 0.9, 0.35));
        }, 2.0);
        return T('sh-lock', () => 'در پشتی «انبار» باز مانده. قفلش کن', () => F('lock'), () => { st.doors.back.locked = false; st.doors.back.setOpen(true); });
      },
      find: () => {
        const spots = [V(4.6, 0.82, -11.2), V(-12.5, 0.05, -10.6), V(6.3, 0.05, -7.6), V(-3.0, 0.05, -14.5)];
        const spot = spots[this.index % spots.length];
        const w = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.025, 0.08), new THREE.MeshStandardMaterial({ color: 0x3a2214, roughness: 0.6 }));
        w.visible = !F('wallet');
        this.givePickup('wallet', w, st.dyn, spot, 'برداشتن کیف پول', () => isT('sh-find'), () => { SF('wallet'); g.setItem(null); g.toast('داخل کیف: کارت شناسایی یک «راد»... تاریخ تولد: ۱۳۶۶'); });
        return T('sh-find', () => 'یک مشتری کیف پولش را گم کرده. دنبالش بگرد (اتاق‌ها، انبار، پشت ساختمان)', () => F('wallet'));
      },
      hide: () => {
        let hid = 0;
        return T('sh-hide', () => `مرد بلند داخل آمده! در کمد یا جای امن مخفی شو (${fa(Math.min(12, Math.floor(hid)))}/۱۲)`, () => hid >= 12, () => {
          const t = g.monsters.ensure('tall', () => new TallMonster(g)); t.appear(V(0, 0, 2.6), true);
          g.onFrame((dt) => { if (this.g.station !== st) return false; if (g.player.hide) hid += dt; if (hid >= 12) { t.vanish(); return false; } return true; });
        });
      },
    };
    const finale: Partial<Record<Theme, () => TaskDef>> = {
      rain: () => this.surviveTask(k, 'طوفان! مشعل را روشن کن و کنار جایگاه‌ها دوام بیاور', 30, () => { const d = g.monsters.ensure('dog', () => new DogMonster(g)); d.aggressive = true; d.place(V(-25, 0, 20)); d.show(true); d.setState('chase'); }),
      faceless: () => { let c: Customer | null = null; return T('sh-fl', () => 'مشتری بی‌چهره جلوی صندوق است. فقط حساب کن. هیچ سؤالی نپرس', () => !!c && c.served, () => { c = g.npcs.spawn({ role: 'faceless', quirk: 'line' }); }); },
      basement: () => { this.interact('sh-hatch', a.hatch, () => (isT('sh-listen') ? 'گوش دادن به دریچه' : null), () => { SF('listen'); audio.breath(a.hatch, 0.3, true, 2); }, 2.0); return T('sh-listen', () => 'صدای نفس از زیر دفتر مدیر می‌آید. به دریچه گوش کن', () => F('listen'), () => { st.doors.office.locked = false; }); },
    };
    let sd = this.index * 7919 + 13; const rnd = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
    const keys = Object.keys(P);
    for (let i = keys.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [keys[i], keys[j]] = [keys[j], keys[i]]; }
    const fin = finale[theme] ?? P.serve;
    this.tasks = [...keys.slice(0, 8).map((n) => P[n]()), fin()];
  }
  private surviveTask(k: string, label: string, secs: number, threat: () => void): TaskDef {
    const g = this.g; let t = 0; let started = false;
    return {
      id: 'sh-survive', text: () => `${label} (${fa(Math.min(secs, Math.floor(t)))}/${fa(secs)})`, done: () => t >= secs,
      start: () => {
        if (!started) { started = true; threat(); }
        g.onFrame((dt) => { if (!this.g.station) return false; t += dt * (g.flareT > 0 ? 1.4 : 1); if (t >= secs) { this.f[k + 'surv'] = true; g.monsters.list.forEach((m) => { if (m.kind === 'dog') m.vanish(); }); return false; } return true; });
      },
    };
  }

  private async sleepSequence() {
    const g = this.g; const p = g.player;
    p.frozen = true; ui.set({ cutscene: true });
    await g.fadeTo(0.7, 1.2);
    p.teleport(V(1.55, 0.75 - 1.62, 1.4), -Math.PI / 2); p.pitch = 1.3;
    this.card('خواب...', 'بالاخره', 3);
    audio.heartbeat(0.3); await g.sleep(1.5); audio.heartbeat(0.25);
    await g.fadeTo(1, 2.5);
    await g.sleep(1);
  }

  // ---------- 8: the station that isn't (woke up somewhere else) ----------
  private setupNightmareStation() {
    const g = this.g; const st = this.st; const a = st.a; const k = 'ns_';
    const F = (n: string) => !!this.f[k + n]; const SF = (n: string) => { this.f[k + n] = true; };
    const isT = (id: string) => this.tid() === id;
    g.director.reset(false); this.allowRandomCustomers = false;
    st.setHorror(3); st.doors.front.locked = false; st.doors.office.locked = false; st.heart.visible = true;
    if (this.taskIndex === 0) { g.player.teleport(a.spawnPlayer, yawTo(a.spawnPlayer, V(0, 0, 15))); this.card(`فصل ${fa(this.index)} — پمپی که نیست`, 'بیهوش شدی… و جایی دیگر به هوش آمدی', 4); }
    else g.player.teleport(V(0, 0, 8), Math.PI);
    [V(-8, 0, -0.6), V(-4.5, 0, -0.6), V(-11, 0, 2.7), V(2.4, 0, -0.4), V(0, 0, -8.5), V(-8, 0, -9), V(7, 0, 15), V(-7, 0, 15), V(12, 0, 6)].forEach((p, i) => this.spawnStatue(p, i));
    const fl = flareMesh(); fl.rotation.z = Math.PI / 2; fl.visible = !F('flare');
    this.givePickup('flare', fl, st.dyn, V(-19.6, 1.12, 10.2), 'برداشتن مشعل از روی کاپوت', () => isT('ns-flare'), () => SF('flare'), 1.2);
    const ts = [V(-5, 1.25, 11.8), V(5, 1.25, 11.8), V(-5, 1.25, 18.2), V(5, 1.25, 18.2)].map((p, i) => this.addTorch(st.dyn, p, false, 'ns-t' + i, () => isT('ns-torches')));
    this.interact('ns-reg', a.register.clone().setY(1.2), () => (isT('ns-register') ? 'باز کردن کشوی صندوق' : null), () => { audio.beep(a.register); SF('reg'); g.showNote('کارت شناسایی کارمند', 'پترو ۲۴ — کارمند شیفت شب\n\nنام: مسعود راد\nتاریخ استخدام: ۱۳۶۶\nوضعیت: «دائم»\n\nزیرش با خودکار قرمز: «جانشین: آرش راد — فرزند اول»'); }, 2.4);
    this.interact('ns-off', st.items.note3.position.clone().setY(1.0), () => (isT('ns-office') ? 'برداشتن رونوشت قرارداد' : null), () => { SF('off'); g.showNote('رونوشت قرارداد — ۱۳۶۶', 'من، مسعود راد، می‌پذیرم که در ازای بخشش بدهی‌هایم، اولین فرزندم را برای «شیفت شب» به پمپ پترو ۲۴ بسپارم.\n\nاین قرارداد تنها با دست «جانشین» باطل می‌شود.\n\nاصل قرارداد: زیرزمین'); }, 1.8);
    this.interact('ns-hatch', a.hatch, () => (isT('ns-hatch') ? 'باز کردن دریچه و پایین رفتن' : null), () => SF('down'), 2.0);
    let cctvSeen = false;
    this.tasks = [
      { id: 'ns-walk', text: () => 'کجا هستی؟ به سمت جایگاه‌ها برو', done: () => g.player.pos.distanceTo(V(0, 0, 15)) < 9, start: () => g.after(4, () => this.think('آخرین چیزی که یادمه... دود. آتیش. صدای مینا... الان اینجام؟ همه‌چیز قرمزه.', 5)) },
      { id: 'ns-flare', text: () => 'یک مشعل روی کاپوت ماشینت است. برش دار', done: () => F('flare') || g.item === 'flare' },
      { id: 'ns-light', text: () => 'مشعل را روشن کن (دکمه «استفاده»). سگ‌ها در تاریکی‌اند', done: () => g.flareT > 0, start: () => { const d = g.monsters.ensure('dog', () => new DogMonster(g)); d.aggressive = true; g.after(6, () => { d.place(V(-28, 0, -6)); d.show(true); d.setState('stalk', 30); }); } },
      { id: 'ns-torches', text: () => `چهار مشعل کنار جایگاه‌ها را روشن کن (${fa(ts.filter((t) => t.lit).length)}/۴)`, done: () => ts.every((t) => t.lit) },
      { id: 'ns-enter', text: () => 'وارد فروشگاه شو. به «آن‌ها» زیاد نگاه نکن', done: () => g.inBuilding(g.player.pos), start: () => { const fm = g.monsters.ensure('faceless', () => new FacelessMonster(g)); fm.appear(V(-8, 0, 2.7), 0, true); } },
      { id: 'ns-register', text: () => 'کشوی صندوق را باز کن', done: () => F('reg') && !ui.get().note },
      { id: 'ns-cctv', text: () => 'دوربین‌ها را در «اتاق کارکنان» ببین', done: () => cctvSeen && g.cctvIndex < 0, start: () => g.onFrame(() => { if (g.cctvIndex >= 0 && !cctvSeen) { cctvSeen = true; g.after(1.5, () => this.think('روی دوربین... خودم بودم. پشت صندوق. بی‌صورت.', 4)); } return !cctvSeen; }) },
      { id: 'ns-office', text: () => 'در دفتر مدیر، رونوشت قرارداد را پیدا کن', done: () => F('off') && !ui.get().note },
      { id: 'ns-hatch', text: () => 'دریچه‌ی کف دفتر را باز کن و پایین برو', done: () => F('down') },
    ];
  }

  // ---------- 9: underneath (father) ----------
  private setupNightmareBasement() {
    const g = this.g; const st = this.st; const a = st.a; const k = 'nb_';
    const F = (n: string) => !!this.f[k + n]; const SF = (n: string) => { this.f[k + n] = true; };
    const isT = (id: string) => this.tid() === id;
    g.director.reset(false); this.allowRandomCustomers = false; st.heart.visible = false;
    g.player.teleport(a.basementSpawn, Math.PI * 0.75);
    if (this.taskIndex === 0) this.card(`فصل ${fa(this.index)} — زیر زمین`, 'جایی که همه‌چیز شروع شد', 4);
    g.save.hasLighter = true;
    const BY = -6;
    const t1 = this.addTorch(st.dyn, V(7.78, BY + 1.7, -9), true, 'nb-t1', () => isT('nb-t1'));
    const t2 = this.addTorch(st.dyn, V(15.22, BY + 1.7, -7), true, 'nb-t2', () => isT('nb-t2'));
    const names = [['حسین یزدانی — ۱۳۷۲', 'محمد رضایی — ۱۳۹۸', 'سارا کریمی — ۱۴۰۰', 'علی نوروزی — ۱۴۰۱'], ['مسعود راد — ۱۳۶۶ — «دائم»', 'هر شب به‌جای پسرش'], ['آرش راد', 'جانشین', 'امشب']];
    const wallPos = [V(7.67, BY + 1.5, -11.8), V(15.33, BY + 1.5, -11.0), V(11.5, BY + 1.5, -12.83)];
    wallPos.forEach((p, i) => {
      const cv = document.createElement('canvas'); cv.width = 512; cv.height = 256; const c = cv.getContext('2d')!;
      c.font = '900 34px Vazirmatn, Tahoma'; c.textAlign = 'center'; c.direction = 'rtl'; c.fillStyle = 'rgba(220,200,180,0.8)';
      names[i].forEach((n, j) => c.fillText(n, 256, 50 + j * 56));
      const tx = new THREE.CanvasTexture(cv); tx.colorSpace = THREE.SRGBColorSpace;
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshBasicMaterial({ map: tx, transparent: true, depthWrite: false }));
      m.position.copy(p); m.rotation.y = i === 0 ? Math.PI / 2 : i === 1 ? -Math.PI / 2 : 0; st.dyn.add(m);
      this.interact('nb-w' + i, p, () => (isT('nb-w' + i) ? 'خواندن نوشته‌های دیوار' : null), () => { SF('w' + i); audio.whisper(p, 0.16, 2); g.say(undefined, names[i].join(' • '), 5); }, 2.4);
    });
    const father = new Humanoid({ skin: 0xc49a7c, shirt: 0x1d3a6a, pants: 0x222630, top: 'shirt', hairStyle: 'short', hair: 0x1a120c, faceless: true, build: 1.0 }, false);
    father.root.visible = false; g.scene.add(father.root);
    let looked = 0;
    this.interact('nb-contract', V(12.5, BY + 1.2, -8.3), () => (isT('nb-contract') ? 'برداشتن قرارداد اصلی از میان خاکسترها' : null), () => { SF('contract'); g.showNote('قرارداد اصلی — ۱۳۶۶', 'کاغذی سوخته که نمی‌سوزد. امضای پدرت هنوز تازه است.\n\n«تنها با دست جانشین باطل می‌شود.»\n\nجانشین تویی. اما اینجا نمی‌شود پاره‌اش کرد… باید بیدار شوی.'); }, 2.4);
    this.interact('nb-ladder', a.ladder, () => (isT('nb-ladder') ? 'بالا رفتن از نردبان… به سمت صدای مینا' : null), () => SF('up'), 1.8);
    this.tasks = [
      { id: 'nb-t1', text: () => 'تاریک است. با فندک مشعل اول را روشن کن', done: () => t1.lit },
      { id: 'nb-t2', text: () => 'مشعل دوم را روشن کن', done: () => t2.lit },
      { id: 'nb-w0', text: () => 'روی دیوار چیزی کنده شده. بخوانش', done: () => F('w0') },
      { id: 'nb-w1', text: () => 'نوشته‌ی دیوار روبه‌رو را بخوان', done: () => F('w1') },
      { id: 'nb-w2', text: () => 'نوشته‌ی دیوار انتهایی را بخوان', done: () => F('w2') },
      {
        id: 'nb-turn', text: () => 'کسی پشت سرت نفس می‌کشد. برگرد', done: () => looked > 1.2,
        start: () => {
          const f = g.player.forward(); father.root.position.set(g.player.pos.x - f.x * 2.2, BY, g.player.pos.z - f.z * 2.2);
          father.root.rotation.y = Math.atan2(f.x, f.z); father.root.visible = true; audio.breath(father.root.position.clone().setY(BY + 1.6), 0.25, false, 1.5);
          g.onFrame((dt) => { if (!this.g.station) return false; if (g.isLooking(father.root.position.clone().setY(BY + 1.6), 0.92)) looked += dt; father.animate(dt, 0); return looked <= 1.2; });
        },
      },
      {
        id: 'nb-talk', text: () => 'با او حرف بزن', done: () => F('talk'),
        start: () => {
          const lines = ['...آرش. چقدر بزرگ شدی. صورتت رو یادم نبود... صورت خودم رو هم.', 'سی سال پیش اون کاغذ رو امضا کردم. فکر می‌کردم شوخیه. وقتی فهمیدم، اومدم جای تو بمونم. هر شب.', 'اون تماس ساعت دو من بودم. خواستم بیدارت کنم... نه اینکه صدات کنم.', 'تو الان بین مرگ و زندگی هستی، پسرم. مینا داره صدات می‌کنه. برگرد... و قرارداد رو پاره کن.'];
          let i = 0;
          const say = () => { audio.voice(father.root.position.clone().setY(BY + 1.6), 95, 3, 0.1, false); g.openDialogue('پدر', lines[i], [{ id: 'n', text: i < lines.length - 1 ? '...' : 'باشه، پدر.' }], () => { i++; if (i < lines.length) say(); else { g.closeDialogue(); SF('talk'); father.root.visible = false; g.flicker('basement', 1); } }); };
          g.after(0.5, say);
        },
      },
      { id: 'nb-contract', text: () => 'قرارداد اصلی میان خاکستر قلب است. برش دار', done: () => F('contract') && !ui.get().note },
      { id: 'nb-ladder', text: () => 'از نردبان بالا برو… به سمت صدای مینا', done: () => F('up') },
    ];
  }

  // =====================================================================
  // ================= wife, films, phone, chapters 6 / 7 / 10 ==========
  // =====================================================================
  static FILMS = {
    oldRoad: 'https://videos.pexels.com/video-files/3588881/3588881-hd_1920_1080_18fps.mp4',
    oldCar: 'https://videos.pexels.com/video-files/3588888/3588888-hd_1920_1080_18fps.mp4',
    fire: 'https://videos.pexels.com/video-files/20706788/20706788-hd_1920_1080_25fps.mp4',
    news: 'https://videos.pexels.com/video-files/14367163/14367163-hd_1920_1080_30fps.mp4',
  };
  private wife: Humanoid | null = null;
  private wifeFollow = false;
  spawnWife(pose: 'sleep' | 'stand', pos = V(0.6, 0.73, 2.25), yaw = 0) {
    const h = new Humanoid({ skin: 0xe2b89a, shirt: 0xe6dac4, pants: 0x2a2a35, top: 'knit', sleeves: 'long', hairStyle: 'long', hair: 0x2b1a12, female: true, age: 30, build: 0.9, height: 1.66, photo: 'woman', shoes: 0xd8c8b8 }, false);
    h.root.position.copy(pos);
    if (pose === 'sleep') { h.root.rotation.x = -Math.PI / 2; h.lArm.rotation.x = 0.2; h.rArm.rotation.x = 0.2; h.lArmOverride = h.rArmOverride = true; }
    else h.root.rotation.y = yaw;
    (this.g.house?.dyn ?? this.g.scene).add(h.root);
    this.wife = h; this.wifeFollow = false;
    const g = this.g;
    g.onFrame((dt) => {
      if (this.wife !== h || !h.root.parent) return false;
      if (this.wifeFollow) {
        const pl = g.player.pos; const p = h.root.position;
        const dx = pl.x - p.x, dz = pl.z - p.z, d = Math.hypot(dx, dz);
        let sp = 0;
        if (d > 1.3) {
          let tx = pl.x, tz = pl.z;
          if (g.col?.segmentBlocked(p.x, p.z, pl.x, pl.z, 1, { inflate: 0.2 }) && g.nav) {
            const nav = g.nav; const ids = nav.path(nav.nearest(p.x, p.z, g.col), nav.nearest(pl.x, pl.z, g.col));
            if (ids.length) { let n = nav.nodes[ids[0]]; if (Math.hypot(n.x - p.x, n.z - p.z) < 0.3 && ids[1] !== undefined) n = nav.nodes[ids[1]]; tx = n.x; tz = n.z; }
          }
          const ex = tx - p.x, ez = tz - p.z, el = Math.hypot(ex, ez) || 1;
          sp = Math.min(2.6, d * 0.9);
          p.x += (ex / el) * sp * dt; p.z += (ez / el) * sp * dt;
          g.col?.resolve(p, 0.25, 1.6);
          h.root.rotation.y = Math.atan2(ex, ez);
        } else h.root.rotation.y = Math.atan2(dx, dz);
        h.animate(dt, sp);
      } else if (h.root.rotation.x === 0) h.animate(dt, 0);
      return true;
    });
    return h;
  }
  private wifeTalk(w: Humanoid | null, lines: [string, string][], done?: () => void) {
    const g = this.g; let i = 0;
    const next = () => {
      if (i >= lines.length) { g.closeDialogue(); done?.(); return; }
      const [sp, tx] = lines[i++];
      if (sp === 'مینا') audio.voice(w ? w.root.position.clone().setY(1.5) : undefined, 215, Math.min(3, 0.8 + tx.length * 0.045), 0.1);
      g.openDialogue(sp, tx, [{ id: 'n', text: i < lines.length ? 'ادامه…' : 'باشه' }], next);
    };
    next();
  }
  private nightmareVoices() {
    const g = this.g; const gen = g.gen;
    const lines = ['آرش... بیدار شو... صدامو می‌شنوی؟', 'دکترها می‌گن هنوز امید هست... دستمو فشار بده...', 'سه روزه چشماتو باز نکردی... برگرد پیشم.', 'آتش‌نشان‌ها می‌گن یه کاغذ سوخته تو دستت بود...'];
    let k = 0;
    const tick = () => { if (g.gen !== gen) return; audio.voice(undefined, 210, 2.2, 0.05, true); g.say('صدای مینا — از دور', lines[k++ % lines.length], 4.5); g.after(55 + Math.random() * 30, tick); };
    g.after(25, tick);
  }

  /** phone call responses – every chapter reacts differently */
  handleCall(num: string): { name?: string; lines: [string, string][]; eerie?: boolean; onEnd?: () => void } | null {
    const k = this.setupKey, act = this.chapter;
    if (this.def?.nightmare) {
      if (num === 'wife') return { name: 'مینا ❤', eerie: true, lines: [['مینا', '...آرش؟ تو بیمارستانی... صدامو می‌شنوی؟ بیدار شو عزیزم...'], ['مینا', '...نرو پایین... هر چی هست، نرو...']] };
      return { name: '؟', eerie: true, lines: [['؟', '...شیفت هنوز تموم نشده.']] };
    }
    if (num === 'wife') {
      if (k === 'home1') return { lines: [['مینا', 'آرش؟ من که کنارتم! ... از اون اتاق بهم زنگ می‌زنی؟ برو دیگه، دیرت میشه.']] };
      if (k === 'ch2') return { lines: [['مینا', '...رسیدی؟ خوبه. اونجا چطوره؟'], ['آرش', 'ساکته. خیلی ساکت.'], ['مینا', 'مواظب خودت باش. من بیدارم تا زنگ بزنی.']] };
      if (k === 'ch3') return { lines: [['مینا', 'آرش؟ صدات قطع و وصل میشه... پشت سرت کسی هست؟ یکی داره نفس می‌کشه!']], onEnd: () => audio.breath(undefined, 0.2, false, 1.2) };
      if (k === 'ch4' || k === 'ch5') return { lines: [['مینا', '...الو؟ آرش؟ یه زنی دم در خونه بود، گفت از پمپ بنزین اومده دنبالت...'], ['مینا', 'صورت نداشت آرش... صورت نداشت!']], onEnd: () => audio.stinger(0.15) };
      if (k === 'homeDay' || k === 'finale') return { lines: [['مینا', 'من که همین‌جام عزیزم! بیا پیشم.']] };
      return null;
    }
    if (num === '110') {
      if (k === 'homeDay') return { name: 'پلیس ۱۱۰', lines: [['پلیس', 'پلیس ۱۱۰، بفرمایید.'], ['آرش', 'دیشب توی پمپ بنزین پترو ۲۴، جاده‌ی قدیم... اتفاقای وحشتناکی افتاد. آتیش گرفت.'], ['پلیس', '...پترو ۲۴؟ آقا، اون پمپ از سال ۱۳۶۶ تعطیله. همون سال آتیش گرفت. کارمند شیفت شبش هم گم شد... مسعود راد.'], ['پلیس', 'شما گفتید فامیلیتون چیه؟ ... الو؟']], onEnd: () => { this.f.mo_police = true; } };
      if (k === 'homeFire') return { name: 'پلیس ۱۱۰', lines: [['پلیس', 'برای آتش‌سوزی با ۱۲۵ تماس بگیرید! ماشین گشت هم اعزام شد.']] };
      if (k === 'finale') return { name: 'پلیس ۱۱۰', lines: [['پلیس', 'آقای آرش راد؟ خوب شد زنگ زدید. امروز صبح مردی حدوداً شصت‌ساله رو کنار جاده‌ی قدیم پیدا کردیم.'], ['پلیس', 'خودش رو مسعود راد معرفی می‌کنه. می‌گه پدر شماست. از سی سال گذشته هیچی یادش نیست... جز آدرس خونه‌ی شما.'], ['پلیس', 'همکارام آوردنش. الان باید جلوی در خونه‌تون باشن.']], onEnd: () => { this.f.en_police = true; } };
      if (act >= 3) return { name: 'پلیس ۱۱۰', eerie: true, lines: [['؟', '(خش‌خش)... اینجا کسی نیست که کمکت کنه... تا صبح دووم بیار.']] };
      return { name: 'پلیس ۱۱۰', lines: [['پلیس', 'پلیس ۱۱۰... مشکلی پیش اومده؟ ... خط اضطراریه آقا، مزاحم نشید.']] };
    }
    if (num === '125') {
      if (k === 'homeFire') return { name: 'آتش‌نشانی ۱۲۵', lines: [['آتش‌نشانی', 'آتش‌نشانی ۱۲۵. آدرس؟'], ['آرش', 'خیابون یاس، پلاک ۱۳... خونه‌مون آتیش گرفته! همسرم...'], ['آتش‌نشانی', 'ماشین‌ها اعزام شدن. سریع از خونه خارج شید، خم بشید تا دود نفس نکشید!']], onEnd: () => { this.f.hf_called = true; } };
      return { name: 'آتش‌نشانی ۱۲۵', lines: [['آتش‌نشانی', 'آتش‌نشانی ۱۲۵... حادثه‌ای در این محدوده ثبت نشده.']] };
    }
    if (num === '115') return { name: 'اورژانس ۱۱۵', lines: [['اورژانس', k === 'homeFire' ? 'اورژانس اعزام شد. از دود دور بمونید!' : 'اورژانس ۱۱۵... بیمار هوشیاره؟ ... الو؟']] };
    if (num === 'manager') return act >= 3 && act <= 5 ? { name: 'مدیر پمپ', eerie: true, lines: [['مدیر', '...شیفتت تموم نشده، پسر جون. تا طلوع آفتاب.']] } : null;
    if (num === 'unknown') {
      if (k === 'home1' || k === 'ch2') return { name: 'ناشناس', eerie: true, lines: [['؟', '...ساعت سه. دیر نکن.']] };
      if (k === 'homeDay' || k === 'finale') return { name: 'ناشناس', eerie: true, lines: [['پدر؟', '...آرش... اون کاغذ... پاره‌ش کن...']] };
      return { name: 'ناشناس', eerie: true, lines: [['؟', '(صدای نفس کشیدن)']] };
    }
    return null;
  }

  private setupMorning() { home.morning(this); }
  private setupHomeFire() { home.homeFire(this); }
  private faintSequence() { return home.faint(this); }
  private setupEnding() { home.ending(this); }

  private async chapterEnd() {
    if (this.setupKey === 'home1') { this.driveSequence(); return; }
    if (this.setupKey === 'ch5' || this.setupKey === 'finale') return;
    if (this.setupKey === 'homeDay') { await this.sleepSequence(); }
    if (this.setupKey === 'homeFire') { await this.faintSequence(); }
    this.goChapter(this.index + 1);
  }
  async goChapter(next: number) {
    const g = this.g;
    if (next > LAST_CHAPTER) return;
    g.player.frozen = true; ui.set({ cutscene: true });
    await g.sleep(0.8);
    if (ui.get().fade < 1) await g.fadeTo(1, 1.4);
    g.save.chapter = next; g.save.task = 0; g.save.item = null;
    this.index = next; this.taskIndex = 0;
    g.setItem(null);
    writeSave({ ...g.save });
    g.loadChapter(next, 0).then(() => ui.set({ fade: 0, cutscene: false }));
  }
}