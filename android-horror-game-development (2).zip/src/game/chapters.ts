// 10-chapter campaign (single, linear story – no repeated nights).
export type Setup = 'home1' | 'ch2' | 'ch3' | 'ch4' | 'shift' | 'ch5' | 'homeDay' | 'homeFire' | 'nmHouse' | 'nmStation' | 'nmBasement' | 'finale';
export type Theme = 'rain' | 'faceless' | 'basement' | 'blackout' | 'tall' | 'dogs' | 'mirror' | 'cctv' | 'ghostcar' | 'phone' | 'fog' | 'shelves' | 'long' | 'countdown' | 'last';

export interface ChapterDef {
  title: string; sub: string; setup: Setup; level: 'house' | 'station'; act: number;
  theme?: Theme; night?: number; nightmare?: boolean; daylight?: boolean; clock: number;
}

export const CHAPTERS: ChapterDef[] = [
  { title: '', sub: '', setup: 'home1', level: 'house', act: 1, clock: 120 }, // index 0 unused
  { title: 'بیداری', sub: '۰۲:۰۰ بامداد — خانه‌ی آرش و مینا', setup: 'home1', level: 'house', act: 1, clock: 120 },
  { title: 'اولین شیفت', sub: '۰۳:۰۰ بامداد • پمپ بنزین پترو ۲۴', setup: 'ch2', level: 'station', act: 2, clock: 180 },
  { title: 'مشتری‌های عجیب', sub: '۰۳:۴۰ بامداد', setup: 'ch3', level: 'station', act: 3, clock: 220 },
  { title: 'آن‌ها می‌آیند', sub: '۰۴:۲۰ بامداد • باران', setup: 'ch4', level: 'station', act: 4, clock: 260 },
  { title: 'راز پمپ', sub: '۰۵:۰۰ بامداد', setup: 'ch5', level: 'station', act: 5, clock: 300 },
  { title: 'صبح', sub: '۰۷:۱۰ صبح — بالاخره خانه', setup: 'homeDay', level: 'house', act: 1, daylight: true, clock: 430 },
  { title: 'آتش', sub: 'همان شب • ۰۲:۰۰ بامداد', setup: 'homeFire', level: 'house', act: 4, clock: 120 },
  { title: 'پمپی که نیست', sub: 'جایی بین خواب و بیداری', setup: 'nmStation', level: 'station', act: 5, nightmare: true, clock: 0 },
  { title: 'زیر زمین', sub: 'جایی که همه‌چیز شروع شد', setup: 'nmBasement', level: 'station', act: 5, nightmare: true, clock: 0 },
  { title: 'راز', sub: 'سه روز بعد — پایان', setup: 'finale', level: 'house', act: 1, daylight: true, clock: 600 },
];
export const LAST_CHAPTER = CHAPTERS.length - 1;
