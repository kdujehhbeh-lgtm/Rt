// Photographic cars.
// The real side photo is chroma-keyed and its silhouette is measured column by column. From that profile
// we derive LANDMARKS (bumper top, headlight band, bonnet, windshield base/top, roof, rear window, trunk,
// tail-lamp band). The front & rear views are then drawn with exactly those heights and with widths that
// follow the 3D body's tumblehome, so when they are projected onto the photo-fitted shell every feature
// lands where it belongs (lights on the nose, glass on the glass slope, plate on the bumper…).
// Window pixels are moved into a separate translucent glass layer → the cabin is visible inside.
import * as THREE from 'three';
import sideUrl from '../assets/cars/side.png';
import { finishTex, hiCanvas } from './gfx';
import { tex } from './textures';

export const SIDE = { length: 4.66, frontWheel: 0.813, rearWheel: 0.211, wheelR: 0.0695 };
const HW = 0.86, BELT = 1.0, C = 0.05;
/** body half-width at height y (tumblehome above the belt, tuck below the sill) */
export function hw(y: number) { return y > BELT ? HW - Math.min(1, (y - BELT) / 0.46) * 0.2 : y < 0.35 ? HW - (0.35 - y) * 0.12 : HW; }
const VW = 2.0; // width (m) of the front / rear view canvases
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

// ---------------- loading & keying ----------------
let sideBase: HTMLCanvasElement | null = null;
let loading = false;
const waiters: (() => void)[] = [];
function keyAndCrop(img: HTMLImageElement) {
  const W = img.naturalWidth, H = img.naturalHeight;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const c = cv.getContext('2d', { willReadFrequently: true })!;
  c.drawImage(img, 0, 0);
  const id = c.getImageData(0, 0, W, H); const d = id.data;
  let x0 = W, y0 = H, x1 = 0, y1 = 0;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4; const r = d[i], g = d[i + 1], b = d[i + 2];
    const green = g - Math.max(r, b);
    let a = 1 - (green - 28) / 46; a = clamp(a, 0, 1);
    if (a < 1 && g > Math.max(r, b)) d[i + 1] = Math.max(r, b) + Math.max(0, (g - Math.max(r, b)) * 0.15);
    d[i + 3] = Math.round(a * 255);
    if (a > 0.5) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  }
  c.putImageData(id, 0, 0);
  const cw = x1 - x0 + 1, ch = y1 - y0 + 1;
  const out = document.createElement('canvas'); out.width = cw; out.height = ch;
  out.getContext('2d')!.drawImage(cv, x0, y0, cw, ch, 0, 0, cw, ch);
  return out;
}
function ensureLoaded(cb: () => void) {
  if (sideBase) { cb(); return; }
  waiters.push(cb);
  if (loading) return; loading = true;
  const img = new Image();
  img.onload = () => { try { sideBase = keyAndCrop(img); } catch { sideBase = null; } waiters.splice(0).forEach((f) => f()); };
  img.onerror = () => { waiters.splice(0); };
  img.src = sideUrl;
}

// ---------------- silhouette profile & landmarks ----------------
export interface Landmarks { roofY: number; hoodY: number; wsBase: number; wsTop: number; noseY: number; bumperF: number; trunkY: number; rwBase: number; rwTop: number; tailY: number; bumperR: number; wsX: number }
interface Profile { N: number; top: number[]; L: number; Hm: number; lm: Landmarks }
let prof: Profile | null = null;
function profile(): Profile | null {
  if (prof) return prof;
  if (!sideBase) return null;
  const W = sideBase.width, H = sideBase.height;
  const d = sideBase.getContext('2d')!.getImageData(0, 0, W, H).data;
  const L = SIDE.length, Hm = (L * H) / W, N = 120;
  const raw: number[] = [];
  for (let i = 0; i <= N; i++) {
    const px = Math.min(W - 1, Math.round((i / N) * (W - 1)));
    let ty = -1;
    for (let y = 0; y < H; y++) if (d[(y * W + px) * 4 + 3] > 140) { ty = y; break; }
    raw.push(ty < 0 ? 0.35 : ((H - ty) / H) * Hm);
  }
  const top = raw.map((v, i) => (i === 0 || i === N ? v : (raw[i - 1] + 2 * v + raw[i + 1]) / 4));
  const col = (x: number) => clamp(Math.round(((x + L / 2) / L) * N), 0, N);
  const roofY = Math.max(...top);
  // front: bonnet plateau above the front wheel → windshield base → windshield top
  const fw = col(-L / 2 + SIDE.frontWheel * L); const hoodY = top[fw];
  let a = fw; while (a > N / 2 && top[a] < hoodY + 0.07) a--;
  let b = a; while (b > N / 2 && top[b] < roofY - 0.03) b--;
  const wsBase = clamp(top[a], 0.8, roofY - 0.28), wsTop = clamp(top[b], wsBase + 0.2, roofY - 0.02);
  const noseY = clamp(top[col(L / 2 - 0.22)], 0.55, wsBase - 0.05);
  // rear: trunk deck above the rear wheel → rear window base → top
  const rw = col(-L / 2 + SIDE.rearWheel * L); const trunkY = top[rw];
  let c = rw; while (c < N / 2 && top[c] < trunkY + 0.07) c++;
  let e = c; while (e < N / 2 && top[e] < roofY - 0.03) e++;
  const rwBase = clamp(top[c], 0.85, roofY - 0.22), rwTop = clamp(top[e], rwBase + 0.15, roofY - 0.02);
  const tailY = clamp(top[col(-L / 2 + 0.22)], 0.6, rwBase - 0.04);
  const lm: Landmarks = {
    roofY, hoodY, wsBase, wsTop, noseY, bumperF: 0.22 + (noseY - 0.22) * 0.5,
    trunkY, rwBase, rwTop, tailY, bumperR: 0.22 + (tailY - 0.22) * 0.5, wsX: -L / 2 + (a / N) * L,
  };
  prof = { N, top, L, Hm, lm };
  return prof;
}

// ---------------- drawing helpers (metres → canvas) ----------------
const S = 220;
type Fx = (m: number) => number;
function view(VH: number, draw: (c: CanvasRenderingContext2D, X: Fx, Y: Fx) => void) {
  const { cv, c } = hiCanvas(VW * S, VH * S, 2);
  draw(c, (m) => m * S, (m) => (VH - m) * S);
  return cv;
}
function poly(c: CanvasRenderingContext2D, X: Fx, Y: Fx, pts: number[][], fill: string | CanvasGradient) {
  c.beginPath(); pts.forEach(([x, y], i) => (i ? c.lineTo(X(x), Y(y)) : c.moveTo(X(x), Y(y)))); c.closePath(); c.fillStyle = fill; c.fill();
}
function rect(c: CanvasRenderingContext2D, X: Fx, Y: Fx, x0: number, y0: number, x1: number, y1: number, fill: string | CanvasGradient) {
  c.fillStyle = fill; c.fillRect(X(x0), Y(y1), X(x1) - X(x0), Y(y0) - Y(y1));
}
function vgrad(c: CanvasRenderingContext2D, Y: Fx, y0: number, y1: number, stops: [number, string][]) {
  const g = c.createLinearGradient(0, Y(y1), 0, Y(y0)); stops.forEach(([o, s]) => g.addColorStop(o, s)); return g;
}
const PAINT = (c: CanvasRenderingContext2D, Y: Fx, y0: number, y1: number) => vgrad(c, Y, y0, y1, [[0, '#f6f7f8'], [0.55, '#e4e6e8'], [1, '#b9bdc1']]);
function tire(c: CanvasRenderingContext2D, X: Fx, Y: Fx, x0: number, x1: number) {
  rect(c, X, Y, x0, 0, x1, 0.62, vgrad(c, Y, 0, 0.62, [[0, '#2a2a2a'], [0.5, '#121212'], [1, '#050505']]));
  c.strokeStyle = 'rgba(255,255,255,0.05)'; c.lineWidth = 2;
  for (let y = 0.05; y < 0.6; y += 0.05) { c.beginPath(); c.moveTo(X(x0), Y(y)); c.lineTo(X(x1), Y(y)); c.stroke(); }
}
/** trapezoid following the body tumblehome between heights y0..y1 (inset = pillar width) */
function glassPoly(y0: number, y1: number, inset: number) {
  const cx = VW / 2, pts: number[][] = [];
  for (let k = 0; k <= 6; k++) { const y = y0 + ((y1 - y0) * k) / 6; pts.push([cx - (hw(y) - C - inset), y]); }
  for (let k = 6; k >= 0; k--) { const y = y0 + ((y1 - y0) * k) / 6; pts.push([cx + (hw(y) - C - inset), y]); }
  return pts;
}
function greenhouse(c: CanvasRenderingContext2D, X: Fx, Y: Fx, y0: number, y1: number) {
  poly(c, X, Y, glassPoly(y0, y1 + 0.02, 0), PAINT(c, Y, y0, y1));
}
function glassFill(c: CanvasRenderingContext2D, X: Fx, Y: Fx, pts: number[][], y0: number, y1: number) {
  const g = c.createLinearGradient(X(0.4), Y(y1), X(1.6), Y(y0)); g.addColorStop(0, '#5a7088'); g.addColorStop(0.45, '#1e2a36'); g.addColorStop(1, '#101820');
  poly(c, X, Y, pts, g);
  // diagonal reflection streak
  const cx = VW / 2; poly(c, X, Y, [[cx - 0.42, y1 - 0.01], [cx - 0.2, y1 - 0.01], [cx - 0.42, y0 + 0.01], [cx - 0.62, y0 + 0.01]], 'rgba(255,255,255,0.1)');
}

// ---------------- front & rear views fitted to the landmarks ----------------
interface ViewOut { cv: HTMLCanvasElement; glass: number[][] }
function frontView(p: Profile): ViewOut {
  const lm = p.lm, VH = p.Hm, cx = VW / 2;
  const gl = glassPoly(lm.wsBase + 0.02, Math.min(lm.wsTop, lm.roofY - 0.04), 0.07);
  const cv = view(VH, (c, X, Y) => {
    for (const s of [-1, 1]) { const m = cx + s * (HW - 0.12); tire(c, X, Y, m - 0.11, m + 0.11); }
    rect(c, X, Y, cx - HW + 0.18, 0.1, cx + HW - 0.18, 0.24, '#0e0e0e');
    rect(c, X, Y, cx - HW, 0.2, cx + HW, lm.noseY, PAINT(c, Y, 0.2, lm.noseY));
    // bonnet (seen edge-on from the front, from above it reads as the bonnet surface)
    rect(c, X, Y, cx - HW, lm.noseY, cx + HW, lm.wsBase + 0.02, vgrad(c, Y, lm.noseY, lm.wsBase, [[0, '#fbfcfd'], [1, '#d6d9dc']]));
    c.strokeStyle = 'rgba(0,0,0,0.1)'; c.lineWidth = 2; c.beginPath(); c.moveTo(X(cx - 0.45), Y(lm.wsBase)); c.lineTo(X(cx - 0.55), Y(lm.noseY)); c.moveTo(X(cx + 0.45), Y(lm.wsBase)); c.lineTo(X(cx + 0.55), Y(lm.noseY)); c.stroke();
    greenhouse(c, X, Y, lm.wsBase, lm.roofY);
    glassFill(c, X, Y, gl, lm.wsBase, lm.wsTop);
    c.strokeStyle = '#060606'; c.lineWidth = 4; c.beginPath(); c.moveTo(X(cx - 0.62), Y(lm.wsBase + 0.04)); c.lineTo(X(cx - 0.05), Y(lm.wsBase + 0.08)); c.moveTo(X(cx + 0.02), Y(lm.wsBase + 0.04)); c.lineTo(X(cx + 0.6), Y(lm.wsBase + 0.08)); c.stroke();
    // headlight / grille band
    const b0 = lm.bumperF + 0.02, b1 = lm.noseY - 0.015, bh = b1 - b0;
    for (const s of [-1, 1]) {
      const x0 = s < 0 ? cx - HW + 0.03 : cx + 0.36, x1 = s < 0 ? cx - 0.36 : cx + HW - 0.03;
      rect(c, X, Y, x0, b0, x1, b1, '#1d2226');
      const hl = c.createLinearGradient(0, Y(b1), 0, Y(b0)); hl.addColorStop(0, '#f4f8fa'); hl.addColorStop(0.5, '#b4c0c8'); hl.addColorStop(1, '#e2e8ec');
      rect(c, X, Y, x0 + 0.015, b0 + 0.012, x1 - 0.015, b1 - 0.012, hl);
      for (const k of [0.3, 0.62]) { c.beginPath(); c.arc(X(x0 + (x1 - x0) * (s < 0 ? k : 1 - k)), Y(b0 + bh / 2), bh * 0.32 * S, 0, Math.PI * 2); c.fillStyle = 'rgba(255,255,255,0.7)'; c.fill(); }
      const ax = s < 0 ? x0 + 0.015 : x1 - 0.105; rect(c, X, Y, ax, b0 + 0.012, ax + 0.09, b1 - 0.012, 'rgba(240,150,30,0.75)');
    }
    rect(c, X, Y, cx - 0.35, b0, cx + 0.35, b1, '#101010');
    c.fillStyle = '#2c2c2c'; for (let y = b0 + 0.015; y < b1 - 0.01; y += 0.028) c.fillRect(X(cx - 0.33), Y(y + 0.01), X(cx + 0.33) - X(cx - 0.33), 0.01 * S);
    c.beginPath(); c.arc(X(cx), Y(b0 + bh / 2), 0.04 * S, 0, Math.PI * 2); c.fillStyle = '#c8ccd0'; c.fill();
    // bumper: rubbing strip + chrome, plate recess, lower intake, fog lamps
    rect(c, X, Y, cx - HW, lm.bumperF - 0.09, cx + HW, lm.bumperF, '#1e1e1e'); rect(c, X, Y, cx - HW, lm.bumperF, cx + HW, lm.bumperF + 0.012, '#d8dde2');
    rect(c, X, Y, cx - 0.27, lm.bumperF - 0.13, cx + 0.27, lm.bumperF - 0.015, '#e9e9e6');
    rect(c, X, Y, cx - 0.45, 0.22, cx + 0.45, 0.29, '#161616');
    for (const s of [-1, 1]) { c.beginPath(); c.arc(X(cx + s * 0.66), Y(0.3), 0.04 * S, 0, Math.PI * 2); c.fillStyle = '#d0d5da'; c.fill(); }
    rect(c, X, Y, cx - 0.6, lm.roofY - 0.025, cx + 0.6, lm.roofY, 'rgba(255,255,255,0.65)');
  });
  return { cv, glass: gl };
}
function rearView(p: Profile): ViewOut {
  const lm = p.lm, VH = p.Hm, cx = VW / 2;
  const gl = glassPoly(lm.rwBase + 0.02, Math.min(lm.rwTop, lm.roofY - 0.04), 0.08);
  const cv = view(VH, (c, X, Y) => {
    for (const s of [-1, 1]) { const m = cx + s * (HW - 0.12); tire(c, X, Y, m - 0.11, m + 0.11); }
    rect(c, X, Y, cx - HW + 0.18, 0.1, cx + HW - 0.18, 0.24, '#0e0e0e');
    rect(c, X, Y, cx - HW, 0.2, cx + HW, lm.tailY, PAINT(c, Y, 0.2, lm.tailY));
    rect(c, X, Y, cx - HW, lm.tailY, cx + HW, lm.rwBase + 0.02, vgrad(c, Y, lm.tailY, lm.rwBase, [[0, '#fbfcfd'], [1, '#d2d5d8']]));
    // trunk-lip spoiler
    rect(c, X, Y, cx - HW + 0.08, lm.tailY - 0.01, cx + HW - 0.08, lm.tailY + 0.035, vgrad(c, Y, lm.tailY - 0.01, lm.tailY + 0.035, [[0, '#ffffff'], [1, '#c2c6ca']]));
    greenhouse(c, X, Y, lm.rwBase, lm.roofY);
    glassFill(c, X, Y, gl, lm.rwBase, lm.rwTop);
    c.strokeStyle = 'rgba(120,70,50,0.35)'; c.lineWidth = 1;
    for (let y = lm.rwBase + 0.06; y < lm.rwTop - 0.03; y += 0.035) { const w = hw(y) - C - 0.14; c.beginPath(); c.moveTo(X(cx - w), Y(y)); c.lineTo(X(cx + w), Y(y)); c.stroke(); }
    // tail lamps (red / amber / white), black centre garnish with badge
    const t0 = lm.bumperR + 0.03, t1 = lm.tailY - 0.03;
    for (const s of [-1, 1]) {
      const x0 = s < 0 ? cx - HW + 0.03 : cx + 0.28, x1 = s < 0 ? cx - 0.28 : cx + HW - 0.03;
      rect(c, X, Y, x0, t0, x1, t1, '#1a0505');
      const red = c.createLinearGradient(0, Y(t1), 0, Y(t0)); red.addColorStop(0, '#ff3a2a'); red.addColorStop(0.5, '#b40e0e'); red.addColorStop(1, '#6a0606');
      rect(c, X, Y, x0 + 0.015, t0 + 0.012, x1 - 0.015, t1 - 0.012, red);
      const ax = s < 0 ? x0 + 0.015 : x1 - 0.18; rect(c, X, Y, ax, t0 + 0.012, ax + 0.165, t0 + (t1 - t0) * 0.45, '#f0a020');
      const wx = s < 0 ? x1 - 0.16 : x0 + 0.015; rect(c, X, Y, wx, t0 + 0.012, wx + 0.145, t0 + (t1 - t0) * 0.45, '#e8e8e8');
      c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 2; for (let x = x0 + 0.08; x < x1; x += 0.08) { c.beginPath(); c.moveTo(X(x), Y(t0)); c.lineTo(X(x), Y(t1)); c.stroke(); }
    }
    rect(c, X, Y, cx - 0.28, t0 + 0.02, cx + 0.28, t1 - 0.02, '#151515');
    c.beginPath(); c.arc(X(cx), Y((t0 + t1) / 2), 0.04 * S, 0, Math.PI * 2); c.fillStyle = '#c8ccd0'; c.fill();
    // bumper strip, plate recess, exhaust
    rect(c, X, Y, cx - HW, lm.bumperR - 0.09, cx + HW, lm.bumperR, '#1e1e1e'); rect(c, X, Y, cx - HW, lm.bumperR, cx + HW, lm.bumperR + 0.012, '#d8dde2');
    rect(c, X, Y, cx - 0.27, lm.bumperR - 0.13, cx + 0.27, lm.bumperR - 0.015, '#dcdcd8');
    c.beginPath(); c.arc(X(cx - 0.55), Y(0.21), 0.04 * S, 0, Math.PI * 2); c.fillStyle = '#3a3a3a'; c.fill();
    c.beginPath(); c.arc(X(cx - 0.55), Y(0.21), 0.026 * S, 0, Math.PI * 2); c.fillStyle = '#050505'; c.fill();
    rect(c, X, Y, cx - 0.6, lm.roofY - 0.025, cx + 0.6, lm.roofY, 'rgba(255,255,255,0.65)');
  });
  return { cv, glass: gl };
}

// ---------------- recolouring (white paint → body colour) ----------------
function tint(src: HTMLCanvasElement, color: number) {
  const out = document.createElement('canvas'); out.width = src.width; out.height = src.height;
  const c = out.getContext('2d', { willReadFrequently: true })!; c.drawImage(src, 0, 0);
  const col = new THREE.Color(color);
  if (col.r > 0.82 && col.g > 0.82 && col.b > 0.82) return out;
  const tr = col.r * 1.12, tg = col.g * 1.12, tb = col.b * 1.12;
  const id = c.getImageData(0, 0, out.width, out.height); const d = id.data;
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] < 8) continue;
    const r = d[i], g = d[i + 1], b = d[i + 2];
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
    const lum = (r + g + b) / 765, sat = mx ? (mx - mn) / mx : 0;
    let k = clamp((lum - 0.4) / 0.18, 0, 1) * clamp((0.22 - sat) / 0.1, 0, 1);
    if (lum > 0.93) k *= 0.55;
    if (k <= 0) continue;
    d[i] = r + (Math.min(255, r * tr) - r) * k; d[i + 1] = g + (Math.min(255, g * tg) - g) * k; d[i + 2] = b + (Math.min(255, b * tb) - b) * k;
  }
  c.putImageData(id, 0, 0);
  return out;
}

// ---------------- glass separation ----------------
function inPoly(x: number, y: number, p: number[][]) {
  let ins = false;
  for (let i = 0, j = p.length - 1; i < p.length; j = i++) {
    const [xi, yi] = p[i], [xj, yj] = p[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) ins = !ins;
  }
  return ins;
}
function splitGlass(src: HTMLCanvasElement, isGlass: (px: number, py: number, r: number, g: number, b: number) => boolean) {
  const W = src.width, H = src.height;
  const body = document.createElement('canvas'); body.width = W; body.height = H;
  const glass = document.createElement('canvas'); glass.width = W; glass.height = H;
  const bc = body.getContext('2d', { willReadFrequently: true })!; bc.drawImage(src, 0, 0);
  const gc = glass.getContext('2d')!;
  const bd = bc.getImageData(0, 0, W, H); const gd = gc.createImageData(W, H);
  const a = bd.data, o = gd.data;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4; if (a[i + 3] < 128) continue;
    if (!isGlass(x, y, a[i], a[i + 1], a[i + 2])) continue;
    // clear-ish tinted glass: keep the reflections, mostly see-through (~33% opaque)
    o[i] = Math.min(255, a[i] * 1.1 + 30); o[i + 1] = Math.min(255, a[i + 1] * 1.1 + 36); o[i + 2] = Math.min(255, a[i + 2] * 1.05 + 44); o[i + 3] = 84;
    a[i + 3] = 0;
  }
  bc.putImageData(bd, 0, 0); gc.putImageData(gd, 0, 0);
  return { body, glass };
}
function viewSplit(v: ViewOut, VH: number) {
  return splitGlass(v.cv, (px, py) => inPoly((px / v.cv.width) * VW, VH - (py / v.cv.height) * VH, v.glass));
}
function sideSplit(cv: HTMLCanvasElement, p: Profile) {
  return splitGlass(cv, (px, py, r, g, b) => {
    const ym = ((cv.height - py) / cv.height) * p.Hm;
    if (ym < BELT - 0.03 || ym > p.lm.roofY - 0.035) return false;
    const xm = -p.L / 2 + (px / cv.width) * p.L;
    if (xm > p.lm.wsX + 0.05) return false; // not on the bonnet
    const lum = (r + g + b) / 765;
    return lum < 0.4 && b >= g + 3; // purple-tinted side glass (black pillars & trims stay opaque)
  });
}

// ---------------- skins (cached per paint colour) ----------------
export interface CarSkin { side: THREE.Texture; front: THREE.Texture; rear: THREE.Texture; sideGlass: THREE.Texture; frontGlass: THREE.Texture; rearGlass: THREE.Texture }
const skinCache = new Map<number, CarSkin>();
let frontOut: ViewOut | null = null, rearOut: ViewOut | null = null;
export function getCarSkin(color: number, cb: (s: CarSkin) => void) {
  const hit = skinCache.get(color); if (hit) { cb(hit); return; }
  ensureLoaded(() => {
    const p = profile(); if (!sideBase || !p) return;
    let s = skinCache.get(color);
    if (!s) {
      frontOut ||= frontView(p); rearOut ||= rearView(p);
      const T = (cv: HTMLCanvasElement) => finishTex(new THREE.CanvasTexture(cv));
      const sd = sideSplit(tint(sideBase, color), p);
      const fr = viewSplit({ cv: tint(frontOut.cv, color), glass: frontOut.glass }, p.Hm);
      const rr = viewSplit({ cv: tint(rearOut.cv, color), glass: rearOut.glass }, p.Hm);
      s = { side: T(sd.body), front: T(fr.body), rear: T(rr.body), sideGlass: T(sd.glass), frontGlass: T(fr.glass), rearGlass: T(rr.glass) };
      skinCache.set(color, s);
    }
    cb(s);
  });
}

// ---------------- photo-fitted body ----------------
class GeoB {
  pos: number[] = []; uv: number[] = [];
  tri(a: number[], b: number[], c: number[], ua: number[], ub: number[], uc: number[]) { this.pos.push(...a, ...b, ...c); this.uv.push(...ua, ...ub, ...uc); }
  quad(a: number[], b: number[], c: number[], d: number[], f: (p: number[]) => number[], flip = false) {
    if (flip) { this.tri(a, c, b, f(a), f(c), f(b)); this.tri(a, d, c, f(a), f(d), f(c)); }
    else { this.tri(a, b, c, f(a), f(b), f(c)); this.tri(a, c, d, f(a), f(c), f(d)); }
  }
  build() { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2)); g.computeVertexNormals(); g.computeBoundingSphere(); return g; }
}
export interface PhotoBody { side: THREE.BufferGeometry; front: THREE.BufferGeometry; rear: THREE.BufferGeometry; under: THREE.BufferGeometry; fuel: THREE.Vector3; shield: { x: number; y: number; slope: number }; frontX: number; rearX: number; lm: Landmarks }
let photoBody: PhotoBody | null = null;

export function photoBodyGeo(): PhotoBody | null {
  if (photoBody) return photoBody;
  const p = profile(); if (!p) return null;
  const { N, top, L, Hm, lm } = p;
  const X = (i: number) => -L / 2 + (i / N) * L;
  const topAt = (x: number) => top[clamp(Math.round(((x + L / 2) / L) * N), 0, N)];
  const sideUV = (q: number[]) => [(q[0] + L / 2) / L, Math.min(q[1], topAt(q[0]) - 0.014) / Hm];
  const frontUV = (q: number[]) => [0.5 - q[2] / VW, Math.min(q[1], lm.roofY - 0.012) / Hm];
  const rearUV = (q: number[]) => [0.5 + q[2] / VW, Math.min(q[1], lm.roofY - 0.012) / Hm];
  const Sd = new GeoB(), F = new GeoB(), R = new GeoB();
  const K = 6;
  const rows = (i: number) => { const T = Math.max(0.06, top[i] - C); return [0, Math.min(0.35, T), Math.min(BELT, T), T]; };
  const V = (i: number, r: number, s: number) => { const y = rows(i)[r]; return [X(i), y, s * hw(y)]; };
  const Ct = (i: number, s: number) => [X(i), top[i], s * (hw(top[i]) - C)];
  const Sk = (i: number, k: number) => { const t = -1 + (2 * k) / K; const w = hw(top[i]) - C; const crown = (1 - t * t) * (top[i] > BELT + 0.1 ? 0.035 : 0.018); return [X(i), top[i] + crown, t * w]; };
  for (let i = 0; i < N; i++) {
    for (const s of [-1, 1]) {
      for (let r = 0; r < 3; r++) Sd.quad(V(i, r, s), V(i + 1, r, s), V(i + 1, r + 1, s), V(i, r + 1, s), sideUV, s < 0);
      Sd.quad(V(i, 3, s), V(i + 1, 3, s), Ct(i + 1, s), Ct(i, s), sideUV, s < 0);
    }
    const B = X(i) >= -1e-6 ? F : R; const uvf = B === F ? frontUV : rearUV;
    for (let k = 0; k < K; k++) B.quad(Sk(i, k), Sk(i, k + 1), Sk(i + 1, k + 1), Sk(i + 1, k), uvf);
  }
  const endCap = (i: number, B: GeoB, uvf: (q: number[]) => number[], flip: boolean) => {
    const ring: number[][] = [];
    for (let r = 0; r <= 3; r++) ring.push(V(i, r, -1));
    for (let k = 0; k <= K; k++) ring.push(Sk(i, k));
    for (let r = 3; r >= 0; r--) ring.push(V(i, r, 1));
    const c = [X(i), top[i] * 0.45, 0];
    const T = (a: number[], b: number[]) => (flip ? B.tri(c, b, a, uvf(c), uvf(b), uvf(a)) : B.tri(c, a, b, uvf(c), uvf(a), uvf(b)));
    for (let j = 0; j < ring.length - 1; j++) T(ring[j], ring[j + 1]);
    T(ring[ring.length - 1], ring[0]);
  };
  endCap(N, F, frontUV, false); endCap(0, R, rearUV, true);
  // closed chassis block: floor pan, engine bay & trunk floor → no see-through underneath; its top is the cabin floor
  const under = new THREE.BoxGeometry(L - 0.34, 0.3, 2 * (HW - 0.05)); under.translate(0, 0.37, 0);
  let shield = { x: lm.wsX + 0.15, y: lm.wsBase + 0.12, slope: -0.6 };
  for (let i = N - 2; i > N / 2; i--) if (top[i] > lm.wsBase + 0.12) { shield = { x: X(i), y: top[i], slope: (top[i + 1] - top[i - 1]) / (X(i + 1) - X(i - 1)) }; break; }
  photoBody = { side: Sd.build(), front: F.build(), rear: R.build(), under, fuel: new THREE.Vector3(-L / 2 + 0.115 * L, 0.84, -(HW + 0.02)), shield, frontX: L / 2, rearX: -L / 2, lm };
  return photoBody;
}

/** additive glow sprite for head / tail lights */
export function lampGlow(color: number, size: number) {
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex.glow(), color, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true }));
  s.scale.setScalar(size); s.visible = false; return s;
}
