// First-person player controller: movement, look, crouch, sprint/stamina, head-bob, footsteps, noise, flashlight, hiding
import * as THREE from 'three';
import { input, consumeLook } from './input';
import { audio } from './audio';
import type { Collision } from './physics';
import { settingsStore } from './store';
import type { HideSpot } from './levels/station';

export type Surface = 'tile' | 'concrete' | 'wood' | 'wet' | 'metal';

export class Player {
  pos = new THREE.Vector3();
  yaw = 0; pitch = 0;
  vel = new THREE.Vector3();
  stamina = 1;
  running = false;
  crouchT = 0;
  noise = 0; // current emitted noise radius
  bob = 0; stepAcc = 0;
  frozen = false;
  speedMul = 1;
  flash: THREE.SpotLight;
  flashOn = false;
  hasFlash = false;
  camera: THREE.PerspectiveCamera;
  hide: HideSpot | null = null;
  surfaceFn: (p: THREE.Vector3) => Surface = () => 'concrete';
  shake = 0;
  lookYawLimit: [number, number] | null = null;
  private hideBaseYaw = 0;
  moving = false;
  radius = 0.3;
  heldMesh: THREE.Object3D | null = null;
  holder = new THREE.Group();
  heightFn: ((x: number, z: number, y: number) => number) | null = null;

  constructor(camera: THREE.PerspectiveCamera, shadows: boolean) {
    this.camera = camera;
    this.flash = new THREE.SpotLight(0xfff1dc, 0, 24, 0.42, 0.55, 1.6);
    this.flash.castShadow = shadows;
    if (shadows) { this.flash.shadow.mapSize.set(512, 512); this.flash.shadow.camera.near = 0.2; this.flash.shadow.bias = -0.002; }
    this.flash.position.set(0.15, -0.15, 0.1);
    this.flash.target.position.set(0.05, -0.2, -5);
    camera.add(this.flash); camera.add(this.flash.target);
    this.holder.position.set(0.32, -0.32, -0.55);
    camera.add(this.holder);
  }

  get eye() { return 1.62 - this.crouchT * 0.65; }
  get crouching() { return input.crouch; }

  forward() { return new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw)); }
  lookDir() { const d = new THREE.Vector3(); this.camera.getWorldDirection(d); return d; }

  setFlash(on: boolean) {
    if (!this.hasFlash) on = false;
    this.flashOn = on;
    this.flash.intensity = on ? 38 : 0;
    audio.click();
  }

  /**
   * Put an object in the hand. Fixes the old pickup bug: clones of objects from the frozen static
   * level group kept matrixAutoUpdate=false and stayed at their world position. Also normalises the
   * size (big cartons no longer cover the screen) and draws the item on top so it never clips walls.
   */
  setHeld(mesh: THREE.Object3D | null, fit = 0.3) {
    if (this.heldMesh) this.holder.remove(this.heldMesh);
    this.heldMesh = mesh;
    if (!mesh) return;
    mesh.traverse((c) => { c.matrixAutoUpdate = true; c.visible = c.visible || c === mesh; c.layers.set(0); });
    mesh.visible = true;
    mesh.position.set(0, 0, 0); mesh.rotation.set(0, 0, 0); mesh.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(mesh); const size = box.getSize(new THREE.Vector3()); const ctr = box.getCenter(new THREE.Vector3());
    const mx = Math.max(size.x, size.y, size.z) || 1;
    const k = fit / mx; mesh.scale.multiplyScalar(k);
    const pivot = new THREE.Group(); pivot.name = 'heldPivot';
    mesh.position.copy(ctr).multiplyScalar(-k);
    pivot.add(mesh); pivot.rotation.set(0.15, -0.45, 0.05);
    pivot.traverse((c) => {
      const m = c as THREE.Mesh; if (!m.isMesh) return;
      m.renderOrder = 990; m.castShadow = false;
      const fix = (mm: THREE.Material) => { const n = mm.clone(); n.depthTest = false; n.depthWrite = false; return n; };
      m.material = Array.isArray(m.material) ? m.material.map(fix) : fix(m.material);
    });
    this.heldMesh = pivot;
    this.holder.add(pivot);
  }

  enterHide(h: HideSpot) {
    this.hide = h;
    this.hideBaseYaw = h.yaw; this.yaw = h.yaw; this.pitch = 0;
    audio.door(h.pos, false);
  }
  exitHide() {
    if (!this.hide) return;
    this.pos.copy(this.hide.exit);
    audio.door(this.hide.pos, true);
    this.hide = null;
  }

  teleport(p: THREE.Vector3, yaw?: number) {
    this.pos.copy(p); if (yaw !== undefined) this.yaw = yaw; this.pitch = 0; this.vel.set(0, 0, 0);
  }

  update(dt: number, col: Collision | null) {
    const s = settingsStore.get();
    const look = consumeLook();
    if (!this.frozen) {
      const sens = 0.0042 * s.sensitivity;
      this.yaw -= look.x * sens;
      this.pitch -= look.y * sens * (s.invertY ? -1 : 1);
      this.pitch = Math.max(-1.35, Math.min(1.35, this.pitch));
      if (this.hide) {
        const lim = this.hide.open ? 1.4 : 0.6;
        let d = this.yaw - this.hideBaseYaw; d = Math.atan2(Math.sin(d), Math.cos(d));
        d = Math.max(-lim, Math.min(lim, d)); this.yaw = this.hideBaseYaw + d;
        this.pitch = Math.max(-0.5, Math.min(0.4, this.pitch));
      }
    }

    // crouch
    const ct = input.crouch ? 1 : 0;
    this.crouchT += (ct - this.crouchT) * Math.min(1, dt * 8);

    let speed = 0;
    this.moving = false;
    if (!this.frozen && !this.hide) {
      const mx = input.move.x, my = input.move.y;
      const mag = Math.min(1, Math.hypot(mx, my));
      const wantRun = input.run && mag > 0.3 && !input.crouch && this.stamina > 0.05;
      this.running = wantRun;
      const base = input.crouch ? 1.25 : wantRun ? 4.6 : 2.3;
      speed = base * mag * this.speedMul;
      const f = this.forward();
      const r = new THREE.Vector3(-f.z, 0, f.x);
      const dir = new THREE.Vector3().addScaledVector(f, my).addScaledVector(r, mx);
      if (dir.lengthSq() > 0) dir.normalize();
      const target = dir.multiplyScalar(speed);
      this.vel.lerp(target, Math.min(1, dt * 10));
      this.pos.addScaledVector(this.vel, dt);
      if (col) col.resolve(this.pos, this.radius, this.eye);
      // multi-storey support (villa stairs / upstairs): ease towards the floor height under the player
      if (this.heightFn) { const ty = this.heightFn(this.pos.x, this.pos.z, this.pos.y); this.pos.y += (ty - this.pos.y) * Math.min(1, dt * 14); }
      const hs = Math.hypot(this.vel.x, this.vel.z);
      this.moving = hs > 0.2;
      if (wantRun && this.moving) this.stamina = Math.max(0, this.stamina - dt * 0.16);
      else this.stamina = Math.min(1, this.stamina + dt * (this.moving ? 0.1 : 0.2));
      // footsteps & bob
      if (this.moving) {
        this.bob += dt * hs * 2.6;
        this.stepAcc += hs * dt;
        const stride = input.crouch ? 0.65 : wantRun ? 0.95 : 0.75;
        if (this.stepAcc > stride) {
          this.stepAcc = 0;
          const vol = input.crouch ? 0.08 : wantRun ? 0.45 : 0.22;
          audio.footstep(this.surfaceFn(this.pos), vol);
        }
      }
      this.noise = !this.moving ? 0 : input.crouch ? 2.5 : wantRun ? 16 : 7;
    } else {
      this.vel.set(0, 0, 0); this.noise = 0; this.running = false;
      this.stamina = Math.min(1, this.stamina + dt * 0.15);
    }

    // camera
    const cam = this.camera;
    if (this.hide) {
      cam.position.copy(this.hide.pos);
    } else {
      const bobY = this.moving ? Math.sin(this.bob * 2) * (this.running ? 0.05 : 0.028) : 0;
      const bobX = this.moving ? Math.cos(this.bob) * (this.running ? 0.04 : 0.02) : 0;
      cam.position.set(this.pos.x + Math.cos(this.yaw) * bobX, this.pos.y + this.eye + bobY, this.pos.z - Math.sin(this.yaw) * bobX);
    }
    let sx = 0, sy = 0;
    if (this.shake > 0) { this.shake = Math.max(0, this.shake - dt); sx = (Math.random() - 0.5) * this.shake * 0.08; sy = (Math.random() - 0.5) * this.shake * 0.08; }
    cam.rotation.set(this.pitch + sy, this.yaw + sx, 0, 'YXZ');
    // held item sway
    this.holder.position.y = -0.32 + (this.moving ? Math.sin(this.bob * 2) * 0.012 : 0);
    // flashlight flicker when low "battery" feel during chase handled outside
  }
}
