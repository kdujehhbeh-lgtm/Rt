# NIGHT SHIFT | شیفت شب

A cinematic, first-person horror game for Android (landscape) built with **Three.js + React + Vite + Tailwind**.
It's a WebGL game packaged as a native Android app through **Capacitor**. All audio is synthesised at runtime and all textures are procedural, so there are no heavy asset files.

## Campaign: 25 chapters × 10 missions, 8 endings
- **1–4:** home → first night at PETRO 24 (see below).
- **5–19:** sixteen more nights (`setupShift`), each with its own theme (black rain, faceless customer, basement breathing, blackout, the tall man, dogs, mirror, lying CCTV, driverless car, the 4 AM call, fog, shelves, endless night, torches, the last customer). Each night draws 8 missions from a pool (serve, restock chips, fridge, spill, trash, pumps, CCTV, coffee, hot dog, fueling, inventory, breaker, phone, back door, lost wallet, hide), plus one page of the father's 1366 diary and a themed finale.
- **20:** the secret of the station: name tags, emergency stop, burning the heart.
- **21:** morning. Drive home, newspaper, TV news (real video), sleep.
- **22–24:** waking on the other side: a nightmare house and station full of non-human statues, a hunting creature, lightable torches and flares; descent to the basement and a conversation with your faceless father.
- **25:** the real secret (your father signed you away before you were born) and the final choice. Endings: True Dawn / Awakening / New Manager, plus the earlier Release, Fire, Dawn, Passenger and Eternal Shift.

## Original story notes (5 chapters + 4 endings)
1. **Home (02:00):** wake up to the alarm, read the message, grab the keys, then **drive the car yourself** (steering, throttle, brake, working rear-view mirror) through the foggy city: the tall man by the road, a dog crossing in the headlights, handprints on the windshield, an engine stall, then the NIGHT SHIFT title.
2. **First shift:** open the store, restore power, tidy shelves, restock fridges, **fill the donut case**, **start the hot dog roller**, serve customers, check the pumps, read the rules.
3. **Strange customers:** CCTV anomalies, wet floor, **fueling a customer's car whose driver vanishes**, faceless customer, mismatched reflections, **making a hot dog** for the trucker, the bipedal dog, **a flyer left on your car**.
4. **They come:** shapeshifter, chases, hiding, blackout, fuel can, **wrench from the tools wall**, generator, phone call.
5. **The secret:** manager's logbook, basement, the heart. Endings are **driving escapes**: Fire (station burning in the mirror) / Dawn / Passenger (someone in the back seat) / Eternal Shift.

### What's new
- `props.ts`: instanced 3D merchandise (chip bags, cereal, cans, bottles, candy, motor oil), glass-door fridges with real bottles, donut case (iced donuts with sprinkles), hot dog roller with rotating sausages that cook, slushie machine, ice cream freezer, ATM, tools pegboard (hammers, wrenches, pliers, tape), wet-floor sign, detailed sedan model (extruded body, rims, lights, plate, interior).
- `creatures.ts`: scarier models: ribcage dog with a long fanged snout and claws, tall man with a cracked porcelain grin and very long fingers, hooded faceless, gaunt watcher with a gaping mouth, flesh-textured shapeshifter variants.
- `art.ts`: procedural horror posters (missing persons, "don't look at its face", the tall man, a lost dog that stands on two legs, a fake job ad, the rules, a "smile" poster, and finally *your own* missing poster), handprints, blood scrawl, packaging labels, plates, gauges.
- Chapter 5 fixes: creatures can no longer see/hear/kill through the basement floor, hunters roam instead of camping above the hatch, escape requires knowing the secret, flags reset correctly on retry, the dog guards the path instead of the car door.

## Project structure
```
src/
  game/
    game.ts        Core engine: renderer, loop, levels, interaction, CCTV, hiding, death/checkpoint, chase, rain, traffic
    story.ts       Chapters, missions, scripted sequences, notes, phone calls, endings
    director.ts    Random event director (17 events, cooldowns, deliberate quiet periods)
    monsters.ts    Creature AI: Dog, Faceless, Tall Man, Watcher behind the glass, Shapeshifter
    npc.ts         Customers: navigation, browsing, queueing, quirks, agitation, dialogue
    player.ts      First-person controller (joystick/keys, sprint/stamina, crouch, head-bob, noise, flashlight)
    characters.ts  Humanoid/creature models + transformations
    audio.ts       Procedural spatial WebAudio (wind, rain, fluorescent buzz, fridges, steps, doors, breathing, chase music…)
    physics.ts     AABB collision, line of sight, waypoint navigation (A*)
    world.ts       Builder helpers, doors, light groups (flicker/power)
    textures.ts    Procedural textures + quality-aware materials
    store.ts       UI store, settings, auto-save/checkpoints, endings
    levels/        house.ts, drive.ts, station.ts
  ui/              HUD, touch controls, menus, settings
```

## Building for Android (Capacitor)
```bash
npm run build                       # produces dist/index.html (single file)
npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap add android                 # uses capacitor.config.json (webDir: dist)
npx cap sync android
```
In `android/app/src/main/AndroidManifest.xml`, add these to the main `<activity>`:
`android:screenOrientation="sensorLandscape"` and `android:configChanges="orientation|screenSize|keyboardHidden"`.
Then build: `npx cap open android` (Android Studio → Build APK), or `cd android && ./gradlew assembleRelease`.

The game can also be installed as a PWA (fullscreen + landscape manifest).

## Controls
- **Touch:** left side = floating joystick; right side = drag to look; buttons for interact ✋, run 🏃, crouch ⬇, flashlight 🔦, use/throw 🍾.
- **Desktop (for testing):** WASD, mouse (click to lock the pointer), Shift, C, E, F, Q, Esc.

## Settings
Quality Low/Medium/High (pixel ratio, shadows, materials, fog volumes, rain density), camera sensitivity, FOV, master/music/SFX volume, button size and opacity, left-handed mode, invert Y, FPS counter.
